/**
 * Object representing the defaults var of this script. Mainly is using for injecting of variables from the Visualforce merge fields.
 * @type {Object}
 */
var migrationDefaults = {
    listDatapicker: [],

    selectedProduct_Selected: null,
    selectedProduct_SelectedIndex: '0',
    selectedProduct_ProductId: null,
    selectedProduct_size: 999,
    migrationProcessId: null,
    images: {
        minus: null,
        plus: null,
        disabledPlus: null,
        up: null,
        down: null,
        left: null,
        right: null,
        newWindow: null,
        magnifier: null,
        cancel: null,
        open: null,
        selectAll: null,
        deselectAll: null,
        printer: null,
        printok: null,
        printnok: null,
    },
    remoteActions: {
        getRelationsOfMigratedProduct: null,
        getProductParameters: null,
        createCase: null,
        checkDependencies: null,
        getSubProductList: null,
        generateQuoteForPrinting: null,
        saveCaseAttachment: null,
        sendOutput: null,
        //deactivateCreditCards: null,
        //getCancellationValidation : null,
        //calculateBagettaDate: null,
        //storeToJSK: null,
        updateOpp: null,
        //checkHeritageCasesDraft: null,
        //removeSelectedProducts: null,
        checkHeirsData: null,
        //checkElbValid: null,
        //callSignBiometricEnvelope: null,
        //checkIfPpfDraft: null,
    },
    temp: {
        selectedProductId: null,
        selectedIndex: null,
        selectedRowId: null,
    },
    urls: {
        scube: null,
        crif: null,
        dmsfn: null,
        sf: null,
    },
    labels: {
        productParametersNotFound: null,
        pcfDraftSaved: null,
        //pcfDraftSavedWithCard: null,
        //heritageDraftExists: null,
        pcfBioSignNoSelectedDoc: null,
        //pcfBioSignSendToTablet: null,
        //ppfDraftExists: null,
    },
    icalc: {
        base: null,
        base: null,
        supplement: null,
        theme: null,
        regular_investment: null,
    },
    translations: {
        base: null,
        supplement: null,
        theme: null,
        regular_investment: null,
    },
    fsval: {
        email: null,
        errSize: 0,
    }
};

const GENERAL_KEYWORD = 'GENERAL';

const VISIBILITY_TYPE_SHOW = 'Show';
const VISIBILITY_TYPE_HIDE = 'Hide';
const VISIBILITY_TYPE_DISABLE = 'Disable';
//----
const INPUT_TYPE_CHECKBOX = 'Checkbox';
const INPUT_TYPE_INPUT = 'Input parameters';
const INPUT_TYPE_SELECT = 'Select';
const INPUT_TYPE_SELECT_WITH_BACKGROUND_QUERY = 'Select With Background Query';
const INPUT_TYPE_CALCULATED_SELECT = 'Calculated Select';
const INPUT_TYPE_INPUT_WITH_BACKGROUND_QUERY = 'Input With Background Query';
const INPUT_TYPE_INPUT_WITH_BACKGROUND_QUERY_MULTI = 'Multiple Input With Background Query';
const INPUT_TYPE_MULTI_SELECT = 'Multi Select';
const INPUT_TYPE_FORMULA = 'Formula';
const INPUT_WITH_SOQL = 'Input with SOQL';
const INPUT_TYPE_DATE = 'Date';
const INPUT_TYPE_HIDDEN = 'Hidden';
const INPUT_TYPE_TEXTAREA = 'Textarea Input Parameter';
const EXTERNAL_LINK = 'External Link';
const BRANCH_FLEXIBILNI_OPERACE_DATA_ID = '5406';
const BRANCH_VZDALENE_BANKOVNICTVI_DATA_ID = '6513';

alertify.defaults.theme.ok = "confirm-btn confirm-btn-primary";
alertify.defaults.theme.cancel = "confirm-btn btn-danger";
alertify.defaults.glossary.ok = 'Ok';

/**
 * State of the application
 * @type {Object}
 */
var configuration = {
    accountId: null,
    oppId: null,
    cuid: null,
    accName: null,
    accSurname: null,
    //accBN: null,
    userName: null,
    userOrgUnitId: null,
    uniqueId: null,
    assetId: null,
    migrationProcessId: null,
    migrationProcessName: null,
    migrationProcessTitle: null,
    atLeastOneAttachmentIsRequired: null,
    selectedAssetMainElement: null,
    selectedAssetChildElement: null,
    caseMessage: null,
    isWdeUser: null,
    onSubmitStoreToJSK: null,
    cstProdMap: null,
    pretermDocSwitch: null,
    note: null,
    istsDocumentIsGenerated: false,
    productList: null,
    productRelations: null,
    //    generatedDocument: null,
    generatedDocumentMap: {},
    filesSize: 0,
    loadedSize: 0,
    files: [],
    apiFields: new Object(),
    elementMarginEdit: '16',
    elementMarginRO: '3',
    elDistribAgreementValue: null,
    pcfUnfinished: null,
    cancellatonValidation: null,
    //isValid: null,
    selectedList: null,
    caseIdFromPage: null,
    originalCaseId: null,
    useAlreadyCreatedCase: null,
    editMode: null,
    mapOfReadOnlyProductsPerId: null,
    allItems: null,
    documents: null,
    doNotCreateACase: null,
    doNotLoadPretermDocFromCST: null,
    sendOutputOnSubmit: null,
    sentOutputType: null,
}

var pppConfig = [];
var checkDepFutureList = [];
var cleavesList = [];
var cleaveIndex = 0;
var requiredFields = [];
var attachmentSendIndex = -1;
var createdCaseId = '';
var pretermDocListLength = 0;
var allPreContractDocumentPrinted = false;
var sendOutputDataListEl = [];
var sendOutputDataListPap = [];
var printingDuty = false;
var sendOutputSent = false;
var elDocDistVisible = false;
var elDocDistVisibilityPerPage = [];
var lastGeneratedDocId = null;
var typeOfOperation;
var firstLoad = true;
var assetList = [];

if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position) {
        position = position || 0;
        return this.indexOf(searchString, position) === position;
    };
}

if (!String.prototype.endsWith) {
    String.prototype.endsWith = function(suffix) {
        return this.indexOf(suffix, this.length - suffix.length) !== -1;
    }
}

if (!String.prototype.includes) {
    String.prototype.includes = function(search, start) {
        'use strict';
        if (typeof start !== 'number') {
            start = 0;
        }

        if (start + search.length > this.length) {
            return false;
        } else {
            return this.indexOf(search, start) !== -1;
        }
    };
}

function getSelectedProductSizeInReeditMode() {
    if (configuration.pcfUnfinished || configuration.editMode) {
        let maxId = '0';
        for (parentId in configuration.productRelations) {
            var idParts = parentId.split('-');
            if (idParts.length > 1 && parseInt(idParts[0], 10) > parseInt(maxId, 10)) {
                maxId = idParts[0];
            }
        }
        if (maxId >= migrationDefaults.selectedProduct_size) {
            migrationDefaults.selectedProduct_size = ++maxId;
        }
    }
}

function clearSelects() {
    $('#childProductOptions').val("0");
    $('.select2-container').hide();
    $('#productCategoriesOptions').hide();
    $('.select2-selection--single').hide();
    //$('#childProductOptions').hide();
    $('#OKLookup').prop("disabled", true);
    //showChildProducts();
}

/*function checkSelectedProducts() {
    //dedictvi
    if(configuration.migrationProcessName === 'Heritage'){
        Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.removeSelectedProducts, JSON.stringify(configuration.productList), configuration.migrationProcessName, function(result, evt) {
            if (evt.status) {
                console.log('res: ' , result);
                console.log('res2: ' , $('#childProductOptions'));
                var childProductOptions = $('#childProductOptions');
                childProductOptions.html('');
                childProductOptions.append($('<option>', {
                    value: '0',
                    text: '---Vyberte---'
                }));
                $.each(result, function(i, item) {
                    childProductOptions.append($('<option>', {
                        value: item.Id,
                        text: item.Name
                    }));
                });
            } else {
                var errorDiv = $('#cancel-validation-error-div');
                html += ' <h2 id="alert-error--errorMessage">' + 'Nastal problém s načtením  prvků v select boxu' + '</h2>';
                errorDiv.html(html);
                errorDiv.show();
            }
        });
    }
}*/

function clearSelectsDebetCards() {
    //$('#debetCardsOptions').val("0");
    $('#modal-select-cards-ok-button').prop("disabled", true);
}

function showChildProducts() {
    $('.select2-selection--single').show();
    //$('#childProductOptions').empty();
    $('#childProductOptions').select2({
        dropdownParent: $("#modal-1"),
        width: '100%',
        language: "cs"
    });
}

function removeDisabled(value) {
    if (value != null && value != '0' && value != 0) {
        $('#OKLookup').removeAttr('disabled');
    }
    if (value == '0' && value == 0) {
        $('#OKLookup').prop("disabled", true);
    }
}

function disableImage(elmnt) {
    var image = elmnt.getElementsByTagName('img');
    $(elmnt).css({
        'pointer-events': 'none'
    });
    $(image).prop('src', migrationDefaults.images.disabledPlus);
    var children = document.querySelectorAll('[data-parentid=\'' + elmnt.id + '\']');
    for (var i = 0; i < children.length; i++) {
        disableImage(children[i]);
    }
}

function disableSelectedProductsInReeditMode() {
    //PJ comment 6th Sept 2020: this is weird - only change images, does not change onclick function !!
    if (configuration.editMode) {
        for (var k in configuration.productList.itemMap) {
            var iMap = configuration.productList.itemMap[k];
            var image = $('#productImage' + iMap.theProduct.Id + '-' + iMap.theAsset.Id);
            var element = $('#productButton-' + iMap.theProduct.Id + '-' + iMap.theAsset.Id);
            $(element).css({
                'pointer-events': 'none'
            });
            $(image).prop('src', migrationDefaults.images.disabledPlus);
            var children = document.querySelectorAll('[data-parentid=\'productButton-' + iMap.theProduct.Id + '-' + iMap.theAsset.Id + '\']');
            for (var i = 0; i < children.length; i++) {
                disableImage(children[i]);
            }
        }
    }
    if (configuration.pcfUnfinished) {
        var productsFromConfig = [];
        for (var k in configuration.productList.itemMap) {
            var representativeItem = {};
            representativeItem.id = configuration.productList.itemMap[k].theProduct.Id;
            representativeItem.productNumber = configuration.productList.itemMap[k].theAsset.Account_Number__c;
            productsFromConfig.push(representativeItem);
        }
        for (var i = 0; i < productsFromConfig.length; i++) {
            for (var k in configuration.allItems.itemMap) {
                if (productsFromConfig[i].id === configuration.allItems.itemMap[k].theProduct.Id && productsFromConfig[i].productNumber === configuration.allItems.itemMap[k].theAsset.Account_Number__c) {
                    var elementToDisable = document.getElementById('productButton-' + configuration.allItems.itemMap[k].theProduct.Id + '-' + configuration.allItems.itemMap[k].theAsset.Id);
                    disableImage(elementToDisable);
                }
            }
        }
    }
}

function removeDisabledModalButton(value, elementId) {
    elementId = '#' + elementId;
    if (value != null && value != '0' && value != 0) {
        $(elementId).removeAttr('disabled');
    } else {
        $(elementId).attr('disabled', 'disabled');
    }
}

function enableImage(productId, assetId) {
    var image = $('#productImage' + productId + '-' + assetId);
    var element = $('#productButton-' + productId + '-' + assetId);
    $(element).css({
        'pointer-events': 'auto'
    });
    $(image).prop('src', migrationDefaults.images.plus);

    var children = document.querySelectorAll('[data-parentid=\'productButton-' + productId + '-' + assetId + '\']');
    for (var i = 0; i < children.length; i++) {
        enableImage(children[i].dataset.productid, children[i].dataset.assetid);
    }
}

function getProductToMigrationHTML(productId, productName, data, hasSubproducts, assetId) {
    var newItem = ''
    var productIndex = '';
    var productWholeName = productName;
    if (data.theAsset && data.theAsset.Account_Number__c) {
        productWholeName += ' - ' + data.theAsset.Account_Number__c;
    }
    var selectedProductSpanId = 'selected-product-{0}-{1}'.format(migrationDefaults.selectedProduct_size, productId);
    newItem += '<span id="{0}">'.format(selectedProductSpanId);
    newItem += '<ul id="" aria-activedescendant="tree0-node0" aria-labelledby="treeheading" class="slds-tree" role="tree">'
    newItem += '<li aria-expanded="true" aria-level="1" class="slds-tree__branch" id="li-node-{0}" role="treeitem">'.format(migrationDefaults.selectedProduct_size);
    newItem += '<div class="slds-tree__item" style="width: 100%;">';
    newItem += '<a href="#" id="tree0-node0-link{0}" onclick="changePage({1});" role="presentation" tabindex="-1">{2}</a>'
        .format(productIndex, migrationDefaults.selectedProduct_size, productWholeName);
    newItem += '<div class="slds-button-group">';
    if (hasSubproducts) {
        newItem += '<button class="slds-button slds-button--icon-bare slds-m-right--x-smal button-without-border" data-aljs="modal" data-aljs-show="modal-select-cards" onclick="addSubProductSetVariables(\'selected-product-{0}-{1}\', {0}, \'{1}\');">'
            .format(migrationDefaults.selectedProduct_size, productId);
        newItem += '<span class="calc-btn-icon">';
        newItem += '<img id="assetMinus{0}" style="width: 28px; height: 28px;" src="{1}"></img>'.format(productId, migrationDefaults.images.card);
        newItem += '</span>';
        newItem += '</button>';
    }
    newItem += '<button class="slds-button slds-button--icon-bare slds-m-right--x-smal button-without-border" onClick="removeFromMigration(\'{0}\', \'{1}\', \'{2}\', \'{3}\', \'{4}\');">'
        .format(productId, selectedProductSpanId, 'transition-tab-' + migrationDefaults.selectedProduct_size, migrationDefaults.selectedProduct_size, assetId);
    newItem += '<span class="calc-btn-icon">';
    newItem += '<img id="assetMinus{0}" style="width: 28px; height: 28px;" src="{1}"></img>'.format(productId, migrationDefaults.images.minus);
    newItem += '</span>';
    newItem += '</button>';
    newItem += '</div>';
    newItem += '</div>';
    newItem += '</li>';
    newItem += '</ul>';
    if (data && configuration.migrationProcessName != 'Heritage') {
        newItem += getProductToMigrationChildHTML(data);
    }
    newItem += '</span>';
    migrationDefaults.selectedProduct_size += 1;
    return newItem;
}

function getProductToMigrationChildHTML(data) {
    var html = '';
    if (data.childItemMap) {
        for (var childItemIndex in data.childItemMap) {
            var childItem = data.childItemMap[childItemIndex];
            html += '<ul id="" aria-activedescendant="tree0-node0" aria-labelledby="treeheading" class="slds-tree" role="tree">'
            html += '   <li aria-expanded="true" aria-level="1" class="slds-tree__branch" id="tree0-node0{0}" role="treeitem">';
            html += '       <div class="slds-tree__item" style="width: 100%;">';
            html += '           <span class="tab-escape">';
            html += childItem.name;
            if (data.theAsset && data.theAsset.Assets__r && data.theAsset.Assets__r.records && data.theAsset.Assets__r.records[0].Account_Number__c) {
                html += ' ' + data.theAsset.Assets__r.records[0].Account_Number__c;
            }
            if (childItem.dispatcher) {
                var dispatcher = childItem.dispatcher;
                html += '<div class="tooltip-disponent">(disponent)';
                html += '<div class="tooltiptext">';
                html += '<div><br />';
                html += '<p>';
                html += '<a href="" onclick="openItem({0});">'.format(dispatcher.theId);
                html += '{0}&nbsp;(CUID: {1})&nbsp;'.format(dispatcher.name, dispatcher.cuid);
                html += '<img style="width: 20px; height: 20px;" src="{0}"/>'.format(migrationDefaults.images.newWindow);
                html += '</a>';
                html += '</p>';
                html += '</div>';
                html += '</div>';
                html += '</div>';
            }
            html += '</span>';
            html += '</div>';
            html += '</li>';
            html += '</ul>';
        }
    }
    return html;
}

function getSubProductToMigrationHTML(productId, productName, parentProductId, parentIndex) {
    var newItem = ''
    var productIndex = '';
    var newItemId = 'ul-' + productId;
    newItem += '<ul id="{0}" aria-activedescendant="tree0-node0" aria-labelledby="treeheading" class="slds-tree" role="tree">'.format(newItemId);
    newItem += '<li aria-expanded="true" aria-level="1" class="slds-tree__branch" id="tree0-node0{0}" role="treeitem">'.format(productIndex);
    newItem += '<div class="slds-tree__item" style="width: 100%;">';
    newItem += '<span class="tab-escape">{0}</span>'.format(productName);
    newItem += '<button class="slds-button slds-button--icon-bare slds-m-right--x-smal button-without-border" onClick="removeChildFromMigration(\'{0}\', \'{1}\', \'{2}\', \'{3}\');">'
        .format(productId, newItemId, parentProductId, parentIndex);
    newItem += '<span class="calc-btn-icon">';
    newItem += '<img id="assetMinus{0}" style="width: 28px; height: 28px;" src="{1}"></img>'.format(productId, migrationDefaults.images.minus);
    newItem += '</span>';
    newItem += '</button>';
    newItem += '</div>';
    newItem += '</li>';
    newItem += '</ul>';
    return newItem;
}

function addProductTransitionHtml(isVisible, selectedRow, productRelationMap, elementId, productId) {
    var html = getProductTransitionHtml(isVisible, selectedRow, productRelationMap, elementId, productId);
    $('#product-settings-tab-1').append(html);
}

function addProductParameterHtml(isVisible, selectedRow, productRelationMap, elementId, productId) {
    var html = getProductParameterHtml(isVisible, selectedRow, productRelationMap, elementId, productId);
    $('#product-parameter-table').append(html);
}

/*function addSubProductTransitionHtml(productRelationMap, parentProductId){
    var html = '';
    for(childItemIndex in productRelationMap){
        var childItem = productRelationMap[childItemIndex];
        html += getProductTransitionElementHtml(childItem.productName, childItem.productRelationList, true, null, migrationDefaults.temp.selectedIndex + '-' + migrationDefaults.temp.selectedProductId, childItemIndex);
    }
    var elementId = '#transition-item-' + migrationDefaults.temp.selectedIndex + '-' + migrationDefaults.temp.selectedProductId;
    $(elementId).append(html);
}*/

function addSubProductTransitionHtml(childItem, childItemIndex) {
    var html = '';
    html += getProductTransitionElementHtml(childItem.productName, childItem.productRelationList, true, null, null, migrationDefaults.temp.selectedIndex + '-' + migrationDefaults.temp.selectedProductId, childItemIndex, childItem.assetAccountNumber, childItem.assetId);
    var elementId = '#transition-item-' + migrationDefaults.temp.selectedIndex + '-' + migrationDefaults.temp.selectedProductId;
    $(elementId).append(html);
}

/**
 * [addSubProductParameterHtml description]
 * @param {String} productName     The name of the added product
 * @param {String} productId       The ID of the added product
 */
function addSubProductParameterHtml(productName, productId) {
    var html = '';
    var parentElementId = '{0}-{1}'.format(migrationDefaults.temp.selectedIndex, migrationDefaults.temp.selectedProductId);
    //getProductParameterElementHtml(productName, isOwner, disponentText, parentId, productId)
    html += getProductParameterElementHtml(productName, true, null, parentElementId, productId);
    var elementId = '#item-product-param-{0}'.format(migrationDefaults.temp.selectedIndex);
    $(elementId).append(html);
}

function addMultipleProductTransitionHtml(isVisible, selectedRow, productRelationMap) {
    console.log('1 multiple ', isVisible);
    console.log('1 multiple ', selectedRow);
    console.log('1 multiple ', productRelationMap);
    var htmlProductParams = getMultipleProductParameterHtml(isVisible, selectedRow, productRelationMap);
    $('#product-parameter-table').append(htmlProductParams);
    if (productRelationMap[GENERAL_KEYWORD]) {
        var htmlGeneralProductParams = getGeneralMultipleProductParameterHtml(productRelationMap[GENERAL_KEYWORD]);
        $('#general-product-parameter-table').append(htmlGeneralProductParams);
    }
    var htmlTransitions = '';
    for (var parentItemIndex in productRelationMap) {
        if (parentItemIndex == GENERAL_KEYWORD) {
            var generalRelationMap = productRelationMap[GENERAL_KEYWORD];
            for (var childItemIndex in generalRelationMap) {
                var childItem = generalRelationMap[childItemIndex];
                if (childItem && childItem.productRelationList && childItem.productRelationList.length > 0) {
                    var prodRelation = childItem.productRelationList[0];
                    console.log('2 multiple');
                    getProductParameters(prodRelation.Id, prodRelation.Default_Name__c, GENERAL_KEYWORD, prodRelation.Id, configuration.assetId, null, null);
                }
            }
            continue;
        }
        htmlTransitions += getMultipleProductTransitionHtml(isVisible, selectedRow, parentItemIndex, productRelationMap);
        /*if(isVisible){
            isVisible = false;
        }*/
    }
    $('#product-settings-tab-1').append(htmlTransitions);
    disableSelectedProductsInReeditMode();
    getSelectedProductSizeInReeditMode();
}

function getMultipleProductTransitionHtml(isVisible, selectedRow, parentItemIndex, productRelationMap) {
    var html = '';
    //for(parentItemIndex in productRelationMap){
    var parentItem = productRelationMap[parentItemIndex];
    var index = parentItemIndex.split('-');
    var localVisible = false;
    if (isVisible && index[0] == '0') {
        localVisible = true;
        //migrationDefaults.selectedProduct_SelectedIndex = index[0];
    }
    html += '<div class="slds-tabs__content {0}" role="tabpanel" id="transition-tab-{1}">'.format(localVisible ? 'slds-show' : 'slds-hide', index[0]);
    html += '<div class="form-full">';
    html += '<div id="transition-item-{0}" class="slds-form--horizontal" style="text-align: left;">'.format(parentItemIndex);
    var elements = [];
    for (var childItemIndex in parentItem) {
        var childItem = parentItem[childItemIndex];
        var expr = /-/;
        var transitionIndex;
        if (expr.test(childItemIndex)) {
            transitionIndex = childItemIndex.split('-')[0];
        }
        //var childItem = productRelationMap[childItemIndex];
        if (typeof childItem.disponentId == 'undefined') {
            childItem.disponentId = null;
        }
        elements[transitionIndex] = getProductTransitionElementHtml(childItem.productName, childItem.productRelationList, childItem.isOwner, childItem.disponentText, childItem.disponentId, parentItemIndex, childItemIndex, childItem.assetAccountNumber, childItem.assetId);
    }
    elements.forEach(function(item) {
        html += item;
    });


    html += '</div>';
    html += '</div>';
    html += '</div>';
    //}
    return html;
}

function getMultipleProductParameterHtml(isVisible, selectedRow, productRelationMap) {
    var html = '';
    for (var parentItemIndex in productRelationMap) {
        if (parentItemIndex === GENERAL_KEYWORD) {
            continue;
        }
        var parentItem = productRelationMap[parentItemIndex];
        var index = parentItemIndex.split('-');
        var localVisible = false;
        if (isVisible && index[0] == '0') {
            localVisible = true;
            //migrationDefaults.selectedProduct_SelectedIndex = index[0];
        }
        html += '<div id="item-product-param-{0}" class="{1}" style="min-height: 405px;">'.format(index[0], localVisible ? 'slds-show' : 'slds-hide');
        /*if(isVisible){
            isVisible = false;
        }*/
        var elements = [];
        for (var childItemIndex in parentItem) {
            var childItem = parentItem[childItemIndex];
            if (childItem.productRelationList && childItem.productRelationList.length > 0) {
                var expr = /-/;
                var transitionIndex;
                if (expr.test(childItemIndex)) {
                    transitionIndex = childItemIndex.split('-')[0];
                }

                var itemElementName;
                if (childItem && childItem.assetAccountNumber && childItem.assetAccountNumber != '') {
                    itemElementName = childItem.productName + '&nbsp;(' + childItem.assetAccountNumber + ')&nbsp;';
                } else {
                    itemElementName = childItem.productName;
                }
                elements[transitionIndex] = getProductParameterElementHtml(itemElementName, childItem.isOwner, childItem.disponentText, parentItemIndex, childItemIndex);
            }
        }
        elements.forEach(function(item) {
            html += item;
        });
        html += '</div>';
    }
    return html;
}

function getGeneralMultipleProductParameterHtml(productRelationMap) {
    var html = '';
    html += '<div id="item-product-param-general" class="slds-show">';
    var elements = [];
    var i = 0;
    for (var childItemIndex in productRelationMap) {
        var childItem = productRelationMap[childItemIndex];
        var itemElementName;
        var itemElementId;
        if (childItem && childItem.productRelationList && childItem.productRelationList.length > 0) {
            var prodRelation = childItem.productRelationList[0];
            itemElementName = prodRelation.Default_Name__c;
            itemElementId = prodRelation.Id;
            elements[i] = getProductParameterElementHtml(itemElementName, true, null, GENERAL_KEYWORD, itemElementId);
        }
        i++;
    }
    elements.forEach(function(item) {
        html += item;
    });
    html += '</div>';
    return html;
}

function getProductTransitionHtml(isVisible, selectedRow, productRelationMap, elementId, productId) {
    var html = '';
    html += '<div class="slds-tabs__content {0}" role="tabpanel" id="transition-tab-{1}">'.format(isVisible ? 'slds-show' : 'slds-hide', elementId);
    html += '<div class="form-full">';
    html += '<div id="transition-item-{0}-{1}" class="slds-form--horizontal" style="text-align: left;">'.format(elementId, productId);
    for (childItemIndex in productRelationMap) {
        var childItem = productRelationMap[childItemIndex];
        html += getProductTransitionElementHtml(childItem.productName, childItem.productRelationList, true, null, null, elementId, childItemIndex, childItem.assetAccountNumber, null);
    }
    html += '</div>';
    html += '</div>';
    html += '</div>';
    return html
}

function getProductParameterHtml(isVisible, selectedRow, productRelationMap, elementId, productId) {
    //console.log('tu som getProductParameterHtml', productRelationMap);
    var html = '';
    html += '<div class="{0}" id="item-product-param-{1}">'.format(isVisible ? 'slds-show' : 'slds-hide', elementId);
    var prKeys = Object.keys(productRelationMap).sort();
    for (var k = 0; k < prKeys.length; ++k) {
        var childItem = productRelationMap[prKeys[k]];
        if (childItem.productRelationList && childItem.productRelationList.length > 0) {
            var itemElementName;
            if (childItem && childItem.assetAccountNumber && childItem.assetAccountNumber != '') {
                itemElementName = childItem.productName + '&nbsp;(' + childItem.assetAccountNumber + ')&nbsp;';
            } else {
                itemElementName = childItem.productName;
            }
            var parentId = elementId + '-' + productId;
            html += getProductParameterElementHtml(itemElementName, childItem.isOwner, childItem.disponentText, parentId, prKeys[k]);
        }
    }
    html += '</div>';
    return html;
}

function getProductTransitionElementHtml(productName, productRelationList, isOwner, disponentText, disponentId, parentId, productId, assetNumber, assetId) {
    var newItem = '';
    if (productRelationList && productRelationList.length > 0) {

        console.log('configuration.mapOfReadOnlyProductsPerId: ', configuration.mapOfReadOnlyProductsPerId);

        var isElementReadOnly = false;
        if (configuration.mapOfReadOnlyProductsPerId && configuration.editMode && assetId) {
            var productObjects = JSON.parse(configuration.mapOfReadOnlyProductsPerId);
            for (var oneObject in productObjects) {
                console.log('oneObject: ', oneObject);
                console.log('assetId: ', assetId);
                if (oneObject === assetId) {
                    console.log('som in');
                    if (productObjects[oneObject] == false) {
                        isElementReadOnly = true;
                    }
                    break;
                }
            }
        }

        var dispatcherTextHtml = isOwner ? '' : ' - ' + disponentText;
        var productNumberHtml = '';
        if (assetNumber !== undefined && assetNumber !== null && assetNumber !== '') {
            productNumberHtml = '- ' + assetNumber;
        }
        if (configuration.migrationProcessName === 'Heritage') {
            newItem += '<div id="transition-error-{0}-{1}" style="color: #c23934; text-align: center;">Vyberte prosím druh převodu.</div>'.format(parentId, productId);
        }
        newItem += '<div id="{0}-{1}">'.format(parentId, productId);
        newItem += '<div class="slds-form-element" style="margin-top: 16px;" id="relatiion-1" data-index="69">';
        newItem += '<label class="slds-form-element__label headline" for="prod_param_9_69" style="display: inline-block">{0} {1} {2}</label>'
            .format(productName, productNumberHtml, dispatcherTextHtml);
        newItem += '<div class="slds-form-element__control">';
        newItem += '<select {0} id="prod_param_select_9_69" class="slds-select valid" style="width: 30%;" onchange="getProductParameters(this.value, this.options[this.selectedIndex].innerHTML, \'{1}\', \'{2}\', \'{3}\', \'{4}\', this);" aria-invalid="false" data-prodname="{5}" data-parid="{1}" data-prodid="{2}">'
            .format(configuration.savedConfiguration || isElementReadOnly ? 'disabled=""' : '', parentId, productId, assetId ? assetId : '', migrationDefaults.migrationProcessId, productName);
        newItem += '<option value="0">---Vyberte---</option>';
        if (productRelationList) {
            for (var i = 0; i < productRelationList.length; i++) {
                var relation = productRelationList[i];
                var relationName = relation.Default_Name__c ? relation.Default_Name__c : relation.To__r.Name;
                if (relation.Type__c == 'Create') {
                    var toCstValId = relation.From__r.CST_Value_ID__c;
                    var toName = relation.From__r.Name;
                } else if (relation.Type__c == 'Cancel') {
                    var toCstValId = 'cancel';
                    var toName = 'cancel';
                } else {
                    var toCstValId = relation.To__c ? relation.To__r.CST_Value_ID__c : 'cancel';
                    var toName = relation.To__c ? relation.To__r.Name : 'cancel';
                }
                //JK: uprava pridani do nebo vetve cast s pcf unfinished
                if (!configuration.savedConfiguration && !configuration.pcfUnfinished && ((isOwner && relation.Is_Owner_Default__c) || (!isOwner && relation.Is_Dispatcher_Default__c))) {
                    configuration.productRelations[parentId][productId].selectedRelationId = relation.Id;
                    getProductParameters(relation.Id, relationName, parentId, productId, assetId, disponentId, null);
                    newItem += '<option data-to-cst-val-id="{2}" data-to-name="{3}" selected="selected" value="{0}">{1}</option>'.format(relation.Id, relationName, toCstValId, toName);
                } else {
                    //JK: uprava pridani do nebo vetve cast s pcf unfinished
                    if ((configuration.savedConfiguration || configuration.pcfUnfinished) && configuration.productRelations[parentId][productId].selectedRelationId == relation.Id) {
                        newItem += '<option data-to-cst-val-id="{2}" data-to-name="{3}" selected="selected" value="{0}">{1}</option>'.format(relation.Id, relationName, toCstValId, toName);
                        getProductParameters(relation.Id, relationName, parentId, productId, assetId, disponentId, null);
                    } else {
                        newItem += '<option data-to-cst-val-id="{2}" data-to-name="{3}" value="{0}">{1}</option>'.format(relation.Id, relationName, toCstValId, toName);
                    }
                }
            }
        }
        newItem += '</select>';
        newItem += '</div>';
        newItem += '</div>';
        newItem += '</div>';
    }
    return newItem;
}

function getProductParameterElementHtml(productName, isOwner, disponentText, parentId, productId) {
    var newItem = '';
    var dispatcherTextHtml;
    if (isOwner) {
        dispatcherTextHtml = '';
    } else {
        dispatcherTextHtml = ' - ' + disponentText;
    }
    if (parentId === GENERAL_KEYWORD) {
        /*newItem += '<h3 id="product-parameter-section-{0}-{1}"" class="slds-section-title--divider section-title--margin section-main-title">{2}</h3>'
            .format(parentId, productId, productName);*/
    } else {
        newItem += '<h3 id="product-parameter-section-{0}-{1}"" class="slds-section-title--divider section-title--margin section-main-title">{2}{3}&nbsp;&rarr;&nbsp;<span id="product-parameter-transition-{4}-{5}"></span></h3>'
            .format(parentId, productId, productName, dispatcherTextHtml, parentId, productId);
    }
    /*newItem += '<div class="grid">';
    newItem +=      '<div id="product-parameter-part-{0}-{1}" style="table:row;">'.format(parentId, productId);
    newItem +=          '<div scope="col" style="text-align:right;" class="slds-col slds-size--1-of-2">';
    newItem +=              '<div class="slds-form-element">';
    newItem +=                  '<div id="item-product-param-option-{0}" class="slds-form-element__control exception-row" aria-labelledby="a0B4E000002tmqoUAA" style="display:block">'.format(productId);
    newItem +=                      '<p id="placeholder-product-param-{0}-{1}">{2}</p>'.format(parentId, productId, 'Neni vybran prechod na jiny produkt.');
    newItem +=                  '</div>';
    newItem +=              '</div>';
    newItem +=          '</div>';
    newItem +=      '</div>';*/
    newItem += '<div id="product-parameter-part-{0}-{1}">'.format(parentId, productId);
    if (parentId !== GENERAL_KEYWORD) {
        newItem += '<div class="slds-form--horizontal" style="text-align: left;">';
        //newItem +=      '<div id="product-parameter-part-{0}-{1}">'.format(parentId, productId);
        newItem += '<div class="slds-form-element" style="margin-top: 16px;">';
        newItem += '<p id="placeholder-product-param-{0}-{1}">{2}</p>'.format(parentId, productId, 'Neni vybran prechod na jiny produkt.');
        newItem += '</div>';
        //newItem +=      '</div>';
        newItem += '</div>';
    }
    newItem += '</div>';
    return newItem;
}
//CRMCNCP-7220,7213
var assetsForValidationList = [];

function removeFromMigration(productId, elementId, transitionElementId, index, assetId) {
    var selected = false;
    var nodeId = '#li-node-' + index;
    if ($(nodeId).hasClass('chosenProduct')) {
        selected = true;
    }

    //    $('#item-product-param-' + index).removeClass('slds-show');
    //    $('#item-product-param-' + index).addClass('slds-hide');

    $('#item-product-param-' + index).remove();
    $('#' + elementId).remove();
    $('#' + transitionElementId).remove();
    delete configuration.productRelations[index + '-' + productId];
    delete configuration.productList.itemMap[index + '-' + productId];

    elDocDistVisibilityPerPage[index] = false;
    checkAndSetGlobalElDocDistVisibility();

    enableImage(productId, assetId);
    if (selected) selectFirstFromSelectedProducts();
    removeFromAssetList(assetId);

    //callCancellationValidaton(assetId, true);
}

function selectFirstFromSelectedProducts() {
    var firstItem = $('#selected-products span:first-child');
    if (firstItem.length > 0) {
        var spanId = firstItem.attr('id');
        var index = spanId.split('-');
        if (index.length > 3) {
            changePage(index[2]);
        }
    }
}

function removeChildFromMigration(productId, elementId, parentProductId, parentIndex) {
    $('#product-parameter-section-' + parentIndex + '-' + parentProductId + '-' + productId).remove();
    $('#product-parameter-part-' + parentIndex + '-' + parentProductId + '-' + productId).remove();
    $('#' + parentIndex + '-' + parentProductId + '-' + productId).remove();
    $('#' + elementId).remove();
    var itemToDelete = configuration.productRelations[parentIndex + '-' + parentProductId];
    var dataIndex = parentIndex + '-' + parentProductId;
    var dataToDelete = configuration.productList.itemMap[dataIndex].childItemMap;
    delete dataToDelete[productId];
    delete itemToDelete[productId];
    setElDocDistAgrSelectVisibility(parentIndex);
}

function changeSelectedProductParameter(parentId, productId, productParameterId) {
    var expr = /-/;
    var parentIdWithoutIndex;
    if (expr.test(parentId)) {
        parentIdWithoutIndex = parentId.split('-')[1];
    }
    if (parentIdWithoutIndex === productId) {

    } else {

    }
}

function addSubProductButton(selectedRowId) {
    migrationDefaults.selectedProduct_Selected = selectedRowId;
    clearSelectsDebetCards();
}

function addToAssetList(assetId) {
    if (assetId) {
        for (var i = 0; i < assetList.length; i++) {
            if (assetList[i] == assetId) {
                return;
            }
        }
        assetList.push(assetId);
    }
}

function removeFromAssetList(assetId) {
    if (assetId) {
        for (var i = 0; i < assetList.length; i++) {
            if (assetList[i] == assetId) {
                assetList.splice(i, 1);
                return;
            }
        }
    }
}

function addProductAndRender(currentElement, productId, productName, assetId) {
    showLoadingModal();
    console.log('test1: ', migrationDefaults.selectedProduct_size);
    Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.getRelationsOfMigratedProduct,
        configuration.accountId, productId, '', assetId, migrationDefaults.selectedProduct_size, false, configuration.migrationProcessId,
        function(result, event) {
            console.log('result: ', result);
            var parser = new DOMParser;
            var dom = parser.parseFromString(result, 'text/html');
            var decodedString = dom.body.textContent;
            result = decodeURIComponent(decodedString);
            result = JSON.parse(result);
            addProductParameterHtml(false, '', result.transitionItemMap[migrationDefaults.selectedProduct_size + '-' + result.productId], migrationDefaults.selectedProduct_size, result.productId);
            //addProductTransitionHtml(false, '', result.transitionItemMap, migrationDefaults.selectedProduct_size, result.productId);
            configuration.productRelations[migrationDefaults.selectedProduct_size + '-' + result.productId] = result.transitionItemMap[migrationDefaults.selectedProduct_size + '-' + result.productId];
            var html = getMultipleProductTransitionHtml(false, 'selectedRow', migrationDefaults.selectedProduct_size + '-' + result.productId, result.transitionItemMap)
            $('#product-settings-tab-1').append(html);

            configuration.productList.itemMap[migrationDefaults.selectedProduct_size + '-' + result.productId] = result.theItem;

            dismissLoadingModal();
            // Initialization of new modal have to be called HERE! When it is called in the current thread, its preventing the close operation associated with the "OK" button on modal.
            //            $('[data-aljs="modal]').modal();
            Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.getSubProductList, productId, configuration.migrationProcessId, function(res, evt) {
                if (evt.status && res && res.length > 0) {
                    var newItem = getProductToMigrationHTML(productId, productName, result.theItem, true, assetId);
                } else {
                    var newItem = getProductToMigrationHTML(productId, productName, result.theItem, false, assetId);
                }
                if (currentElement) {
                    disableImage(currentElement);
                }
                $('#selected-products').append(newItem);
                changePage(migrationDefaults.selectedProduct_size - 1);
                addToAssetList(assetId);
                removeDisabled(0);
            });
            //        migrationDefaults.selectedProduct_size += 1;
        });
    //    //console.log('### currentElement - ', currentElement);
    //    //console.log('### children - ', document.querySelectorAll('[data-parentid=\''+ currentElement.id +'\']'));
    //callCancellationValidaton(assetId);
}

// CRMCNCP-7220,7213
/*function callCancellationValidaton(assetId, remove) {
    if (configuration.migrationProcessName === 'Account_Cancellation' && assetId) {
        if (remove) {
            var assetIndex = assetsForValidationList.indexOf(assetId);
            if (assetIndex > -1) {
                assetsForValidationList.splice(assetIndex, 1);
            }
        } else {
            assetsForValidationList.push(assetId);
        }
        Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.getCancellationValidation, assetsForValidationList, configuration.accountId, function(result,event){
            var errorDiv = $('#cancel-validation-error-div');
            if(result && result.messageList && result.messageList.length > 0){
                var html = '';
                for(var i = 0; i < result.messageList.length; i++){
                    html += ' <h2 id="alert-error--errorMessage">' + result.messageList[i] + '</h2>';
                }
                errorDiv.html(html);
                errorDiv.show();
            } else {
                errorDiv.hide();
            }
        });
    }
}*/

function addSubProductSetVariables(currentRowId, selectedRowIndex, productId) {
    migrationDefaults.temp.selectedRowId = currentRowId;
    migrationDefaults.temp.selectedIndex = selectedRowIndex;
    migrationDefaults.temp.selectedProductId = productId;
    Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.getSubProductList, productId, configuration.migrationProcessId, function(result, event) {
        if (event.status && result) {
            var debetCards = $('#debetCardsOptions');
            debetCards.html('');
            debetCards.append($('<option>', {
                value: '0',
                text: '---Vyberte---'
            }));
            $.each(result, function(i, item) {
                debetCards.append($('<option>', {
                    value: item.Id,
                    text: item.Name
                }));
            });
        }
    });
    //console.log('migProcId: ' + configuration.migrationProcessId);
    clearSelectsDebetCards();
}

/**
 * Method adding HTML elements to the product setting page (Choosing of products and Configuration)
 * @param {String} productId   [The ID of the added product]
 * @param {String} productName [The name of the added product]
 */
function addSubProductAndRender(productId, productName) {
    Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.getRelationsOfMigratedProduct,
        configuration.accountId, productId, migrationDefaults.temp.selectedProductId, null, 1, true, configuration.migrationProcessId, /*migrationDefaults.selectedProduct_size,*/
        function(result, event) {
            result = JSON.parse(decodeString(result));
            var newItem;
            var parentIndex = migrationDefaults.temp.selectedIndex + '-' + migrationDefaults.temp.selectedProductId;
            var data = configuration.productRelations[parentIndex];
            if (!configuration.productList.itemMap[parentIndex].childItemMap) {
                configuration.productList.itemMap[parentIndex].childItemMap = new Object();
            }
            var confData = configuration.productList.itemMap[parentIndex];
            for (index in result.transitionItemMap) {
                var item = result.transitionItemMap[index];
                var dataIndex = objectLength(data) + '-' + productId;
                var itemData;
                for (indexData in item) {
                    itemData = item[indexData];
                }
                data[dataIndex] = itemData;
                confData.childItemMap[dataIndex] = result.theItem;
                confData.lastIndex += 1;

                var itemElement = item[0 + '-' + productId];
                var itemElementName;
                if (itemElement && itemElement.assetAccountNumber && itemElement.assetAccountNumber != '') {
                    itemElementName = productName + '&nbsp;(' + itemElement.assetAccountNumber + ')&nbsp;';
                } else {
                    itemElementName = result.productName;
                }
                addSubProductParameterHtml(itemElementName, dataIndex);
                addSubProductTransitionHtml(item[0 + '-' + productId], dataIndex);
                newItem = getSubProductToMigrationHTML(dataIndex, productName, migrationDefaults.temp.selectedProductId, migrationDefaults.temp.selectedIndex);
                var selectedRowId = '#' + migrationDefaults.temp.selectedRowId;
                $(selectedRowId).append(newItem);
                //addSubProductTransitionHtml(result.transitionItemMap, result.htmlElementId);
            }
            //addSubProductTransitionHtml(result.transitionItemMap, result.htmlElementId);
        });
}

function changePage(index) {
    if (configuration.pretermDocSwitch) {
        if (elDocDistVisibilityPerPage[index]) {
            $('#doc-el-distrib-agreement').show();
        } else {
            $('#doc-el-distrib-agreement').hide();
        }
    }
    elementId = '#li-node-' + index;
    // Remove mark from previouse selected product
    $('#li-node-' + migrationDefaults.selectedProduct_SelectedIndex).removeClass('chosenProduct');
    // Add mark to the currently selected product
    $(elementId).addClass('chosenProduct');

    // Hide / Show page with product relations
    $('#transition-tab-' + migrationDefaults.selectedProduct_SelectedIndex).removeClass('slds-show');
    $('#transition-tab-' + migrationDefaults.selectedProduct_SelectedIndex).addClass('slds-hide');
    $('#transition-tab-' + index).addClass('slds-show');
    $('#transition-tab-' + index).removeClass('slds-hide');

    // Hide / Show page with product parameters
    $('#item-product-param-' + migrationDefaults.selectedProduct_SelectedIndex).removeClass('slds-show');
    $('#item-product-param-' + migrationDefaults.selectedProduct_SelectedIndex).addClass('slds-hide');
    $('#item-product-param-' + index).addClass('slds-show');
    $('#item-product-param-' + index).removeClass('slds-hide');

    // Set current index to the variable
    migrationDefaults.selectedProduct_SelectedIndex = index;
}

/**
 * [getProductParameters description]
 * @param  {String} productRelId [The ID of Product_Relation__c object]
 * @param  {String} parentId     [The ID of the parent product. The id is composed from index and product ID. Example: 1-123456]
 * @param  {String} productId    [The ID Of the (current) product selected in select input]
 * @return {void}              [description]
 */
function getProductParameters(productRelId, productRelName, parentId, productId, assetId, disponentId, element) {
    console.log('1 get productPar');
    //    if(!configuration.productRelations[parentId][productId].productParameterDefaults){
    if (!configuration.savedConfiguration && !configuration.pcfUnfinished) {
        configuration.productRelations[parentId][productId].productParameterDefaults = {};
    }
    showLoadingModal();
    var sfProductId = null;
    if (productId && productId.includes('-')) {
        var prodIdParts = productId.split('-');
        sfProductId = prodIdParts[1];
    }
    Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.getProductParameters, productRelId, assetId, configuration.migrationProcessId, configuration.accountId, disponentId, sfProductId, function(result, event) {
        if (event.status) {
            if (firstLoad) {
                selectFirstFromSelectedProducts();
                firstLoad = false;
            }
            renderProductParameters(result, productRelId, productRelName, parentId, productId, assetId, true);
            dismissLoadingModal();
        }
    });
    if (element != null) {
        var currentErr = $('#transition-error-' + element.dataset.parid + '-' + element.dataset.prodid);
        if (productRelId != "0") {
            currentErr.hide();
        } else {
            currentErr.show();
        }
    }


    //    if(configuration.migrationProcessName == 'Heritage'){
    //        var sel = document.getElementById("prod_param_select_9_69");
    //        var dropDown_sel = sel.options[sel.selectedIndex].value;
    //        var errorText = document.getElementById("transition-error")
    //        if (dropDown_sel != "0") {
    //            errorText.classList.add('slds-hide-trans-error');
    //        }
    //        errorText.classList.remove('slds-hide-trans-error');
    //    }


}

function addDays(date, days) {
    var result = new Date(reformatDate(date));
    result.setDate(result.getDate() + (days * 1));
    return result;
}

function renderProductParameters(result, productRelId, productRelName, parentId, productId, assetId, changeSelectedRelation) {
    var multiSelectCreated = false;
    var html = '';
    var unselectedItems = [];
    var multiSelectPicklist = [];
    var isDatePickerRendered = false;
    var isElementReadOnly = false;

    console.log('configuration.mapOfReadOnlyProductsPerId: ', configuration.mapOfReadOnlyProductsPerId);

    if (configuration.mapOfReadOnlyProductsPerId && configuration.editMode && assetId) {
        var productObjects = JSON.parse(configuration.mapOfReadOnlyProductsPerId);
        for (var oneObject in productObjects) {
            console.log('oneObject: ', oneObject);
            console.log('assetId: ', assetId);
            if (oneObject === assetId) {
                console.log('som in');
                if (productObjects[oneObject] == false) {
                    isElementReadOnly = true;
                }
                break;
            }
        }
    }

    console.log('assetId, isElementReadOnly: ', assetId, isElementReadOnly);
    if (result.length > 0) {
        for (var i = 0; i < result.length; i++) {
            var item = result[i];
            var paramVisibilityClass = '';
            if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE || (!configuration.savedConfiguration && item.loadHidden) || (configuration.savedConfiguration && item.loadHiddenRO)) {
                paramVisibilityClass = 'migration-hide';
            }
            //                if(item.fieldAPI){
            //                    configuration.apiFields[item.productParameter.Id] = {fieldName: item.fieldAPI, value: configuration.productRelations[parentId][productId].productParameterDefaults[item.productParameter.Id].value};
            //                }
            var match = RegExp('&lt;b&gt;(.*?)&lt;/b&gt;').exec(item.productParameter.Parameter_Label__c);
            var boldStyle = configuration.migrationProcessName === 'SUFO' ? 'style="font-weight: bold;"' : '';
            if (match && match.length > 0) {
                item.productParameter.Parameter_Label__c = match[1];
                boldStyle = 'style="font-weight: bold;"';
            }
            var sectionLabelId = 'section-label-{0}'.format(item.productParameter.Id);
            var siblingConfigCount = document.querySelectorAll('[id^="' + sectionLabelId + '"]').length;
            html += '<h3 id="section-label-{2}-{4}" class="slds-text-title product-param-section-title {0}" {3}>{1}</h3>'.format(paramVisibilityClass, item.productParameter.Parameter_Label__c, item.productParameter.Id, boldStyle, siblingConfigCount);
            html += '<div id="section-data-{0}-{1}" class="slds-form--horizontal" style="text-align: left;">'.format(item.productParameter.Id, siblingConfigCount);
            for (var childItemIndex in item.childParameterList) {
                if (configuration.savedConfiguration && typeof configuration.productRelations[parentId][productId].productParameterDefaults[childItemIndex] === 'undefined') {
                    continue;
                }
                var childItem = item.childParameterList[childItemIndex];
                if ((!configuration.savedConfiguration && item.loadHidden) || (configuration.savedConfiguration && item.loadHiddenRO)) {
                    childItem.visibility.visibilityType = VISIBILITY_TYPE_HIDE;
                    childItem.visibility.visibilityCount = 0;
                }
                if (!configuration.productRelations[parentId][productId].productParameterDefaults) {
                    configuration.productRelations[parentId][productId].productParameterDefaults = {};
                }
                //console.log('childItem: ', childItem);
                //console.log('childItem.typeOfParameter: ', childItem.typeOfParameter);
                //console.log('configuration.productRelations[parentId][productId].productParameterDefaults[childItemIndex]: ', configuration.productRelations[parentId][productId].productParameterDefaults[childItemIndex]);
                var valueFromCase = configuration.productRelations[parentId][productId].productParameterDefaults[childItemIndex] ? configuration.productRelations[parentId][productId].productParameterDefaults[childItemIndex].value : null;
                if (childItem.typeOfParameter === INPUT_TYPE_SELECT || childItem.typeOfParameter === INPUT_TYPE_CALCULATED_SELECT) {
                    html += getSelectElement(childItem, parentId, item.Id, parentId, productId, i, childItemIndex, false, valueFromCase, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_SELECT_WITH_BACKGROUND_QUERY) {
                    html += getSelectElement(childItem, parentId, item.Id, parentId, productId, i, childItemIndex, true, valueFromCase, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_CHECKBOX) {
                    html += getCheckboxElement(childItem, parentId, item.productParameter.Id, parentId, productId, i, childItemIndex, valueFromCase, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_INPUT || childItem.typeOfParameter === INPUT_TYPE_FORMULA || childItem.typeOfParameter === INPUT_WITH_SOQL) {
                    html += getInputElement(childItem, parentId, item.productParameter.Id, parentId, productId, i, childItemIndex, false, valueFromCase, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_INPUT_WITH_BACKGROUND_QUERY || childItem.typeOfParameter === INPUT_TYPE_INPUT_WITH_BACKGROUND_QUERY_MULTI) {
                    html += getInputElement(childItem, parentId, item.productParameter.Id, parentId, productId, i, childItemIndex, true, valueFromCase, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_MULTI_SELECT) {
                    multiSelectCreated = true;
                    html += getMultiSelectElement(childItem, parentId, item.Id, parentId, productId, i, childItemIndex, unselectedItems, multiSelectPicklist);
                } else if (childItem.typeOfParameter === EXTERNAL_LINK) {
                    html += getExternalLinkButtonElement(childItem, parentId, item.Id, parentId, productId, i, childItemIndex, unselectedItems, multiSelectPicklist, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_DATE) {
                    //console.log('childItem: ', childItem);
                    //console.log('productRelId: ', productRelId);
                    //console.log('productRelName: ', productRelName);
                    //console.log('parentId: ', parentId);
                    //console.log('productId: ', productId);
                    //console.log('assetId: ', assetId);
                    //console.log('changeSelectedRelation: ', changeSelectedRelation);
                    html += getDateElement(childItem, parentId, item.productParameter.Id, parentId, productId, i, childItemIndex, false, valueFromCase, isElementReadOnly);
                    isDatePickerRendered = true;
                } else if (childItem.typeOfParameter === INPUT_TYPE_TEXTAREA) {
                    html += getTextAreaElement(childItem, parentId, item.productParameter.Id, parentId, productId, i, childItemIndex, false, valueFromCase, isElementReadOnly);
                } else if (childItem.typeOfParameter === INPUT_TYPE_HIDDEN) {
                    html += getHiddenElement(childItem, parentId, item.productParameter.Id, parentId, productId, i, childItemIndex, false);
                }
                if (childItem.productParameter.Required__c == true) {
                    var chids = [];
                    if (typeof childItem.childParameterList !== 'undefined' && childItem.childParameterList) {
                        var keys = Object.keys(childItem.childParameterList);
                        for (c = 0; c < keys.length; c++) {
                            if (childItem.childParameterList[keys[c]].productParameter.Required__c == true) {
                                chids.push(childItem.childParameterList[keys[c]].productParameter);
                            }
                        }
                    }
                    requiredFields.push({
                        id: parentId + '-' + productId + '-' + childItem.productParameter.Id,
                        childIds: chids,
                        label: childItem.productParameter.Parameter_Label__c
                    });
                }
                if (childItem.fieldAPI) {
                    configuration.apiFields[childItem.productParameter.Id] = {
                        fieldName: childItem.fieldAPI,
                        value: childItem.visibility.visibilityCount > 0 ? configuration.productRelations[parentId][productId].productParameterDefaults[childItem.productParameter.Id].value : '',
                        wantEncryptFields: childItem.wantEncryptFields
                    };
                }
            }
            html += '</div>';
        }
    } else {
        html = '<p>{0}</p>'.format(migrationDefaults.labels.productParametersNotFound);
    }
    if (changeSelectedRelation && configuration.productRelations && configuration.productRelations[parentId] && configuration.productRelations[parentId][productId]) {
        configuration.productRelations[parentId][productId].selectedRelationId = productRelId;
    }
    if (changeSelectedRelation) {
        var itemId = '#product-parameter-part-{0}-{1}'.format(parentId, productId);
        var elementTransitionName = $('#product-parameter-transition-{0}-{1}'.format(parentId, productId));
        var element = $(itemId);
        element.html("");
        if (isDatePickerRendered && !configuration.savedConfiguration) {
            element.css('min-height', '405px');
        }
        element.append(html);
        elementTransitionName.html('');
        elementTransitionName.append(productRelName);

        for (var dpindex = 0; dpindex < migrationDefaults.listDatapicker.length; dpindex++) {
            //console.log('jeden dtae picker data: ' , migrationDefaults.listDatapicker[dpindex]);
            let maxDate = migrationDefaults.listDatapicker[dpindex].maxDate;
            let minDate = migrationDefaults.listDatapicker[dpindex].minDate;
            //console.log('minDate: ', minDate);
            //console.log('maxDate: ', maxDate);
            $('#' + migrationDefaults.listDatapicker[dpindex].id).datepicker({
                //initDate: moment(), //Today Date
                format: 'DD.MM.YYYY', //Date Format Of Datepicker Input Field
                numYearsBefore: 15,
                numYearsAfter: 5,
                maxDateInstance: maxDate,
                minDateInstance: minDate,
                onChange: function(datepicker) {
                    var idsElement = getDatepickerIdsElement(datepicker.$el[0].id);
                    changeProductParameterValue(idsElement.parId, idsElement.prodId, idsElement.ppId, datepicker.$el.val(), null, null, idsElement.syncElement); //
                    //handleBagettaElement(null, idsElement.syncElement, datepicker.$el.val());
                },
                dayLabels: [{
                        full: 'Pondělí',
                        abbv: 'Po'
                    },
                    {
                        full: 'Úterý',
                        abbv: 'Út'
                    },
                    {
                        full: 'Středa',
                        abbv: 'St'
                    },
                    {
                        full: 'Čtvrtek',
                        abbv: 'Čt'
                    },
                    {
                        full: 'Pátek',
                        abbv: 'Pá'
                    },
                    {
                        full: 'Sobota',
                        abbv: 'So'
                    },
                    {
                        full: 'Neděle',
                        abbv: 'Ne'
                    }
                ],

                monthLabels: [{
                        full: 'Leden',
                        abbv: 'Le'
                    },
                    {
                        full: 'Únor',
                        abbv: 'Ún'
                    },
                    {
                        full: 'Březen',
                        abbv: 'Bř'
                    },
                    {
                        full: 'Duben',
                        abbv: 'Du'
                    },
                    {
                        full: 'Květen',
                        abbv: 'Kv'
                    },
                    {
                        full: 'Červen',
                        abbv: 'Če'
                    },
                    {
                        full: 'Červenec',
                        abbv: 'Čc'
                    },
                    {
                        full: 'Srpen',
                        abbv: 'Sr'
                    },
                    {
                        full: 'Září',
                        abbv: 'Zá'
                    },
                    {
                        full: 'Říjen',
                        abbv: 'Ří'
                    },
                    {
                        full: 'Listopad',
                        abbv: 'Li'
                    },
                    {
                        full: 'Prosinec',
                        abbv: 'Pr'
                    }
                ]
            });

        }
    }
    if (multiSelectCreated) {
        var selectedItems = [];
        multiSelectPicklist.forEach(function(item) {
            var allValues = item.values;
            item.values = removeSelectedItemsFromUnselected(item.selectedItems, item.values);
            $('[data-aljs="{0}"]'.format(item.id)).multiSelect({
                unselectedItems: item.values,
                selectedItems: item.selectedItems ? item.selectedItems : selectedItems,
            });

            // Removing element/s from selected array
            var idLeftElement = "#{0}".format(item.leftButtonId);
            $(idLeftElement).on("click", item, changeMultiPicklistValue);
            var idLeftAllElement = "#{0}".format(item.leftAllButtonId);
            $(idLeftAllElement).on("click", {
                id: item.id,
                values: allValues
            }, removeAllMultiPicklist);

            // Adding element/s to selected array
            var idRightElement = "#{0}".format(item.rightButtonId);
            $(idRightElement).on("click", item, changeMultiPicklistValue);
            var idRightAllElement = "#{0}".format(item.rightAllButtonId);
            $(idRightAllElement).on("click", {
                id: item.id,
                values: allValues
            }, addAllMultiPicklist);
        });
    }
    setL1VisibilityBasedOnParameterPresence();
    if (configuration.savedConfiguration) {
        callCheckDepFuture();
        $("#doc-el-distrib-select").attr("disabled", "disabled");
        if ($('[data-doc-dist-agreement] option:selected').text().toLowerCase().indexOf("ne") === -1) {
            $('#doc-el-distrib-select').val('ok');
        } else {
            $('#doc-el-distrib-select').val('nok');
        }
    }
    if (configuration.savedConfiguration && configuration.elDistribAgreementValue === false) {
        $('#doc-el-distrib-select').val('nok');
    }
    if (cleavesList.length > 0 && !configuration.savedConfiguration) {
        for (var i = cleaveIndex; i < cleavesList.length; i++) {
            window[cleavesList[i].name] = new Cleave('.' + cleavesList[i].name.trim(), cleavesList[i].data);
        }
        cleaveIndex = cleavesList.length;
    }

    $(".cleave-param").focusout(function() {
        var $inp = $(this);
        changeProductParameterValue($inp.attr("data-parentId"), $inp.attr("data-productId"), $inp.attr("data-inputId"), $inp.val(), null, null, $inp.attr("data-syncElemName"));
    });

    if (!configuration.savedConfiguration) {
        var idParts = parentId.split('-');
        var pageId = idParts[0];
        setElDocDistAgrSelectVisibility(pageId);

        /*if(configuration.migrationProcessName === 'Mobility_income') {
            var bagettaElements = $('[data-syncElemName^="bagetta_"]');
            for (var i = 0; i < bagettaElements.length; i++) {
                handleBagettaElement(bagettaElements[i], bagettaElements[i].dataset.syncelemname);
            }
            calculateBagettaDate();
        }*/
    }
}

/*function handleBagettaElement(element, syncElemName, val) {
    if (configuration.migrationProcessName === 'Mobility_income' && syncElemName.startsWith('bagetta_')) {
        if (element) {
            if (syncElemName.endsWith('effectiveDate')) {
                element.addEventListener("change", calculateBagettaCancDate);
            } else {
                element.addEventListener("change", calculateBagettaDate);
            }
        } else {
            if (syncElemName.endsWith('effectiveDate')) {
                calculateBagettaCancDate();
            } else {
                calculateBagettaDate();
            }
        }
    }
}*/

function removeSelectedItemsFromUnselected(selectedItems, unselectedItems) {
    for (selectedItemIndex in selectedItems) {
        var selectedItem = selectedItems[selectedItemIndex];
        var removeItemAtIndex;
        for (unselectedItemIndex in unselectedItems) {
            var unselectedItem = unselectedItems[unselectedItemIndex];
            if (selectedItem.id == unselectedItem.id) {
                removeItemAtIndex = unselectedItemIndex;
                break;
            }
        }
        unselectedItems.splice(removeItemAtIndex, 1);
    }
    return unselectedItems;
}

function changeMultiPicklistValue(item) {
    var data = item.data;
    changeProductParameterMultiValue(data.parentId, data.productId, data.selectIndexId, $('[data-aljs="{0}"]'.format(data.id)).multiSelect('SelectedItems'));
}

function addAllMultiPicklist(data) {
    data = data.data;
    $('[data-aljs="{0}"]'.format(data.id)).multiSelect({
        unselectedItems: [],
        selectedItems: data.values,
    });
}

function removeAllMultiPicklist(data) {
    data = data.data;
    $('[data-aljs="{0}"]'.format(data.id)).multiSelect({
        unselectedItems: data.values,
        selectedItems: [],
    });
}

/**
 * [getSelectElement description]
 * @param  {ProductParameterWrapper} item [For the structure of this object refer to the object difinition in MigrationPremiumController. Lx__c == L2]
 * @param  {String} parentId              ID of the parent product element. Example {index}-{product.ID}
 * @param  {String} sectionParamId        Id of the section (ID of the Product_Parameter__c which representing the section on the page)
 * @return {[type]}      [description]
 */
function getSelectElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, selectIndexId, hasBackgroundQuery, valueFromCase, isElementReadOnly) {
    var paramVisibilityClass = '';
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }
    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-selectIndexId="{0}" '.format(selectIndexId);
    dataAttributes += 'data-inputId="{0}" '.format(selectIndexId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-hasBackgroundQuery="{0}" '.format(hasBackgroundQuery);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-syncElemName="{0}" '.format(item.productParameter.Sync_Element_Name__c);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');
    if (item.productParameter.Csv_Export_Column__c) {
        dataAttributes += 'data-csvExportColumn="{0}" '.format(item.productParameter.Csv_Export_Column__c);
    }
    if (item.productParameter.Show_ElDistrib_Agreement__c) {
        dataAttributes += 'data-insurance="1" ';
        var idParts = parentId.split('-');
        var pageId = idParts[0];
        if (!elDocDistVisibilityPerPage[pageId]) {
            elDocDistVisibilityPerPage[pageId] = false;
        }
    }
    var exDataAttr = '';
    var agrDataAttr = '';
    var agrFnc = '';
    if (typeof(item.productParameter.ISTS_Element_Name__c) != 'undefined' && item.productParameter.ISTS_Element_Name__c != null) {
        if (item.productParameter.ISTS_Element_Name__c.startsWith('exceptionGeneration')) {
            exDataAttr = 'data-exceptionGen-type="';
        }
        if (item.productParameter.ISTS_Element_Name__c.startsWith('docDistAgreement')) {
            dataAttributes += 'data-doc-dist-agreement="1" ';
            agrFnc = 'propagateDocElDistribAgreement(this);';
        }
    }

    var syblings = '';
    if (item.productParameter.Syblings__r) {
        for (var i = 0; i < item.productParameter.Syblings__r.length; i++) {
            syblings += item.productParameter.Syblings__r[i].Id + ' ';
        }
        syblings = syblings.substring(0, syblings.length - 1);
    }

    var dda = '';
    if (item.productParameter.Show_ElDistrib_Agreement__c) {
        dda = ' dda';
    }

    var helpTextElement = '';
    if (item.productParameter.Help_Text__c) {
        helpTextElement = getHelpTextSpan(item.productParameter.Help_Text__c);
    }
    var productConfiguration = configuration.productRelations[parentId][productId];
    var disabledHtml = isElementReadOnly || configuration.savedConfiguration || item.productParameter.Is_Read_Only__c === true ? 'disabled' : '';
    var html = '';
    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    var req = '';
    if (item.productParameter.Required__c) {
        req = '<span style="color: red; font-weight: bold; font-size: 17px;">|&nbsp;</span>';
    }
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    html += '<label class="slds-form-element__label" for="prod_param_1_17" style="inline-block;">{2}{0}{1}</label>'.format(item.productParameter.Parameter_Label__c, helpTextElement, req);
    html += '<div class="slds-form-element__control">';
    var composedSelectId = parentId + '-' + productId + '-' + item.productParameter.Id;
    var defaultValueFromParent = $('[data-syblings~="' + item.productParameter.Id + '"').find('option:selected').text();

    if (item.hasDependencies) {
        html += '<select {0} id="{1}" class="slds-select{12}" style="width: 30%;" onchange="changeProductParameterValue(\'{2}\', \'{3}\', \'{4}\', {5}, null, null, \'{14}\');changeEnhancedProductParameterValue(\'{2}\', \'{3}\', \'{4}\', \'{1}\');propagateSyblingTextValue(\'{13}\', this);checkDependencies(\'{6}\', \'{7}\', \'{8}\',this, {9});{11}" {10} data-syblings="{13}">'
            .format(disabledHtml, composedSelectId, parentId, productId, selectIndexId, 'this.value', item.productParameter.Id, parentId, productId, hasBackgroundQuery, dataAttributes, agrFnc, dda, syblings, item.productParameter.Sync_Element_Name__c);
        checkDepFutureList.push({
            parentProductParameter: item.productParameter.Id,
            parentProductId: parentId,
            productId: productId,
            selectObject: '#' + composedSelectId,
            hasBackgroundQuery: hasBackgroundQuery
        });
    } else {
        html += '<select {0} id="{1}" class="slds-select{8}" style="width: 30%;" onchange="changeProductParameterValue(\'{2}\', \'{3}\', \'{4}\', {5}, null, null, \'{11}\');changeEnhancedProductParameterValue(\'{2}\', \'{3}\', \'{4}\', \'{1}\');propagateSyblingTextValue(\'{9}\', this);" {7} {6} data-syblings="{9}">'
            .format(disabledHtml, composedSelectId, parentId, productId, selectIndexId, 'this.value', dataAttributes, agrFnc, dda, syblings, defaultValueFromParent, item.productParameter.Sync_Element_Name__c);
    }
    var isFirst = true;
    var valueFilled = false;
    for (childItemIndex in item.childParameterList) {
        var childItem = item.childParameterList[childItemIndex];
        var productParameterId = childItem.productParameter.Id ? childItem.productParameter.Id : childItem.idOfParameter;
        var curExDataAttr = '';
        var productDataAttr = '';
        if (exDataAttr != '') {
            curExDataAttr = exDataAttr + childItem.productParameter.String_Value__c + '"';
        }
        if (childItem.productParameter.Product__c && childItem.productParameter.Product__r.CST_Value_ID__c) {
            //console.log('*** There is a PP with defined Product: ', childItem.productParameter.Parameter_Label__c + ':', childItem.productParameter.Product__r.CST_Value_ID__c);
            productDataAttr += 'data-product-cst-value-id="' + childItem.productParameter.Product__r.CST_Value_ID__c + '"';
            productDataAttr += ' data-product-name="' + childItem.productParameter.Product__r.Name + '"';
        }
        if (childItem.productParameter.Sync_Element_Name__c == 'mobilita_callId_signMethod') {
            productDataAttr += ' data-sign-method-callid="1"';
        }
        if (childItem.productParameter.Sync_Element_Name__c == 'mobilita_courier_signMethod') {
            productDataAttr += ' data-sign-method-courier="1"';
        }
        if (item.productParameter.Csv_Export_Column__c && childItem.productParameter.String_Value__c) {
            productDataAttr += ' data-string-value="{0}"'.format(childItem.productParameter.String_Value__c);
        }
        if (isFirst && !configuration.savedConfiguration) {
            changeProductParameterValue(parentId, productId, selectIndexId, productParameterId, item.defaultValueFromAsset, null, item.productParameter.Sync_Element_Name__c);
        }
        if (item.productParameter.Sync_Element_Name__c === 'SettlementType') {
            console.log('test');
        }
        if (configuration.savedConfiguration &&
            productConfiguration.productParameterDefaults &&
            productConfiguration.productParameterDefaults[selectIndexId] &&
            productConfiguration.productParameterDefaults[selectIndexId].value == productParameterId) {
            html += '<option value="{0}" selected="" {2}>{1}</option>'.format(productParameterId, childItem.productParameter.Parameter_Label__c, productDataAttr);
            if (configuration.migrationProcessName === 'Account_Cancellation') {
                callCheckDependencies(item.productParameter.Id, parentId, productId, childItem.productParameter.Parameter_Label__c, valueFromCase, hasBackgroundQuery, false);
            }
            //changeProductParameterValue(parentId, productId, selectIndexId, productParameterId, valueFromCase,null, item.productParameter.Sync_Element_Name__c);
        } else if (!configuration.savedConfiguration && !configuration.pcfUnfinished && item.defaultValueFromAsset && item.defaultValueFromAsset == childItem.productParameter.Parameter_Label__c) {
            html += '<option value="{0}" selected="" {2} {3}>{1}</option>'.format(productParameterId, childItem.productParameter.Parameter_Label__c, curExDataAttr, productDataAttr);
            changeProductParameterValue(parentId, productId, selectIndexId, childItem.productParameter.Id, item.defaultValueFromAsset, null, item.productParameter.Sync_Element_Name__c);
        } else if (configuration.pcfUnfinished && valueFromCase && valueFromCase == productParameterId) {
            html += '<option value="{0}" selected="" {2} {3}>{1}</option>'.format(productParameterId, childItem.productParameter.Parameter_Label__c, curExDataAttr, productDataAttr);
            changeProductParameterValue(parentId, productId, selectIndexId, productParameterId, null, null, item.productParameter.Sync_Element_Name__c);
            callCheckDependencies(item.productParameter.Id, parentId, productId, childItem.productParameter.Parameter_Label__c, valueFromCase, hasBackgroundQuery, false);
            valueFilled = true;
        } else {
            var selectedHtml = childItem.productParameter.Is_Default__c && !configuration.savedConfiguration && (!configuration.pcfUnfinished || !valueFromCase) ? 'selected="selected"' : '';
            var valueFromParentFilled = defaultValueFromParent == childItem.productParameter.Parameter_Label__c && !configuration.savedConfiguration && (!configuration.pcfUnfinished || !configuration.productRelations[parentId][productId]) ? 'selected="selected"' : '';
            var selectedAttr = defaultValueFromParent ? valueFromParentFilled : selectedHtml;
            if ((selectedAttr || isFirst) && item.productParameter.Show_ElDistrib_Agreement__c && childItem.productParameter.Parameter_Label__c.toLowerCase() != 'žádné') {
                var idParts = parentId.split('-');
                var pageId = idParts[0];
                elDocDistVisibilityPerPage[pageId] = true;
            }
            html += '<option {0} value="{1}" {3} {4}>{2}</option>'.format(selectedAttr, productParameterId, childItem.productParameter.Parameter_Label__c, curExDataAttr, productDataAttr);
            if (childItem.productParameter.Is_Default__c && !valueFilled && !configuration.savedConfiguration || (valueFromParentFilled && !configuration.productRelations[parentId][productId])) {
                changeProductParameterValue(parentId, productId, selectIndexId, productParameterId, null, null, item.productParameter.Sync_Element_Name__c);
            }
            if (item.visibility.visibilityType != VISIBILITY_TYPE_HIDE && valueFromParentFilled) {
                changeEnhancedProductParameterValue(parentId, productId, selectIndexId, null, defaultValueFromParent);
                callCheckDependencies(item.productParameter.Id, parentId, productId, childItem.productParameter.Parameter_Label__c, productParameterId, hasBackgroundQuery, false);
            }
        }
        isFirst = false;
    }

    html += '</select>';
    html += '</div>';
    html += '</div>';

    return html;
}

function getMultiSelectElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, selectIndexId, unselectedItems, multiSelectPicklist) {
    var paramVisibilityClass = '';
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }
    for (childItemIndex in item.childParameterList) {
        var childItem = item.childParameterList[childItemIndex];
        var productParameterId = childItem.productParameter.Id ? childItem.productParameter.Id : childItem.idOfParameter;
        var representativeItem = {};
        representativeItem.id = productParameterId;
        representativeItem.label = childItem.productParameter.Parameter_Label__c;
        unselectedItems.push(representativeItem);
    }
    var rightButtonId = "select-multi-right_{0}-{1}-{2}".format(parentId, productId, selectIndexId);
    var rightAllButtonId = "select-multi-right-all_{0}-{1}-{2}".format(parentId, productId, selectIndexId);
    var leftButtonId = "select-multi-left_{0}-{1}-{2}".format(parentId, productId, selectIndexId);
    var leftAllButtonId = "select-multi-left-all_{0}-{1}-{2}".format(parentId, productId, selectIndexId);
    var productConfiguration = configuration.productRelations[parentId][productId];
    var html = '';
    html += '<div class="slds-form-element">';
    html += '<div class="slds-picklist--draggable slds-grid" data-aljs="multi-select_{0}-{1}-{2}" style="float: right">'.format(parentId, productId, selectIndexId);
    html += '<div class="slds-form-element">';
    html += '<span class="slds-form-element__label" aria-label="select-1">Možné hodnoty</span>';
    html += '<div class="slds-picklist slds-picklist--multi" data-aljs-multi-select="unselected">';
    html += '<ul class="slds-picklist__options slds-picklist__options--multi shown"></ul>';
    html += '</div>';
    html += '</div>';
    html += '<div class="slds-grid slds-grid--vertical">';

    if (configuration.savedConfiguration) {
        html += '<button disabled class="slds-button slds-button--icon-container" data-aljs-multi-select="select" onClick="return false;" id="{0}">'.format(rightButtonId);
    } else {
        html += '<button class="slds-button slds-button--icon-container" data-aljs-multi-select="select" onClick="return false;" id="{0}">'.format(rightButtonId);
    }
    html += '<img src="{0}" class="multi-select__img"/>'.format(migrationDefaults.images.right);
    html += '<span class="slds-assistive-text">Pick list</span>';
    html += '</button>';

    if (configuration.savedConfiguration) {
        html += '<button disabled class="slds-button slds-button--icon-container" data-aljs-multi-select="selectAll" onClick="return false;" id="{0}">'.format(rightAllButtonId);
    } else {
        html += '<button class="slds-button slds-button--icon-container" data-aljs-multi-select="selectAll" onClick="return false;" id="{0}">'.format(rightAllButtonId);
    }
    html += '<img src="{0}" class="multi-select__img"/>'.format(migrationDefaults.images.selectAll);
    html += '<span class="slds-assistive-text">Pick list</span>';
    html += '</button>';


    if (configuration.savedConfiguration) {
        html += '<button disabled class="slds-button slds-button--icon-container" data-aljs-multi-select="unselect" onClick="return false;" id="{0}">'.format(leftButtonId);
    } else {
        html += '<button class="slds-button slds-button--icon-container" data-aljs-multi-select="unselect" onClick="return false;" id="{0}">'.format(leftButtonId);
    }
    html += '<img src="{0}" class="multi-select__img"/>'.format(migrationDefaults.images.left);
    html += '<span class="slds-assistive-text">Pick list</span>';
    html += '</button>';

    if (configuration.savedConfiguration) {
        html += '<button disabled class="slds-button slds-button--icon-container" data-aljs-multi-select="unselectAll" onClick="return false;" id="{0}">'.format(leftAllButtonId);
    } else {
        html += '<button class="slds-button slds-button--icon-container" data-aljs-multi-select="unselectAll" onClick="return false;" id="{0}">'.format(leftAllButtonId);
    }
    html += '<img src="{0}" class="multi-select__img"/>'.format(migrationDefaults.images.deselectAll);
    html += '<span class="slds-assistive-text">Pick list</span>';
    html += '</button>';


    html += '</div>';
    html += '<div class="slds-form-element">';
    html += '<span class="slds-form-element__label" aria-label="select-2">Vybrané hodnoty</span>';
    html += '<div class="slds-picklist slds-picklist--multi" data-aljs-multi-select="selected">';
    html += '<ul class="slds-picklist__options slds-picklist__options--multi shown"></ul>';
    html += '</div>';
    html += '</div>';
    /*html +=         '<div class="slds-grid slds-grid--vertical">';
    html +=             '<button class="slds-button slds-button--icon-container" data-aljs-multi-select="move-up" onClick="return false;">';
    html +=                 '<img src="{0}" class="multi-select__img"/>'.format(migrationDefaults.images.up);
    html +=                 '<span class="slds-assistive-text">Pick list</span>';
    html +=             '</button>';
    html +=             '<button class="slds-button slds-button--icon-container" data-aljs-multi-select="move-down" onClick="return false;">';
    html +=                 '<img src="{0}" class="multi-select__img"/>'.format(migrationDefaults.images.down);
    html +=                 '<span class="slds-assistive-text">Pick list</span>';
    html +=             '</button>';
    html +=         '</div>';*/
    html += '</div>';
    html += '</div>';
    var selectedItems;
    if (configuration.savedConfiguration && productConfiguration.productParameterDefaults &&
        productConfiguration.productParameterDefaults[selectIndexId].multiValue) {
        selectedItems = productConfiguration.productParameterDefaults[selectIndexId].multiValue;
    }
    multiSelectPicklist.push({
        id: 'multi-select_{0}-{1}-{2}'.format(parentId, productId, selectIndexId),
        leftButtonId: leftButtonId,
        rightButtonId: rightButtonId,
        leftAllButtonId: leftAllButtonId,
        rightAllButtonId: rightAllButtonId,
        values: unselectedItems,
        parentId: parentId,
        productId: productId,
        selectIndexId: selectIndexId,
        selectedItems: selectedItems,
    });
    changeProductParameterMultiValue(parentId, productId, selectIndexId, null);
    return html;
}

/**
 * [getCheckboxElement description]
 * @param  {String} parentId              ID of the parent product element. Example {index}-{product.ID}
 * @param  {String} sectionParamId        Id of the section (ID of the Product_Parameter__c which representing the section on the page)
 * @return {[type]}      [description]
 */
function getCheckboxElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, checkboxId, valueFromCase, isElementReadOnly) {
    var productConfiguration = configuration.productRelations[parentId][productId];
    var disabledHtml = isElementReadOnly || configuration.savedConfiguration || item.productParameter.Is_Read_Only__c === true ? 'disabled' : '';
    var html = '';
    var paramVisibilityClass = '';
    var paramVisibilityAtribute = '';
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }
    var helpTextElement = '';
    if (item.productParameter.Help_Text__c) {
        helpTextElement = getHelpTextSpan(item.productParameter.Help_Text__c);
    }

    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-inputId="{0}" '.format(checkboxId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');
    dataAttributes += 'data-syncElemName="{0}" '.format(item.productParameter.Sync_Element_Name__c);
    if (item.productParameter.Csv_Export_Column__c) {
        dataAttributes += 'data-csvExportColumn="{0}" '.format(item.productParameter.Csv_Export_Column__c);
    }
    if (typeof(item.productParameter.ISTS_Element_Name__c) != 'undefined' && item.productParameter.ISTS_Element_Name__c != null && item.productParameter.ISTS_Element_Name__c.startsWith('exceptionGeneration')) {
        dataAttributes += 'data-exceptionGen-checkbox="1"';
    }
    if (typeof(item.productParameter.Priority_SUFO__c) != 'undefined' && item.productParameter.Priority_SUFO__c != null) {
        dataAttributes += 'data-prioritysufo="{0}"'.format(item.productParameter.Priority_SUFO__c);
    }

    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    var match = RegExp('&lt;b&gt;(.*?)&lt;/b&gt;').exec(item.productParameter.Parameter_Label__c);
    var boldClass = '';
    if (match && match.length > 0) {
        item.productParameter.Parameter_Label__c = match[1];
        boldClass = 'bold-class';
    }
    html += '<label class="slds-form-element__label {2}" for="prod_param_1_17" style="inline-block">{0}{1}</label>'.format(item.productParameter.Parameter_Label__c, helpTextElement, boldClass);
    html += '<div class="slds-form-element__control">';
    html += '<div class="switcher">';

    if (configuration.savedConfiguration) {
        var checked = false;
        if (productConfiguration.productParameterDefaults && productConfiguration.productParameterDefaults[checkboxId] && productConfiguration.productParameterDefaults[checkboxId].value) {
            checked = true;
        }
        var checkedHtml = checked ? 'checked' : '';
        html += '<input id="{0}-{1}-{2}" disabled="" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{9}\');" {8} {7}>'
            .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', checkedHtml, dataAttributes, item.productParameter.Sync_Element_Name__c);
        callCheckDependencies(item.productParameter.Id, parentId, productId, checked, null, false, false);
    } else if (configuration.pcfUnfinished && valueFromCase != null) {
        checkedHtml = valueFromCase ? 'checked' : '';
        if (item.hasDependencies) {
            html += '<input id="{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{14}\');checkDependencies(\'{7}\', \'{8}\', \'{9}\',this, {10});" {13} {11} {12}>'
                .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', item.productParameter.Id, parentId, productId, false, checkedHtml, disabledHtml, dataAttributes, item.productParameter.Sync_Element_Name__c);
        } else {
            html += '<input id="{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{10}\');" {9} {7} {8}>'
                .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', checkedHtml, disabledHtml, dataAttributes, item.productParameter.Sync_Element_Name__c);
        }
        callCheckDependencies(item.productParameter.Id, parentId, productId, valueFromCase, null, false, false);
    } else if (item.visibility.visibilityType === VISIBILITY_TYPE_DISABLE) {
        if (item.hasDependencies) {
            html += '<input id="{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{12}\');checkDependencies(\'{7}\', \'{8}\', \'{9}\',this, {10});" {11} disabled>'
                .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', item.productParameter.Id, parentId, productId, false, dataAttributes, item.productParameter.Sync_Element_Name__c);
        } else {
            html += '<input id="{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{8}\');" {7} disabled>'
                .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', dataAttributes, item.productParameter.Sync_Element_Name__c);
        }
        changeProductParameterValue(parentId, productId, checkboxId, false, null, item.productParameter.Is_For_Final_Validation__c, item.productParameter.Sync_Element_Name__c);
    } else /*(!configuration.savedConfiguration)*/ {
        var checkedHtml = item.productParameter.Value__c == 1 ? 'checked' : item.defaultValueFromAsset == 'true' ? 'checked' : '';
        if (item.hasDependencies) {
            html += '<input id="{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{14}\');checkDependencies(\'{7}\', \'{8}\', \'{9}\',this, \'{10}\');" {13} {11} {12}>'
                .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', item.productParameter.Id, parentId, productId, false, checkedHtml, disabledHtml, dataAttributes, item.productParameter.Sync_Element_Name__c);
        } else {
            html += '<input id="{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6}, null, null, \'{10}\');" {9} {7} {8}>'
                .format(parentId, productId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked', checkedHtml, disabledHtml, dataAttributes, item.productParameter.Sync_Element_Name__c);
        }
        changeProductParameterValue(parentId, productId, checkboxId, item.productParameter.Value__c == 1, null, item.productParameter.Is_For_Final_Validation__c, item.productParameter.Sync_Element_Name__c);
    }
    /*else{
            html +=             '<input id="checkbox-{0}-{1}-{2}" class="slds-checkbox tgl tgl-light" type="checkbox" name="options" style="align:right;" onclick="changeProductParameterValue(\'{3}\', \'{4}\', \'{5}\', {6});">'
                                    .format(parentId, sectionParamId, item.productParameter.Id, parentId, productId, checkboxId, 'this.checked');
            changeProductParameterValue(parentId, productId, checkboxId, false);
        }*/
    html += '<label class="slds-form-element__static tgl-btn" for="{0}-{1}-{2}"></label>'.format(parentId, productId, item.productParameter.Id);
    html += '</div>';
    html += '</div>';
    html += '</div>';
    return html;
}
//date picker element
function getDateElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, inputId, hasBackgroundQuery, valueFromCase, isElementReadOnly) {
    var dateValue;
    var paramVisibilityClass = '';
    var productConfiguration = configuration.productRelations[parentId][productId];
    //console.log('ITEM: ' , item);
    if (item.productParameter.String_Value__c) {
        dateValue = item.productParameter.String_Value__c;
        if (dateValue.toLowerCase() == 'today') {
            var todaysDate = new Date();
            dateValue = ('0' + todaysDate.getDate()).slice(-2) + '.' + ('0' + (todaysDate.getMonth() + 1)).slice(-2) + '.' + todaysDate.getFullYear();
        }
    }
    //    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE &&
    //        !(configuration.savedConfiguration &&
    //            productConfiguration.productParameterDefaults &&
    //            productConfiguration.productParameterDefaults[inputId] &&
    //            productConfiguration.productParameterDefaults[inputId].value)) {
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }
    var disabledHtml;
    if (isElementReadOnly || configuration.savedConfiguration || item.productParameter.Is_Read_Only__c === true || item.visibility.visibilityType === VISIBILITY_TYPE_DISABLE) {
        disabledHtml = 'disabled';
    } else {
        disabledHtml = '';
    }
    var helpTextElement = '';
    if (item.productParameter.Help_Text__c) {
        helpTextElement = getHelpTextSpan(item.productParameter.Help_Text__c);
    }

    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-inputId="{0}" '.format(inputId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-hasBackgroundQuery="{0}" '.format(hasBackgroundQuery);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');
    dataAttributes += 'data-syncElemName="{0}" '.format(item.productParameter.Sync_Element_Name__c);
    if (item.productParameter.Csv_Export_Column__c) {
        dataAttributes += 'data-csvExportColumn="{0}" '.format(item.productParameter.Csv_Export_Column__c);
    }
    if (typeof(item.productParameter.ISTS_Element_Name__c) != 'undefined' && item.productParameter.ISTS_Element_Name__c != null && item.productParameter.ISTS_Element_Name__c.startsWith('exceptionGeneration')) {
        dataAttributes += 'data-exceptionGen-date="1"';
    }
    var cleave = '';
    if (typeof item.productParameter.Cleave_Type__c !== 'undefined' && typeof item.productParameter.Cleave_Data__c !== 'undefined') {
        cleave = ' cleave-' + item.productParameter.Cleave_Type__c.toLowerCase() + '-' + cleavesList.length;
        cleavesList.push({
            name: cleave,
            data: JSON.parse($('<textarea />').html(item.productParameter.Cleave_Data__c).text())
        });
        cleave += ' cleave-param';
    }

    var req = '';
    if (item.productParameter.Required__c) {
        req = '<span style="color: red; font-weight: bold; font-size: 17px;">|&nbsp;</span>';
    }
    var html = '';
    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    html += '<label class="slds-form-element__label" for="prod_param_1_17" style="inline-block">{2}{0}{1}</label>'.format(item.productParameter.Parameter_Label__c, helpTextElement, req);
    html += '<div class="slds-form-element__control">';
    var composedDateId = parentId + '-' + productId + '-' + item.productParameter.Id;
    if (configuration.savedConfiguration && productConfiguration.productParameterDefaults &&
        productConfiguration.productParameterDefaults[inputId].value &&
        (productConfiguration.productParameterDefaults[inputId].value || productConfiguration.productParameterDefaults[inputId].value == '')) {
        html += '<input id="{6}" disabled="" onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, null, null, \'{7}\');" type="Date" class="slds-input" value="{4}" {5}/>'
            .format(parentId, productId, inputId, 'this.value', reformatDate(productConfiguration.productParameterDefaults[inputId].value), dataAttributes, composedDateId, item.productParameter.Sync_Element_Name__c);

        if (hasBackgroundQuery && productConfiguration.productParameterDefaults[inputId].value) {
            callCheckDependencies(item.productParameter.Id, parentId, productId, productConfiguration.productParameterDefaults[inputId].value, null, true, false);
        }
    } else if (configuration.pcfUnfinished && valueFromCase != null) {
        if (typeof item.productParameter.Min__c !== 'undefined' && typeof item.productParameter.Max__c !== 'undefined') {
            html += '<div class="slds-form-element"><input onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3});" type="text" class="slds-input{10}" value="{4}" {5} id="{6}-{7}-{8}" {9}/></div>'
                .format(parentId, productId, inputId, 'this.value', valueFromCase, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, cleave);
            changeProductParameterValue(parentId, productId, inputId, valueFromCase, '');
        } else {
            html += '<div class="slds-form-element"><input onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3});" type="text" class="slds-input{10}" value="{4}" {5} id="{6}-{7}-{8}" {9}/></div>'
                .format(parentId, productId, inputId, 'this.value', valueFromCase, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, cleave);
            changeProductParameterValue(parentId, productId, inputId, valueFromCase, item.defaultValueFromAsset);
        }
        datePickerPush("{0}-{1}-{2}".format(parentId, productId, item.productParameter.Id),
            parentId, productId, inputId,
            item.productParameter.Id,
            item.productParameter.Sync_Element_Name__c,
            item.productParameter.Min__c,
            item.productParameter.Max__c,
            valueFromCase);

    } else if (dateValue || item.defaultValueFromAsset) {
        if (typeof item.productParameter.Min__c !== 'undefined' && typeof item.productParameter.Max__c !== 'undefined') {
            html += '<div class="slds-form-element"><input onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3});" type="text" class="slds-input{10}" value="{4}" {5} id="{6}-{7}-{8}" {9}/></div>'
                .format(parentId, productId, inputId, 'this.value', '', disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, cleave);
            changeProductParameterValue(parentId, productId, inputId, '', '');
        } else {
            html += '<div class="slds-form-element"><input onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3});" type="text" class="slds-input{10}" value="{4}" {5} id="{6}-{7}-{8}" {9}/></div>'
                .format(parentId, productId, inputId, 'this.value', item.defaultValueFromAsset ? item.defaultValueFromAsset : dateValue, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, cleave);
            changeProductParameterValue(parentId, productId, inputId, item.defaultValueFromAsset ? item.defaultValueFromAsset : dateValue, item.defaultValueFromAsset);
        }
        datePickerPush("{0}-{1}-{2}".format(parentId, productId, item.productParameter.Id),
            parentId, productId, inputId,
            item.productParameter.Id,
            item.productParameter.Sync_Element_Name__c,
            item.productParameter.Min__c,
            item.productParameter.Max__c,
            item.defaultValueFromAsset ? item.defaultValueFromAsset : dateValue);
    } else {
        html += '<div class="slds-form-element"><input type="text" onChange="changeProductParameterValue(\'{1}\', \'{2}\', \'{5}\', {6})" class="slds-input{7}" {0} id="{1}-{2}-{3}" {4}/></div>'
            .format(disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, inputId, 'this.value', cleave);
        changeProductParameterValue(parentId, productId, inputId, '');

        datePickerPush("{0}-{1}-{2}".format(parentId, productId, item.productParameter.Id),
            parentId, productId, inputId,
            item.productParameter.Id,
            item.productParameter.Sync_Element_Name__c,
            item.productParameter.Min__c,
            item.productParameter.Max__c,
            null);
    }
    html += '</div>';
    html += '</div>';
    return html;
}

function datePickerPush(id, parentId, productId, inputId, ppId, syncElement, minDate, maxDate, defValue) {
    var newDate = new Date();
    //console.log('newDate: ' , newDate);
    var actualHours = newDate.getHours();
    var actualMinutes = newDate.getMinutes();
    var createdDateString = newDate.getDate() + '.' + (newDate.getMonth() + 1) + '.' + newDate.getFullYear();
    maxDate = maxDate != null ? addDays(createdDateString, maxDate) : null;
    minDate = minDate != null ? addDays(createdDateString, minDate) : null;
    if (parentId != 'GENERAL' && minDate != null && configuration.migrationProcessName === 'Account_Cancellation') {
        var hasCardSubProduct = false;
        Object.keys(configuration.productList.itemMap[parentId].childItemMap).forEach(function(child) {
            if (configuration.productList.itemMap[parentId].childItemMap[child].theAsset.Card_Status__c) {
                hasCardSubProduct = true;
            }
        });
        if (!hasCardSubProduct) {
            minDate = addDays(createdDateString, 0);
        }
        if (actualHours >= 15) {
            var addAddToStartDay = true;
            if (actualHours == 15 && actualMinutes < 50) {
                addAddToStartDay = false;
            }
            if (addAddToStartDay) {
                minDate = addDays(createdDateString, 1);
            }
        }
        //console.log('minDate: ' , minDate);
    }

    for (var i = 0; i < migrationDefaults.listDatapicker.length; i++) {
        if (migrationDefaults.listDatapicker[i].syncElement === syncElement) {
            migrationDefaults.listDatapicker[i].minDate = minDate;
        }
    }
    migrationDefaults.listDatapicker.push({
        id: id,
        parId: parentId,
        prodId: productId,
        inpId: inputId,
        ppId: ppId,
        syncElement: syncElement,
        minDate: minDate,
        maxDate: maxDate
    });
}

function reformatDate(date) {
    //console.log('dateeee ' , date);
    if (date && date.includes('.') && !( /*@cc_on!@*/ false || !!document.documentMode)) {
        var splitDate = date.split('.');
        if (splitDate.length === 3) {
            date = splitDate[2] + '-' + splitDate[1] + '-' + splitDate[0];
        }
    }
    return date;
}

function getDatepickerIdsElement(id) {
    for (var i = 0; i < migrationDefaults.listDatapicker.length; i++) {
        if (migrationDefaults.listDatapicker[i].id === id) {
            return migrationDefaults.listDatapicker[i];
        }
    }
}

function getTextAreaElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, inputId, hasBackgroundQuery, valueFromCase, isElementReadOnly) {
    var inputValue;
    var paramVisibilityClass = '';
    var productConfiguration = configuration.productRelations[parentId][productId];
    if (item.productParameter.String_Value__c) {
        inputValue = item.productParameter.String_Value__c;
    } else {
        inputValue = item.productParameter.Value__c;
    }
    //    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE &&
    //        !(configuration.savedConfiguration &&
    //            productConfiguration.productParameterDefaults &&
    //            productConfiguration.productParameterDefaults[inputId] &&
    //            productConfiguration.productParameterDefaults[inputId].value)) {
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }
    var disabledHtml;
    if (isElementReadOnly || configuration.savedConfiguration || item.productParameter.Is_Read_Only__c === true || item.visibility.visibilityType === VISIBILITY_TYPE_DISABLE) {
        disabledHtml = 'disabled';
    } else {
        disabledHtml = '';
    }
    var helpTextElement = '';
    if (item.productParameter.Help_Text__c) {
        helpTextElement = getHelpTextSpan(item.productParameter.Help_Text__c);
    }
    var req = '';
    if (item.productParameter.Required__c) {
        req = '<span style="color: red; font-weight: bold; font-size: 17px;">|&nbsp;</span>';
    }
    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-inputId="{0}" '.format(inputId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-hasBackgroundQuery="{0}" '.format(hasBackgroundQuery);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');
    dataAttributes += 'data-syncElemName="{0}" '.format(item.productParameter.Sync_Element_Name__c);
    if (item.productParameter.Csv_Export_Column__c) {
        dataAttributes += 'data-csvExportColumn="{0}" '.format(item.productParameter.Csv_Export_Column__c);
    }
    var html = '';
    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    html += '<label class="slds-form-element__label" for="prod_param_1_17" style="inline-block">{2}{0}{1}</label>'.format(item.productParameter.Parameter_Label__c, helpTextElement, req);
    html += '<div class="slds-form-element__control">';
    if (configuration.savedConfiguration && productConfiguration.productParameterDefaults &&
        productConfiguration.productParameterDefaults[inputId].value &&
        (productConfiguration.productParameterDefaults[inputId].value || productConfiguration.productParameterDefaults[inputId].value == '')) {
        html += '<div onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{7}\', \'{7}\', \'{6}\');" id="{0}-{1}-{2}" class="slds-input simple-line-spaced" {5} style="background-color:#e0e5ee;cursor:not-allowed;border:1px solid #a8b7c7;color:dimgray;">{4}</div>'
            .format(parentId, productId, inputId, 'this.value', productConfiguration.productParameterDefaults[inputId].value, dataAttributes, item.productParameter.Sync_Element_Name__c, null);

        if (hasBackgroundQuery && productConfiguration.productParameterDefaults[inputId].value) {
            callCheckDependencies(item.productParameter.Id, parentId, productId, productConfiguration.productParameterDefaults[inputId].value, null, true, false);
        }
    } else if (configuration.pcfUnfinished && valueFromCase != null) {
        html += '<textarea onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{11}\', \'{11}\', \'{10}\');" class="slds-input simple-line-spaced" {5} id="{6}-{7}-{8}" {9}>{4}</textarea>'
            .format(parentId, productId, inputId, 'this.value', valueFromCase, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, item.productParameter.Sync_Element_Name__c, null);
        changeProductParameterValue(parentId, productId, inputId, valueFromCase, valueFromCase, null, item.productParameter.Sync_Element_Name__c);
    } else if (inputValue || item.defaultValueFromAsset) {
        html += '<textarea onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{11}\', \'{11}\', \'{10}\');" class="slds-input simple-line-spaced" {5} id="{6}-{7}-{8}" {9}>{4}</textarea>'
            .format(parentId, productId, inputId, 'this.value', item.defaultValueFromAsset ? item.defaultValueFromAsset : inputValue, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, item.productParameter.Sync_Element_Name__c, null);
        changeProductParameterValue(parentId, productId, inputId, item.defaultValueFromAsset ? item.defaultValueFromAsset : inputValue, item.defaultValueFromAsset, null, item.productParameter.Sync_Element_Name__c);
    } else {
        html += '<textarea onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{10}\', \'{10}\', \'{9}\');" class="slds-input simple-line-spaced" {4} id="{5}-{6}-{7}" {8}/></textarea>'
            .format(parentId, productId, inputId, 'this.value', disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, item.productParameter.Sync_Element_Name__c, null);
        changeProductParameterValue(parentId, productId, inputId, '');
    }
    html += '</div>';
    html += '</div>';
    return html;
}

function getHiddenElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, inputId, hasBackgroundQuery) {
    var hiddenValue;
    var paramVisibilityClass = 'migration-hide';
    var productConfiguration = configuration.productRelations[parentId][productId];
    if (item.productParameter.String_Value__c) {
        hiddenValue = item.productParameter.String_Value__c;
    } else if (item.productParameter.Value__c) {
        hiddenValue = item.productParameter.Value__c;
    } else if (item.defaultValueFromAsset && item.productParameter.SOQL__c && item.productParameter.SOQL_Field_Name__c) {
        hiddenValue = item.defaultValueFromAsset;
    }

    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-inputId="{0}" '.format(inputId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-hasBackgroundQuery="{0}" '.format(hasBackgroundQuery);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');
    dataAttributes += 'data-syncElemName="{0}" '.format(item.productParameter.Sync_Element_Name__c);
    if (item.productParameter.Csv_Export_Column__c) {
        dataAttributes += 'data-csvExportColumn="{0}" '.format(item.productParameter.Csv_Export_Column__c);
    }
    var html = '';
    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    html += '<label class="slds-form-element__label" for="prod_param_1_17" style="inline-block">{0}</label>'.format(item.productParameter.Parameter_Label__c);
    html += '<div class="slds-form-element__control">';
    //    //console.log('rendering HIDDEN ELEMENT:');
    //    //console.log(inputId);
    //    //console.log(productConfiguration.productParameterDefaults[inputId]);
    //    //console.log(productConfiguration.productParameterDefaults);
    //    //console.log(this.value);
    //    //console.log(hiddenValue);
    html += '<input onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3});" type="hidden" class="slds-input" value="{4}" id="{0}-{1}-{5}" {6}/>'
        .format(parentId, productId, inputId, 'this.value', hiddenValue, item.productParameter.Id, dataAttributes);
    changeProductParameterValue(parentId, productId, inputId, hiddenValue, null, null, item.productParameter.Sync_Element_Name__c);
    html += '</div>';
    html += '</div>';
    return html;
}

function propagateSyblingValue(ids, val) {
    if (ids) {
        var idList = ids.split(' ');
        idList.forEach(function(id) {
            $('[data-inputid="' + id + '"]').val(val);
            var childElementList = $('[data-inputid="' + id + '"');
            //console.log('childList: ', childElementList);
            for (var x = 0; x < childElementList.length; x++) {
                var childElement = childElementList[x];
                var parentId = childElement.dataset.parentid;
                var productId = childElement.dataset.productid;
                var childSyncElName = childElement.dataset.syncelemname;
                changeProductParameterValue(parentId, productId, id, val, null, null, childSyncElName);
            }
        });
    }
}

/*
function propagateSyblingValue(ids, val){
    if (ids) {
        var idList = ids.split(' ');
        idList.forEach(function (id) {
                           //console.log('tu som110');

           if($('[data-inputid="' + id + '"]').is(":visible")){
               //console.log('tu som111');
              $('[data-inputid="' + id + '"]').val(val);
              var childElementList = $('[data-inputid="' + id + '"');
              //console.log('childList: ', childElementList);
              for (var x = 0; x < childElementList.length; x++) {
                  var childElement = childElementList[x];
                  var parentId = childElement.dataset.parentid;
                  var productId = childElement.dataset.productid;
                  var childSyncElName = childElement.dataset.syncelementname;
                  changeProductParameterValue(parentId, productId, id, val, null, null, childSyncElName );
              }
           }
        });
    }
}*/

//TODO: predelat z textu na vlastnost
function propagateSyblingTextValue(ids, selectObject) {
    //console.log('selectObject: ', selectObject);
    if (ids) {
        var idList = ids.split(' ');
        idList.forEach(function(id) {
            if ($('[data-inputid="' + id + '"').length > 0 && $('[data-inputid="' + id + '"').parent().parent().not('.migration-hide').length > 0) {
                //            if($('[data-inputid="' + id + '"').length > 0) {
                var childElementList = $('[data-inputid="' + id + '"');
                //console.log('childList: ', childElementList);
                for (var x = 0; x < childElementList.length; x++) {
                    var childElement = childElementList[x];
                    //console.log('child: ', childElement);
                    var productParameterId = childElement.dataset.productparameterid;
                    var parentId = childElement.dataset.parentid;
                    var productId = childElement.dataset.productid;
                    var hasBackgroundQuery = childElement.dataset.hasbackgroundquery;
                    var selIndexIdChild = childElement.dataset.selectindexid;
                    var childSyncElName = childElement.dataset.syncelemname;
                    var optionValue = selectObject.options[selectObject.selectedIndex].text;
                    var selectOptionsList = childElement.options;
                    //console.log('javascript selector: ', selectOptionsList);
                    for (var i = 0; i < selectOptionsList.length; i++) {
                        //console.log('one Option: ', selectOptionsList[i]);
                        if (selectOptionsList[i].text == optionValue) {
                            selectOptionsList[i].selected = true;
                            changeProductParameterValue(parentId, productId, selIndexIdChild, selectOptionsList[i].value, null, null, childSyncElName);
                            //if(childSyncElName === 'SettlementType'){
                            changeEnhancedProductParameterValue(parentId, productId, selIndexIdChild, null, optionValue);
                            //}
                        } else {
                            //console.log('neselected');
                            selectOptionsList[i].selected = false;
                        }
                    }
                    checkDependencies(productParameterId, parentId, productId, childElement, hasBackgroundQuery);
                }
            }
        });
    }
}

/**
 * [getInputElement description]
 * @param  {String} parentId              ID of the parent product element. Example {index}-{product.ID}
 * @param  {String} sectionParamId        Id of the section (ID of the Product_Parameter__c which representing the section on the page)
 * @return {[type]}      [description]
 */
function getInputElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, inputId, hasBackgroundQuery, valueFromCase, isElementReadOnly) {
    var inputValue;
    var paramVisibilityClass = '';
    var productConfiguration = configuration.productRelations[parentId][productId];
    if (item.productParameter.String_Value__c) {
        inputValue = item.productParameter.String_Value__c;
    } else {
        inputValue = item.productParameter.Value__c;
    }
    var syblings = '';
    if (item.productParameter.Syblings__r) {
        for (var i = 0; i < item.productParameter.Syblings__r.length; i++) {
            syblings += item.productParameter.Syblings__r[i].Id + ' ';
        }
        syblings = syblings.substring(0, syblings.length - 1);
    }
    //    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE &&
    //        !(configuration.savedConfiguration &&
    //            productConfiguration.productParameterDefaults &&
    //            productConfiguration.productParameterDefaults[inputId] &&
    //            productConfiguration.productParameterDefaults[inputId].value)) {
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }
    var disabledHtml;
    if (isElementReadOnly || configuration.savedConfiguration || item.productParameter.Is_Read_Only__c === true || item.visibility.visibilityType === VISIBILITY_TYPE_DISABLE) {
        disabledHtml = 'disabled';
    } else {
        disabledHtml = '';
    }
    var helpTextElement = '';
    if (item.productParameter.Help_Text__c) {
        helpTextElement = getHelpTextSpan(item.productParameter.Help_Text__c);
    }

    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-inputId="{0}" '.format(inputId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-hasBackgroundQuery="{0}" '.format(hasBackgroundQuery);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-syncElemName="{0}" '.format(item.productParameter.Sync_Element_Name__c);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');

    if (item.productParameter.Csv_Export_Column__c) {
        dataAttributes += 'data-csvExportColumn="{0}" '.format(item.productParameter.Csv_Export_Column__c);
    }

    var cleave = '';
    if (typeof item.productParameter.Cleave_Type__c !== 'undefined' && typeof item.productParameter.Cleave_Data__c !== 'undefined') {
        cleave = ' cleave-' + item.productParameter.Cleave_Type__c.toLowerCase() + '-' + cleavesList.length;
        cleavesList.push({
            name: cleave,
            data: JSON.parse($('<textarea />').html(item.productParameter.Cleave_Data__c).text())
        });
        cleave += ' cleave-param';
    }
    var req = '';
    if (item.productParameter.Required__c) {
        req = '<span style="color: red; font-weight: bold; font-size: 17px;">|&nbsp;</span>';
    }
    var html = '';
    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    html += '<label class="slds-form-element__label" for="prod_param_1_17" style="inline-block">{2}{0}{1}</label>'.format(item.productParameter.Parameter_Label__c, helpTextElement, req);
    html += '<div class="slds-form-element__control">';
    var defaultValueFromParent = $('[data-syblings~="' + item.productParameter.Id + '"').val();
    var composedInputId = parentId + '-' + productId + '-' + item.productParameter.Id;
    //    //console.log(inputId);
    //    //console.log(productConfiguration.productParameterDefaults[inputId]);
    //    //console.log(productConfiguration.productParameterDefaults);
    if (configuration.savedConfiguration && productConfiguration.productParameterDefaults &&
        productConfiguration.productParameterDefaults[inputId].value) {
        html += '<div id="{8}" onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{6}\', \'{6}\', \'{7}\');" class="slds-input" {5} style="background-color:#e0e5ee;cursor:not-allowed;border:1px solid #a8b7c7;color:dimgray;">{4}</div>'
            .format(parentId, productId, inputId, 'this.value', productConfiguration.productParameterDefaults[inputId].value, dataAttributes, null, item.productParameter.Sync_Element_Name__c, composedInputId);

        if (hasBackgroundQuery && productConfiguration.productParameterDefaults[inputId].value) {
            callCheckDependencies(item.productParameter.Id, parentId, productId, productConfiguration.productParameterDefaults[inputId].value, null, true, false);
        }
    } else if (configuration.pcfUnfinished && valueFromCase != null) {
        var bgqstyle = hasBackgroundQuery ? 'style="width: calc(100% - 46px) !important;"' : '';
        html += '<input {14} onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{10}\', \'{10}\', \'{11}\');propagateSyblingValue(\'{13}\', {3});" type="text" class="slds-input{12}" value="{4}" {5} id="{6}-{7}-{8}" {9}  data-syblings="{13}"/>'
            .format(parentId, productId, inputId, 'this.value', defaultValueFromParent ? defaultValueFromParent : valueFromCase, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, null, item.productParameter.Sync_Element_Name__c, cleave, syblings, bgqstyle);
        if (hasBackgroundQuery) {
            html += '<button class="slds-button slds-button--icon-bare slds-m-right--x-small block-btn btn btn-background-query" onclick="getElementAndCheckDependencies(\'{0}\', \'{1}\', \'{2}\',null, true, \'{3}-{4}-{5}\');return false;" style="margin-left: 3px;display: inline-block;margin-right:  0px;margin-bottom: 2px;">'
                .format(item.productParameter.Id, parentId, productId, parentId, productId, item.productParameter.Id);
            html += '<span class="block-btn-icon btn-text-icon-background-query" style="height: 26px;margin-right:  0px;padding-top:  2px;">';
            html += '<img src="{0}">'.format(migrationDefaults.images.magnifier);
            html += '</span>';
            html += '</button>';
        }
        changeProductParameterValue(parentId, productId, inputId, defaultValueFromParent ? defaultValueFromParent : valueFromCase, null, null, item.productParameter.Sync_Element_Name__c);
    } else if (inputValue || item.defaultValueFromAsset) {
        html += '<input  onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{10}\', \'{10}\', \'{11}\');propagateSyblingValue(\'{13}\', {3});" type="text" class="slds-input{12}" value="{4}" {5} id="{6}-{7}-{8}" {9} data-syblings="{13}"/>'
            .format(parentId, productId, inputId, 'this.value', item.defaultValueFromAsset ? item.defaultValueFromAsset : inputValue, disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, null, item.productParameter.Sync_Element_Name__c, cleave, syblings);
        changeProductParameterValue(parentId, productId, inputId, item.defaultValueFromAsset ? item.defaultValueFromAsset : inputValue, item.defaultValueFromAsset, null, item.productParameter.Sync_Element_Name__c);
        callCheckDependencies(item.productParameter.Id, parentId, productId, productConfiguration.productParameterDefaults[inputId].value, null, hasBackgroundQuery, false);
    } else {
        if (hasBackgroundQuery) {
            html += '<input style="width: calc(100% - 46px) !important;" onblur="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{9}\', \'{9}\', \'{10}\');" type="text" class="slds-input{11}" {4} id="{5}-{6}-{7}" {8}/>'
                .format(parentId, productId, inputId, 'this.value', disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, null, item.productParameter.Sync_Element_Name__c, cleave);
            html += '<button class="slds-button slds-button--icon-bare slds-m-right--x-small block-btn btn btn-background-query" onclick="getElementAndCheckDependencies(\'{0}\', \'{1}\', \'{2}\',null, true, \'{3}-{4}-{5}\');return false;" style="margin-left: 3px;display: inline-block;margin-right:  0px;margin-bottom: 2px;">'
                .format(item.productParameter.Id, parentId, productId, parentId, productId, item.productParameter.Id);
            html += '<span class="block-btn-icon btn-text-icon-background-query" style="height: 26px;margin-right:  0px;padding-top:  2px;">';
            html += '<img src="{0}">'.format(migrationDefaults.images.magnifier);
            html += '</span>';
            html += '</button>';
        } else {
            html += '<input onChange="changeProductParameterValue(\'{0}\', \'{1}\', \'{2}\', {3}, \'{9}\', \'{9}\', \'{10}\');propagateSyblingValue(\'{12}\', {3});" type="text" class="slds-input{11}" {4} id="{5}-{6}-{7}" {8} data-syblings="{12}" value="{13}"/>'
                .format(parentId, productId, inputId, 'this.value', disabledHtml, parentId, productId, item.productParameter.Id, dataAttributes, null, item.productParameter.Sync_Element_Name__c, cleave, syblings, defaultValueFromParent ? defaultValueFromParent : '');
        }
        if (item.productParameter.Parameter_Label__c == 'Číslo účtu příjemce') {
            console.log('PJ');
        }
        changeProductParameterValue(parentId, productId, inputId, defaultValueFromParent ? defaultValueFromParent : '', null, null, item.productParameter.Sync_Element_Name__c);
        //changeEnhancedProductParameterValue(parentId, productId, selectIndexId, null, defaultValueFromParent ? defaultValueFromParent : '');
        //callCheckDependencies(item.productParameter.Id, parentId, productId, productConfiguration.productParameterDefaults[inputId].value, null, hasBackgroundQuery, false);
    }
    html += '</div>';
    html += '</div>';
    return html;
}

function getExternalLinkButtonElement(item, parentId, sectionParamId, parentId, productId, sectionIndexId, buttonId, isElementReadOnly) {
    var productConfiguration = configuration.productRelations[parentId][productId];
    var disabledHtml = isElementReadOnly || configuration.savedConfiguration || item.productParameter.Is_Read_Only__c === true ? 'disabled' : '';
    var html = '';
    var paramVisibilityClass = '';
    var paramVisibilityAtribute = '';
    if (item.visibility.visibilityType === VISIBILITY_TYPE_HIDE) {
        paramVisibilityClass = 'migration-hide';
    }

    var dataAttributes = '';
    dataAttributes += ' data-parentId="{0}" '.format(parentId);
    dataAttributes += 'data-productId="{0}" '.format(productId);
    dataAttributes += 'data-inputId="{0}" '.format(buttonId);
    dataAttributes += 'data-productParameterId="{0}" '.format(item.productParameter.Id);
    dataAttributes += 'data-hasBackgroundQuery="{0}" '.format(false);
    dataAttributes += 'data-visibilityCounter="{0}" '.format(item.visibility.visibilityCount);
    dataAttributes += 'data-initVisibility="{0}" '.format(item.visibility.visibilityType === VISIBILITY_TYPE_HIDE ? '0' : '1');

    var elementMargin = configuration.savedConfiguration ? configuration.elementMarginRO : configuration.elementMarginEdit;
    html += '<div class="slds-form-element {0}" style="margin-top: {4}px;" id="parameter-{1}-{2}-{3}" data-index="17">'.format(paramVisibilityClass, parentId, productId, item.productParameter.Id, elementMargin);
    html += '<label class="slds-form-element__label" for="prod_param_1_17" style="inline-block"></label>';
    //item.productParameter.Parameter_Label__c
    html += '<div class="slds-form-element__control">';
    /*if (item.productParameter.System__c == 'SCUBE') {
        console.log(item.data);
		html += '                                    <button class="slds-button slds-button--icon-bare slds-m-right--x-small block-btn btn" onClick="openScube2(\'{0}\', \'{1}\', \'{2}\', \'{3}\'); return false;" {4} id="{5}-{6}-{7}">'
            .format(item.data.cacheId, item.data.endpoint, item.data.endpointCacheId, item.data.json, dataAttributes, parentId, productId, item.productParameter.Id);
	} else if (item.productParameter.System__c == 'CRIF') {
        html += '                                    <button class="slds-button slds-button--icon-bare slds-m-right--x-small block-btn btn" onClick="openCRIF(\'{0}\', \'{5}\', \'{6}\', \'{7}\', \'{8}\', \'{9}\'); return false;" {1} id="{2}-{3}-{4}">'
            .format(configuration.cuid, dataAttributes, parentId, productId, item.productParameter.Id, configuration.accName, configuration.accSurname, configuration.accBN, configuration.userName, configuration.userOrgUnitId);
    } else {*/
    html += '                                    <button class="slds-button slds-button--icon-bare slds-m-right--x-small block-btn btn" onClick="return false;" {0} id="{1}-{2}-{3}">'
        .format(dataAttributes, parentId, productId, item.productParameter.Id);
    //}
    html += '                                        <span class="block-btn-icon">';
    html += '                                            <img src="{0}" />'.format(migrationDefaults.images.open);
    html += '                                        </span>';
    html += '                                        <span id="submit-btn-txt" class="block-btn-text">{0}</span>'.format(item.productParameter.Parameter_Label__c);
    html += '                                    </button>';

    html += '</div>';
    html += '</div>';
    return html;
}

function openCRIF(cuid, accFirstName, accSurname, accBN, userName, userOrgUnitId) {
    //crifDefaults.crifUrl = migrationDefaults.urls.crif;
    //console.log(crifDefaults.crifUrl);
    openCRIFfromMigrationPremium(cuid, accFirstName, accSurname, accBN, userName, userOrgUnitId);
    //console.log('*** OPENING CRIF ***');
    //console.log(cuid + ', ' + accFirstName + ', ' + accSurname + ', ' + accBN + ', ' + userName + ', ' + userOrgUnitId);
    /*var data = '';
    data += '<?xml version="1.0" encoding="UTF-8"?>';
    data += '<document xmlns="http://www.csob.cz/2007/AGF/CRIFService">';
    data += '<header>';
    data += '<user_name>{0}</user_name>'.format(userName);
    data += '<org_unit_id>{0}</org_unit_id>'.format(userOrgUnitId);
    data += '</header>';
    data += '<data>';
    data += '<request_type>4</request_type>';
    data += '<person>';
    data += '<cuid>{0}</cuid>'.format(cuid);
    data += '<name>{0}</name>'.format(accFirstName);
    data += '<surname>{0}</surname>'.format(accSurname);
    data += '<fict_birth_number>{0}</fict_birth_number>'.format(accBN);
    data += '</person>';
    data += '</data>';
    data += '</document>';

    data = encodeURI(data.replace(/&quot;/g, '"'));
    //console.log(data);

    var form = document.createElement("form");
    form.setAttribute("method", "POST");
    form.setAttribute("action", migrationDefaults.urls.crif);
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", "xmlmessage");
    hiddenField.setAttribute("value", data);
    var hiddenField2 = document.createElement("input");
    hiddenField2.setAttribute("type", "hidden");
    hiddenField2.setAttribute("name", "encoded");
    hiddenField2.setAttribute("value", 'utf-8');
    form.appendChild(hiddenField);
    form.appendChild(hiddenField2);
    document.body.appendChild(form);
    var uuid = guid();
    window.open('', uuid, 'location=no,toolbar=no,menubar=no,scrollbars=yes,resizable=yes, width=1320,height=767');
    form.target = uuid;
    form.submit();*/
    return false;
}

function selectScopedTab(currentNavElementId, currentContentElementId, previousNavElementId, previousContentElementId) {
    var currentNavElement = $('#' + currentNavElementId);
    var currentContentElement = $('#' + currentContentElementId);
    var previousNavElement = $('#' + previousNavElementId);
    var previousContentElement = $('#' + previousContentElementId);

    previousContentElement.removeClass('slds-show');
    previousContentElement.addClass('slds-hide');
    currentContentElement.addClass('slds-show');
    currentContentElement.removeClass('slds-hide');
    previousNavElement.removeClass('slds-active');
    currentNavElement.addClass('slds-active');
}

function getElementAndCheckDependencies(parentProductParameter, parentProductId, productId, selectObject, hasBackgroundQuery, elementId) {
    checkDependencies(parentProductParameter, parentProductId, productId, $('#' + elementId), hasBackgroundQuery);
}

function checkDependencies(parentProductParameter, parentProductId, productId, selectObject, hasBackgroundQuery) {
    if (!hasBackgroundQuery) {
        hasBackgroundQuery = false;
    }
    var valueText = null;
    var valueId = null;
    var hideAllDependentParams = selectObject == null ? true : false;
    if (!hideAllDependentParams) {
        //console.log('checkDependencies true');
        var jqSelectedObject = $(selectObject);
        //console.log('jqsele ' , jqSelectedObject);
        if (jqSelectedObject.is('input')) {
            //console.log('checkDependencies input true');
            if (jqSelectedObject.prop('type') == 'text') {
                valueId = null;
                valueText = jqSelectedObject.val();
            } else if (jqSelectedObject.prop('type') == 'checkbox') {
                valueId = null;
                valueText = '' + jqSelectedObject.is(":checked");
            }
        } else {
            //console.log('checkDependencies input false ' );
            var selectedItem = jqSelectedObject.find('option:selected');
            //console.log('selectedItem', selectedItem);
            var value = selectedItem.val();
            //console.log('value', value);
            if (value) {
                valueId = value;
            } else {
                valueId = configuration.accountId;
            }
            valueText = selectedItem.text();
        }
    }
    //console.log('checkDependencies false');

    callCheckDependencies(parentProductParameter, parentProductId, productId, valueText, valueId, hasBackgroundQuery, hideAllDependentParams);
}

function callCheckDependencies(parentProductParameter, parentProductId, productId, valueText, valueId, hasBackgroundQuery, hideAllDependentParams) {
    showLoadingModal();
    //console.log('calling checkDependencies: ' + parentProductParameter, parentProductId, productId, valueText, valueId, hasBackgroundQuery, hideAllDependentParams);

    var compId = parentProductId + '-' + productId + '-' + parentProductParameter;
    var parentProductParameterElement = $('[id$="' + compId + '"').not('div');

    Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.checkDependencies, parentProductParameter, parentProductId, productId, valueId, valueText, hasBackgroundQuery, hideAllDependentParams, configuration.accountId, function(result, event) {
        //console.log('checkDependencies callback');
        //console.log('result size: ' + result.length);
        if (event.status && result) {
            result.forEach(function(element) {
                //                var inpElement = document.getElementById(element.composedId);
                console.log('composeId: ', element.composedId);
                var composedId = '#' + element.composedId;
                //console.log('composeId: ' + composedId);

                var inputElement = $(composedId);
                var paramComposedId = '#parameter-' + element.composedId;
                var parameterElement = $(paramComposedId);
                var data = inputElement.data();
                if (data && data.inputid) {
                    console.log('data-inputId: ', data.inputid);
                    console.log('visibility: ', element.visibilityType);
                }

                if (typeof data !== 'undefined' && (element.isHidden || element.visibilityType === VISIBILITY_TYPE_HIDE)) {
                    if (!configuration.savedConfiguration || data.initvisibility != '0') {
                        if (data.visibilitycounter > 0) {
                            data.visibilitycounter--;
                        }
                        if (data.visibilitycounter < 1) {
                            parameterElement.addClass('migration-hide');
                            if (inputElement.is('input') && !(configuration.migrationProcessName === 'Account_Cancellation' && data.syncelemname === 'terminationFee')) {
                                inputElement.val('');
                                if (inputElement.attr('type') === 'checkbox' && inputElement.prop('checked')) {
                                    inputElement.prop('checked', false);
                                    changeProductParameterValue(data.parentid, data.productid, data.inputid, '', null, null, data.syncelemname);
                                    checkDependencies(data.productparameterid, data.parentid, data.productid, null, data.hasbackgroundquery);
                                } else {
                                    changeProductParameterValue(data.parentid, data.productid, data.inputid, '', null, null, data.syncelemname);
                                }
                            } else {
                                changeProductParameterValue(data.parentid, data.productid, data.selectindexid, '', null, null, data.syncelemname);
                                checkDependencies(data.productparameterid, data.parentid, data.productid, null, data.hasbackgroundquery);
                            }
                            /*else if(!inputElement.is('button')){
                                                        inputElement.html('');
                                                        changeProductParameterValue(data.parentid, data.productid, data.selectindexid, '');
                                                        checkDependencies(data.productparameterid, data.parentid, data.productid, inputElement, data.hasbackgroundquery);
                                                    }*/
                        }
                    }
                } else if (element.visibilityType === VISIBILITY_TYPE_DISABLE) {
                    inputElement.removeClass('slds-hide');
                    inputElement.attr("disabled", true);
                    if (inputElement.attr('type') === 'checkbox') {
                        inputElement.prop('checked', false);
                    } else {
                        inputElement.val(element.initialValue);
                        changeProductParameterValue(data.parentid, data.productid, data.inputid, element.initialValue, null, null, data.syncelemname);
                    }
                } else {
                    // When the input element has background query (like search account with CUID), don't increment the visibility counter.
                    // The user can search multiple times.
                    if (!element.hasBackgroundQuery) {
                        if ((parentProductParameterElement && parentProductParameterElement[0] && parentProductParameterElement[0].type === 'checkbox') || (typeof data !== 'undefined' && data.visibilitycounter < 1)) {
                            //                            if (!configuration.savedConfiguration || data.initVisibility != '1'){ //probably not needed
                            if (!parentProductParameterElement || !parentProductParameterElement[0] || !parentProductParameterElement[0].type.startsWith('select') || !parentProductParameterElement[0].parentElement.parentElement.classList.contains('migration-hide')) {
                                parentProductParameterElement = $('[id$="' + compId + '"').not('div');
                                if (configuration.migrationProcessName === 'FormOrder_Asset_Conf_2' || (parentProductParameterElement && parentProductParameterElement.parent() && parentProductParameterElement.parent().parent() && parentProductParameterElement.parent().parent().parent() && !parentProductParameterElement.parent().parent().parent().hasClass('migration-hide'))) {
                                    data.visibilitycounter++;
                                    parameterElement.removeClass('migration-hide');
                                }
                            }
                            //                            }
                        }
                    }
                    if (configuration.savedConfiguration) {
                        inputElement.attr("disabled", true);
                    }
                    if (!configuration.pcfUnfinished && inputElement.attr('type') === 'checkbox') {
                        if (typeof configuration.productRelations[data.parentid][data.productid].productParameterDefaults[data.inputid] === 'undefined' || configuration.productRelations[data.parentid][data.productid].productParameterDefaults[data.inputid] == "" || configuration.productRelations[data.parentid][data.productid].productParameterDefaults[data.inputid].value == "") {
                            if (element.initialValue) {
                                inputElement.prop('checked', true);
                                changeProductParameterValue(data.parentid, data.productid, data.inputid, true, null, null, data.syncelemname);
                                checkDependencies(data.productparameterid, data.parentid, data.productid, inputElement, data.hasbackgroundquery);
                            } else {
                                inputElement.prop('checked', false);
                                changeProductParameterValue(data.parentid, data.productid, data.inputid, false, null, null, data.syncelemname);
                            }
                        }
                    } else if (!configuration.pcfUnfinished && inputElement.attr('type') === 'text' && !(configuration.migrationProcessName === 'Account_Cancellation' && data.syncelemname === 'terminationFee')) {
                        changeProductParameterValue(data.parentid, data.productid, data.inputid, element.initialValue, null, null, data.syncelemname);
                        inputElement.val(configuration.productRelations[data.parentid][data.productid].productParameterDefaults[data.inputid].value);
                    } else if (inputElement.is('select') && !element.multipleInitialValueList) {
                        var selectedItem = inputElement.find('option:selected');
                        var value = selectedItem.val();
                        /*console.log('value: ' , value);
                        console.log('data.parentid: ' , data.parentid);
                        console.log('data.productid: ' , data.productid);
                        console.log('data.selectindexid: ' , data.selectindexid);
                        console.log('data: ' , data);
                        console.log('inputElement: ' , inputElement);
                        console.log('parameterElement: ' , parameterElement);*/
                        changeProductParameterValue(data.parentid, data.productid, data.selectindexid, value, null, null, data.syncelemname, null);
                        checkDependencies(data.productparameterid, data.parentid, data.productid, inputElement, data.hasbackgroundquery);
                        if (data.syncelemname === 'chequeFullAddress') {
                            changeEnhancedProductParameterValue(data.parentid, data.productid, data.selectindexid, element.composedId);
                        }
                        /*inputElement.html('');
                        var firstNewItem = true;
                        $.each(element.multipleInitialValueList, function (i, item) {
                            inputElement.append($('<option>', {
                                value: item.value,
                                text : item.text
                            }));
                            if(firstNewItem){
                                changeProductParameterValue(data.parentid, data.productid, data.selectindexid, item.value);
                                checkDependencies(data.productparameterid, data.parentid, data.productid, inputElement, data.hasbackgroundquery);
                                firstNewItem = false;
                            }
                        });*/
                    } else if (inputElement.is('select') && element.multipleInitialValueList) {
                        inputElement.html('');
                        var firstNewItem = true;
                        $.each(element.multipleInitialValueList, function(i, item) {
                            inputElement.append($('<option>', {
                                value: item.value,
                                text: item.text
                            }));
                            if (firstNewItem) {
                                changeProductParameterValue(data.parentid, data.productid, data.selectindexid, item.value, null, null, data.syncelemname);
                                checkDependencies(data.productparameterid, data.parentid, data.productid, inputElement, data.hasbackgroundquery);
                                changeEnhancedProductParameterValue(data.parentid, data.productid, data.selectindexid, element.composedId);
                                firstNewItem = false;
                            }
                        });
                    }
                }
            });
        }
        setL1VisibilityBasedOnParameterPresence();
        dismissLoadingModal();
    });
}

function setL1VisibilityBasedOnParameterPresence() {
    var BreakException = {};
    var sections = document.querySelectorAll('[id^="section-data-"]');
    //console.log('SECTIONS:');
    //console.log(sections);
    for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        try {
            var sectIdParts = section.id.split("-");
            var sectionId = sectIdParts[sectIdParts.length - 2] + '-' + sectIdParts[sectIdParts.length - 1];
            var sectionLabel = $('#section-label-' + sectionId);
            if (section.childNodes.length > 0) {
                for (var j = 0; j < section.childNodes.length; j++) {
                    var node = section.childNodes[j];
                    if (!node.classList.contains("migration-hide")) {
                        sectionLabel.show();
                        throw BreakException;
                    }
                };
            }
            sectionLabel.hide();
        } catch (e) {
            if (e !== BreakException) throw e;
        }
    }
}

function callCheckDepFuture() {
    for (var i = 0; i < checkDepFutureList.length; i++) {
        var fo = checkDepFutureList[i];
        checkDependencies(fo.parentProductParameter, fo.parentProductId, fo.productId, fo.selectObject, fo.hasBackgroundQuery);
    }
    checkDepFutureList = [];
}

function sendToBackOfficeAndCreateCase() {
    /* if(!configuration.istsDocumentIsGenerated){
        showNotifyMessage('Před uložením migrace je nutné vytvořit a uložit ISTS dokument.', 'error');
        return false;
    }*/

    if (!isCheckedMandatoryCheckboxes()) {
        alertify.alert('Chyba', "Prosím, zaškrtněte povinné položky.", function() {});
        return;
    }

    var filesIsEmpty = configuration.files == null ? true : configuration.files.length == 0;
    if (configuration.atLeastOneAttachmentIsRequired && filesIsEmpty) {
        alertify.alert('Chyba', "Prosím, nahrajte alespoň jednu přílohu.", function() {});
        return;
    }
    $("#submit-btn").attr("disabled", true);
    showLoadingModal();

    if (configuration.doNotCreateACase) {
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.updateOpp,
            configuration.oppId,
            JSON.stringify(configuration.apiFields),
            function(result, event) {
                if (event.status && result) {
                    if (!result.errorMessage) {
                        msg = configuration.caseMessage;
                        dismissLoadingModal();
                        alertify.alert('Informace', msg, function() {
                            if (configuration.isWdeUser) {
                                closeCurrentOnly();
                            } else {
                                openItemAndCloseCurrent(result.theOppId);
                            }
                        });
                    } else {
                        alertify.alert('Chyba! ' + result.theOppId + ': ' + result.errorMessage);
                        dismissLoadingModal();
                    }
                } else {
                    alertify.alert('Chyba! ' + configuration.oppId + ': ' + event.message);
                    dismissLoadingModal();
                }
            }
        );
        $("#submit-btn").attr("disabled", false);
    } else {
        /*if (configuration.onSubmitStoreToJSK && (configuration.migrationProcessName != 'Mobility_income' || configuration.isWdeUser)) {
            var reservation = configuration.migrationProcessName === 'Mobility_income' && $('[data-sign-method-callid]:selected').length < 1 && !$('[data-sign-method-callid]:selected').parent().parent().parent().hasClass('migration-hide') ? true : false;
            var prodNumber = configuration.migrationProcessName === 'Mobility_income' ? $('*[data-syncElemName="csobProductNumberKc"]').val() ? $('*[data-syncElemName="csobProductNumberKc"]').val() : $('*[data-syncElemName="csobProductNumberKcExist"]').children("option:selected").text().split(' - ')[0].trim() : '';
            prodNumber = prodNumber.split('/')[0];
            var showToClient = configuration.migrationProcessName === 'Mobility_income' && !reservation ? true : false;
            Visualforce.remoting.Manager.invokeAction(
                migrationDefaults.remoteActions.storeToJSK,
                lastGeneratedDocId,
                reservation,
                prodNumber,
                showToClient,
                function(result, event){

                }
            );
        }*/

        //console.log('*** exceptionGen Date elem ***');
        //console.log($('[data-exceptionGen-date]'));

        var exceptionDate = $('[data-exceptionGen-date]').length > 0 ? $('[data-exceptionGen-date]')[0].value : '';
        var exceptionType = $('[data-exceptionGen-type]:selected').length > 0 ? $('[data-exceptionGen-type]:selected')[0].getAttribute('data-exceptionGen-type') : '';

        var checkBoxesWithSufoPriority = $('[data-prioritysufo]:checked');
        var selectedProductRelationId = $('#prod_param_select_9_69').val();
        var lowestPriority;
        checkBoxesWithSufoPriority.each(function(index) {
            var currentPriority = $(this).data('prioritysufo');
            if (currentPriority && (!lowestPriority || currentPriority < lowestPriority)) {
                lowestPriority = currentPriority;
            }
        });

        //        if(configuration.migrationProcessName === 'Account_Cancellation'){
        //            //create call for getting asset cards to apex
        //            Visualforce.remoting.Manager.invokeAction(
        //                migrationDefaults.remoteActions.deactivateCreditCards,
        //                JSON.stringify(configuration.productList),
        //                 JSON.stringify(configuration.productRelations),
        //                function(result, event) {
        //                    //console.log('result: ' , result);
        //                    //console.log('event: ' , event);
        //                    if (event.status && result) {
        //                          if(!result.errorMessage) {
        //                              if(result.successMessage == 'no credit cards deactivated'){
        //                                  dismissLoadingModal();
        //                                  alertify.alert('Informace', "Karty nebyly deaktivovány, protože nejsou přiřazeny k hlavnímu produktu nebo nesplnily podmínky pro jejich deaktivaci. Nyní následuje vytvoření servisního případu.", function(){createSubmitButtonCase('submit');});
        //                              } else{
        //                                  dismissLoadingModal();
        //                                  alertify.alert('Informace', "Karty byly úspěšně deaktivovány.", function(){createSubmitButtonCase('submit');});
        //                              }
        //                          } else {
        //                            alertify.alert(result.errorMessage);
        //                            dismissLoadingModal();
        //                          }
        //                    } else {
        //                        alertify.alert('Chyba', $Label.PCF_Create_Case_Error_Msg + ' ' + event.message);
        //                        $("#submit-btn").removeAttr("disabled");
        //                        dismissLoadingModal();
        //                    }
        //                });
        //        } else{
        createSubmitButtonCase('submit');
        //        }
    }
    return false;
}

function createSubmitButtonCase(operationIncoming) {
    showLoadingModal();
    removeSensitiveDataFromConfiguration();
    typeOfOperation = operationIncoming;

    var createCase = true;
    //console.log('selectedProductRelationId, ', selectedProductRelationId);
    //console.log('elDocDistrib, ', elDocDistrib);
    //console.log('exceptionType, ', exceptionType);
    //console.log('exceptionDate, ', exceptionDate);
    //console.log('filesIsEmpty, ', filesIsEmpty);


    /*if(configuration.migrationProcessName === 'Heritage' && typeOfOperation === 'draft' && !configuration.caseIdFromPage){
        createCase = false;
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.checkHeritageCasesDraft,
            configuration.accountId,
            function(result, event) {
                if (event.status) {
                    if(result == false){
                        createCaseForProccess(typeOfOperation);
                    } else{
                        dismissLoadingModal();
                        alertify.alert('Chyba', migrationDefaults.labels.heritageDraftExists);
                    }
                } else {
                    alertify.alert('Chyba', $Label.PCF_Create_Case_Error_Msg + ' ' + event.message);
                    $("#submit-btn").removeAttr("disabled");
                    dismissLoadingModal();
                }
            });
    }*/
    /*if(configuration.migrationProcessName === 'Heritage' && typeOfOperation === 'submit'){
        showLoadingModal();
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.checkHeirsData,
            JSON.stringify(configuration.productRelations),
            configuration.cuid,
            true,
            function(result, event) {
                if(event.status && result){
                    if(result === 'nok'){
                        console.log('menim starou draft case zneplatneno');
                    } else if( result === 'error'){
                        alertify.alert('Chyba', 'Chyba při načítání konfigurace na servisním případu.');
                    }
                    dismissLoadingModal();
                }else{
                    alertify.alert('Chyba! ' + event);
                    dismissLoadingModal();
                    document.getElementById("scopedTab0").click();
                }
            }
        );
    }*/
    /* if (configuration.migrationProcessName === 'PPF' && typeOfOperation === 'draft' && !configuration.caseIdFromPage) {
         createCase = false;
         Visualforce.remoting.Manager.invokeAction(
             migrationDefaults.remoteActions.checkIfPpfDraft,
             configuration.accountId,
             function (result, event) {
                 if (event.status) {
                     if (result === false) {
                         createCaseForProccess(typeOfOperation);
                     } else {
                         dismissLoadingModal();
                         alertify.alert('Chyba', migrationDefaults.labels.ppfDraftExists);
                     }
                 } else {
                     alertify.alert('Chyba', $Label.PCF_Create_Case_Error_Msg + ' ' + event.message);
                     $("#submit-btn").removeAttr("disabled");
                     dismissLoadingModal();
                 }
             });
     }*/
    console.log('createCase ', createCase);
    if (createCase == true) {
        createCaseForProccess(typeOfOperation);
    }
}

function createCaseForProccess(typeOfOperation) {
    var filesIsEmpty = configuration.files == null ? true : configuration.files.length == 0;
    var exceptionDate = $('[data-exceptionGen-date]').length > 0 ? $('[data-exceptionGen-date]')[0].value : '';
    var exceptionType = $('[data-exceptionGen-type]:selected').length > 0 ? $('[data-exceptionGen-type]:selected')[0].getAttribute('data-exceptionGen-type') : '';
    var elDocDistrib = getElDocDistrib();
    var checkBoxesWithSufoPriority = $('[data-prioritysufo]:checked');
    var csvExportColumns = $('[data-csvexportcolumn]');
    var csvRow = {};
    var selectedProductRelationId = $('#prod_param_select_9_69').val();
    var lowestPriority;
    checkBoxesWithSufoPriority.each(function(index) {
        var currentPriority = $(this).data('prioritysufo');
        if (currentPriority && (!lowestPriority || currentPriority < lowestPriority)) {
            lowestPriority = currentPriority;
        }
    });
    csvExportColumns.each(function(index) {
        if (!$(this).parent().parent().hasClass('migration-hide') || $(this).is('input[type=hidden]')) {
            var colName = $(this).data('csvexportcolumn');
            var parentId = $(this).data('parentid');
            var productId = $(this).data('productid');
            var ppId = $(this).data('productparameterid');
            var val = configuration.productRelations[parentId][productId].productParameterDefaults[ppId] ? configuration.productRelations[parentId][productId].productParameterDefaults[ppId].stringValue ? configuration.productRelations[parentId][productId].productParameterDefaults[ppId].stringValue : configuration.productRelations[parentId][productId].productParameterDefaults[ppId].value : val;
            val = $(this).is('select') ? jQuery("option:selected", this).data('string-value') ? jQuery("option:selected", this).data('string-value') : jQuery("option:selected", this).text() : val;
            val = val === true ? '1' : val === false ? '0' : val && val.length > 3 && val.substr(0, 3) == ppId.substr(0, 3) ? '' : val;
            csvRow[colName] = val;
        }
    });
    var csvRowJson = JSON.stringify(csvRow);
    if (csvRowJson !== JSON.stringify({})) {
        configuration.apiFields['export'] = {
            fieldName: 'Export__c',
            value: csvRowJson,
            wantEncryptFields: false
        };
    }
    var mobilityCourierBranch = null;
    if (configuration.migrationProcessName === 'Mobility_income') {
        if ($('[data-sign-method-courier]:selected').length > 0) {
            mobilityCourierBranch = $('[data-syncElemName="mobilita_premium"]')[0].value == 'true' ? BRANCH_VZDALENE_BANKOVNICTVI_DATA_ID : BRANCH_FLEXIBILNI_OPERACE_DATA_ID;
        }
    }
    // if (configuration.migrationProcessName === 'Account_Cancellation') {
    //     const productCodes = ['347', '350', '380', '390', '3471', '3501', '3801', '3901', '501', '507', '508', '522', '570', '571', '507'];
    //     var amountForVerification = false;
    //     var codeForVerification = false;
    //     var forVerification = false;
    //     var verificationProduct = null;
    //     var assetsForVerification = '';
    //     for (itemIndex in configuration.productRelations) {
    //         for (childItemIndex in configuration.productRelations[itemIndex]) {
    //             var childItem = configuration.productRelations[itemIndex][childItemIndex];
    //             if (childItem.assetId != null && childItem.assetId != '') {
    //                 console.log('MSV assetId2', childItem.assetId);
    //                 assetsForVerification = assetsForVerification + childItem.assetId + ':';
    //                 for (paramIndex in childItem.productParameterDefaults) {
    //                     var param = childItem.productParameterDefaults[paramIndex];
    //                     if (param.syncElementName === 'verificationAmount') {
    //                         if (param.value >= 300000) {
    //                             amountForVerification = true;
    //                             console.log('MSV Nastavujem amountForVerification na TRUE');
    //                         }
    //                         console.log('MSV verificationAmount param: ', param.value);
    //                     }
    //                     if (param.syncElementName === 'verificationProductCode') {
    //                         if (productCodes.includes(param.value)) {
    //                             codeForVerification = true;
    //                             console.log('MSV Nastavujem codeForVerification na TRUE');
    //                         }
    //                         console.log('MSV verificationProductCode param: ', param.value);
    //                     }
    //                     if (param.syncElementName === 'verificationProduct') {
    //                         verificationProduct = param;
    //                         console.log('MSV verificationProduct param: ', JSON.stringify(param.value));
    //                     }
    //                 }
    //                 if (verificationProduct != null) {
    //                     if (amountForVerification && codeForVerification) {
    //                         verificationProduct.value = true;
    //                         forVerification = true;
    //                         assetsForVerification = assetsForVerification + 'in verification,'
    //                         console.log('MSV Nastavujem verificationProduct na TRUE');
    //                     } else {
    //                         verificationProduct.value = false;
    //                         assetsForVerification = assetsForVerification + 'cancel,'
    //                         console.log('MSV Nastavujem verificationProduct na FALSE');
    //                     }
    //                 } else {
    //                     assetsForVerification = assetsForVerification + 'cancel,'
    //                 }
    //             }
    //             amountForVerification = false;
    //             codeForVerification = false;
    //             verificationProduct = null;
    //         }
    //     }
    //     console.log('MSV JSON productRelations: ', JSON.stringify(configuration.productRelations));
    //     console.log('MSV configuration.assetId: ', configuration.assetId);
    // }

    if (configuration.useAlreadyCreatedCase) {
        configuration.caseIdFromPage = configuration.originalCaseId;
    }

    if (configuration.sendOutputOnSubmit) {
        checkAndSendOutput();
    }

    Visualforce.remoting.Manager.invokeAction(
        migrationDefaults.remoteActions.createCase,
        configuration.accountId,
        configuration.assetId,
        JSON.stringify(configuration.productList),
        JSON.stringify(configuration.productRelations),
        JSON.stringify(configuration.apiFields),
        configuration.note,
        //            configuration.generatedDocument,
        JSON.stringify(configuration.generatedDocumentMap),
        configuration.selectedAssetMainElement,
        exceptionDate,
        exceptionType,
        configuration.selectedAssetChildElement,
        configuration.migrationProcessId,
        elDocDistrib,
        mobilityCourierBranch,
        (selectedProductRelationId ? selectedProductRelationId : ''),
        (lowestPriority ? lowestPriority : 0),
        configuration.caseIdFromPage,
        typeOfOperation,
        configuration.editMode,
        /*        (forVerification ? forVerification : false),
                (assetsForVerification ? assetsForVerification : ''),*/
        function(result, event) {
            console.log('result: ', result);
            if (event.status && result) {
                if (!result.errorMessage) {
                    dismissLoadingModal();
                    createdCaseId = result.theCaseId;
                    if (!filesIsEmpty) {
                        $('#modal-attachment-loading').modal('show');
                        sendAttachments();
                    } else {
                        caseSendOkHandling();
                    }
                    //openItemAndCloseCurrent(result.theCaseId);
                    //window.location.assign('/apex/MigrationPremium?caseId=' + result);
                } else {
                    dismissLoadingModal();
                    alertify.alert(result.errorMessage);
                }
            } else {
                alertify.alert('Chyba', $Label.PCF_Create_Case_Error_Msg + ' ' + event.message);
                $("#submit-btn").removeAttr("disabled");
                dismissLoadingModal();
            }
        });
}

function sendAttachments(result, event) {
    if (attachmentSendIndex == -1) {
        $('#attachment-progressbar').width('0px');
        attachmentSendIndex++;
    } else if (result && result > 0) {
        //console.log('Files size: ' + configuration.filesSize);
        //console.log('Loaded percent: ' + (configuration.loadedSize / configuration.filesSize));
        //console.log('Loaded size: ' + configuration.loadedSize);
        configuration.loadedSize = (Number(configuration.loadedSize) + Number(result));
        //console.log('New size: ' + configuration.loadedSize);
        var loaded = (configuration.loadedSize / configuration.filesSize) * 100;
        //console.log('New percentage: ' + loaded);
        var parentWidth = $('#attachment-progressbar').parent().width();
        $('#attachment-progressbar').width(loaded / 100 * parentWidth);
        $('#att-loaded').text('Dokončeno: ' + Math.round(loaded) + '%');
        attachmentSendIndex++;
    }

    if (configuration.files[attachmentSendIndex] && (attachmentSendIndex == 0 || (event.status && result))) {
        if (configuration.useAlreadyCreatedCase === true && configuration.originalCaseId) {
            createdCaseId = configuration.originalCaseId;
        }
        attachmentData = JSON.stringify(configuration.files[attachmentSendIndex]);
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.saveCaseAttachment,
            attachmentData,
            createdCaseId,
            sendAttachments);
    } else {
        if (event.status && result) {
            attachmentSendIndex = -1;
            configuration.loadedSize = 0;
            setTimeout(caseSendOkHandling, 1);
        } else {
            $('#modal-attachment-loading').modal('dismiss');
            alertify.confirm('Chyba', $Label.PCF_Attachment_Send_Err, function() {
                $('#modal-attachment-loading').modal('show');
                sendAttachments('-1', { status: true });
            }, function() {
                attachmentSendIndex = -1;
                configuration.loadedSize = 0;
                $('#modal-attachment-loading').modal('dismiss');
                dismissLoadingModal();
            }).set('labels', { ok: 'Opakovat', cancel: 'Zrušit' });
        }
    }
}

//function caseSendPreOkHandling(){
//    Visualforce.remoting.Manager.invokeAction(
//        migrationDefaults.remoteActions.assignCase,
//        createdCaseId,
//        configuration.migrationProcessId,
//        function(result, event){
//            if (event.status && result) {
//                caseSendOkHandling();
//            } else {
//                alertify.alert('Chyba', $Label.PCF_Case_Assignment_Error + ' ' + event.message);
//                $("#submit-btn").removeAttr("disabled");
//                $('#modal-attachment-loading').modal('dismiss');
//                dismissLoadingModal();
//            }
//    });
//}

function caseSendOkHandling() {
    var msg;
    if (typeOfOperation == 'submit') {
        /*if(configuration.migrationProcessName === 'Account_Cancellation'){
            msg = $Label.PCF_Saved_Cancellation_Config;
        } else{*/
        msg = $Label.PCF_Default_Case_Sent_Msg;
        //}
    } else {
        if (configuration.productList) {
            var hasChild = false;
            for (var i in configuration.productList.itemMap) {
                var map = configuration.productList.itemMap[i];
                if (JSON.stringify(map.childItemMap) !== '{}') {
                    hasChild = true;
                }
            }
            /*if(hasChild){
                msg = migrationDefaults.labels.pcfDraftSavedWithCard;
            }else{*/
            msg = migrationDefaults.labels.pcfDraftSaved;
            //}
        }
    }
    if (configuration.caseMessage) {
        if (typeOfOperation == 'draft' && (configuration.migrationProcessName === 'Heritage' || configuration.migrationProcessName === 'PPF')) {
            msg = 'Konfigurace byla úspěšně uložena.';
        } else {
            msg = configuration.caseMessage;
        }
    }
    /*if (configuration.pretermDocSwitch && (configuration.migrationProcessName !== 'PPF')) {
        if (migrationDefaults.fsval.errSize == 0) {
            msg += ' ' + $Label.PCF_PreContract_Doc_Sent_To_ELB;
        }
        if (migrationDefaults.fsval.errSize == 1) {
            msg += ' ' + $Label.PCF_PreContract_Doc_Sent_To_Email + ' ' + migrationDefaults.fsval.email;
        }
    }*/
    alertify.alert('Informace', msg, function() {
        if (configuration.isWdeUser) {
            closeCurrentOnly();
        } else {
            // openItemAndCloseCurrent(createdCaseId);
            openItemAndCloseCurrent(configuration.accountId);
        }
    });
    $('#modal-attachment-loading').modal('dismiss');
    dismissLoadingModal();
}

function isCheckedMandatoryCheckboxes() {
    for (itemIndex in configuration.productRelations) {
        for (childItemIndex in configuration.productRelations[itemIndex]) {
            var childItem = configuration.productRelations[itemIndex][childItemIndex];
            for (paramIndex in childItem.productParameterDefaults) {
                var param = childItem.productParameterDefaults[paramIndex];
                if (param.isForFinalValidation && !param.value) {
                    return false;
                }
            }
        }
    }
    return true;
}

function removeSensitiveDataFromConfiguration() {
    for (index in configuration.productList.itemMap) {
        var item = configuration.productList.itemMap[index];
        if (item.theAsset) {
            item.theAsset.Account_Number__c = null;
            if (item.theAsset.Assets__r) {
                item.theAsset.Assets__r = null;
            }
        }
        if (item.childItemMap) {
            for (childIndex in item.childItemMap) {
                var childItem = item.childItemMap[childIndex];
                if (childItem.theAsset) {
                    childItem.theAsset.Account_Number__c = null;
                }
            }
        }
    }
}

function changeEnhancedProductParameterValue(parentId, productId, selectIndexId, elementId, stringValue) {
    if (typeof parentId !== 'undefined' && typeof productId !== 'undefined') {
        var strVal = stringValue ? stringValue : $('#' + elementId + ' option:selected').text();
        configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].stringValue = strVal;
    }
}
// changeProductParameterValue(parentId, productId, selIndexIdChild, selectOptionsList[i].value, null, null, childSyncElName );

function changeProductParameterValue(parentId, productId, selectIndexId, parameterValue, assetValue, isForFinalValidation, syncElementName, elDocDistAgrChangeCall) {
    //configuration.productRelations[parentId][productId].productParameters[sectionIndexId].childParameterList[selectIndexId].selectedParameterId = parameterId;
    if (typeof parentId !== 'undefined' && typeof productId !== 'undefined') {
        if (!configuration.productRelations[parentId][productId].productParameterDefaults) {
            configuration.productRelations[parentId][productId].productParameterDefaults = new Object();
        }
        if (configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId]) {
            //console.log('som tu 5: ', syncElementName);
            if (configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].assetValue && (typeof parameterValue === 'undefined' || parameterValue === null)) {
                //console.log('som tu 2: ');
                configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].value = configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].assetValue;
                configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].syncElementName = syncElementName;
            } else if ($('[data-syblings~="' + selectIndexId + '"').val() && !parameterValue) {
                //console.log('som tu 1: ', $('[data-productparameterid~="' + selectIndexId + '"'));
                //console.log('som tu 1 neco jinyho: ', $('[data-syblings~="' + selectIndexId + '"'));
                //console.log('som tu 1 neco jinyho: ', $('[data-syblings~="' + selectIndexId + '"').val());
                //console.log('som tu 1 selectIndexId: ', selectIndexId);
                configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].value = $('[data-syblings~="' + selectIndexId + '"').val();
                configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].syncElementName = syncElementName;
            } else {
                //console.log('som tu 3: ');
                configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].value = parameterValue;
                configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].syncElementName = syncElementName;
            }
            //console.log('value after: ' , configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].value);
        } else {
            //if(parameterValue && syncElementName){
            configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId] = {
                value: parameterValue,
                assetValue: assetValue,
                isForFinalValidation: isForFinalValidation,
                syncElementName: syncElementName
            };
            //}
        }
        var idParts = parentId.split('-');
        var pageId = idParts[0];
        if (!elDocDistAgrChangeCall) {
            setElDocDistAgrSelectVisibility(pageId);
        }
    }
    if (typeof selectIndexId !== 'undefined' && configuration.apiFields[selectIndexId]) {
        //console.log('configuration.apiFields[selectIndexId].value ', configuration.apiFields[selectIndexId].value);
        configuration.apiFields[selectIndexId].value = parameterValue;
    }
}

function changeProductParameterMultiValue(parentId, productId, selectIndexId, parameterValue, assetValue) {
    //configuration.productRelations[parentId][productId].productParameters[sectionIndexId].childParameterList[selectIndexId].selectedParameterId = parameterId;
    if (!configuration.productRelations[parentId][productId].productParameterDefaults) {
        configuration.productRelations[parentId][productId].productParameterDefaults = new Object();
    }
    if (configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId]) {
        configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId].multiValue = parameterValue;
    } else {
        configuration.productRelations[parentId][productId].productParameterDefaults[selectIndexId] = {
            multiValue: parameterValue,
            assetValue: assetValue
        };
    }
    if (configuration.apiFields[selectIndexId]) {
        configuration.apiFields[selectIndexId].value = parameterValue;
    }
}


// UTILS methods

String.prototype.format = function() {
    var args = [].slice.call(arguments);
    return this.replace(/(\{\d+\})/g, function(a) {
        return args[+(a.substr(1, a.length - 2)) || 0];
    });
};

function openItem(itemId) {
    if (sforce.console.isInConsole()) {
        sforce.console.getEnclosingPrimaryTabId(function(result) {
            sforce.console.openSubtab(result.id, '/' + itemId, consoleNavigateToOpenSubtab);
        });
    } else {
        window.top.location.href = '/' + itemId;
    }

    return false;
}

function openItemAndCloseCurrent(itemId) {
    var url = itemId;
    if (sforce.console.isInConsole()) {
        if (configuration.migrationProcessName === 'Account_Cancellation') {
            closeCurrentOnly();
        } else {
            sforce.console.getEnclosingPrimaryTabId(function(result) {
                sforce.console.openSubtab(result.id, url, true, configuration.migrationProcessTitle, null, consoleNavigateToOpenSubtab);
            });
            closeCurrentOnly();
        }
    } else {
        if (parent) {
            if (configuration.migrationProcessName === 'Account_Cancellation') {
                openInLwc('closeCurrentSubTab');
            } else {
                openInLwc('openSubTabWithNewUrl', url, configuration.migrationProcessTitle);
            }
        } else {
            window.top.location.href = '/apex/MigrationPremium?caseId=' + itemId;
        }
    }
    return false;
}

function closeCurrentOnly() {
    if (sforce.console.isInConsole()) {
        sforce.console.getEnclosingTabId(function(result) {
            sforce.console.closeTab(result.id, logErrorCallback);
        });
    } else {
        if (parent) {
            openInLwc('closeCurrentSubTab');
        }
    }
}

var showLoadingModalCounter = 0;

function showLoadingModal() {
    showLoadingModalCounter++;
    $('#modal-waiting-dialog').modal('show');
}

function dismissLoadingModal() {
    showLoadingModalCounter--;
    if (showLoadingModalCounter > 0) {
        return;
    }
    $('#modal-waiting-dialog').modal('dismiss');
    $('.slds-backdrop').removeClass('slds-backdrop--open');
    $('#modal-waiting-dialog').removeClass('slds-fade-in-open').attr('aria-hidden', 'true');
    $('#modal-waiting-dialog').removeClass('slds-show');
    $('.slds-backdrop').remove();
}

function generatePretermDocument(guid, element) {
    var svgs = element.getElementsByClassName('print-ico');
    if (svgs.length === 3) {
        svgs[2].style.display = "none";
        svgs[1].style.display = "inline";
    }

    var visibleSvgs = $('.print-ico.ok').filter(function() {
        return !($(this).css('visibility') == 'hidden' || $(this).css('display') == 'none');
    });
    if (visibleSvgs.length == pretermDocListLength) {
        allPreContractDocumentPrinted = true;
        $('.printmsg-text').css('display', 'none');
        $('li.printmsg').attr('class', 'slds-dropdown__item print-enabled');
        $('svg.print-ico.nok-printer').attr('class', 'print-ico printer'); // on svg element does not work: .removeClass('nok-printer').addClass('printer');
    }

    var url = migrationDefaults.urls.dmsfn + '/HTTPAPI/getViewer?DocumentId=' + guid;
    var label = 'Předsmluvní dokument';
    if (sforce.console.isInConsole()) {
        sforce.console.getEnclosingPrimaryTabId(function(primaryResult) {
            callBackopenTab(primaryResult, url, label);
        });
    } else {
        if (parent) {
            openInLwc('openSubTabWithNewUrl', url, label);
        } else {
            window.open(url, label);
        }

    }

    /*    if (printingDuty && !sendOutputSent && !configuration.savedConfiguration) {
            var offerType = configuration.migrationProcessName == 'PPP' ? '8' : '2';
            Visualforce.remoting.Manager.invokeAction(
                migrationDefaults.remoteActions.sendOutput,
                configuration.cuid,
                38,
                configuration.cuid,
                offerType,
                configuration.sentOutputType,
                configuration.migrationProcessName,
                sendOutputDataListPap,
                function(result, event) {
                sendOutputSent = true;
                    //console.log(event);
                }
            );
        }*/
}

function renderPdf(teplateCode, messageBeforePrint, url, element, openInNewWindow, bioSign) {
    console.log('rendering PDF: ' + teplateCode);
    showLoadingModal();
    syncElemJSON = buildSyncElemJSON($('[data-syncElemName!="undefined"][data-syncElemName]'))

    // var barData = 'Jmeno: ' + configuration.accName + ', Prijmeni: ' + configuration.accSurname + ', Rodne cislo: ' + configuration.accBN;
    // PDF417.init(barData);
    // var barcode = PDF417.getBarcodeArray();
    // // block sizes (width and height) in pixels
    // var bw = 1;
    // var bh = 1;

    // var canvas = document.createElement('canvas');
    // canvas.width = bw * barcode['num_cols'];
    // canvas.height = bh * barcode['num_rows'];
    // var ctx = canvas.getContext('2d');

    // // graph barcode elements
    // var y = 0;
    // // for each row
    // for (var r = 0; r < barcode['num_rows']; ++r) {
    //     var x = 0;
    //     // for each column
    //     for (var c = 0; c < barcode['num_cols']; ++c) {
    //         if (barcode['bcode'][r][c] == 1) {
    //             ctx.fillRect(x, y, bw, bh);
    //         }
    //         x += bw;
    //     }
    //     y += bh;
    // }
    // var img = new Image();
    // img.src = canvas.toDataURL();
    // canvas.toBlob(function(blob) {
    //     var reader = new FileReader();
    //     reader.onload = function(e) {
    //         const blobText = window.btoa(e.target.result);
    //         console.log(blobText);
    //         let barcodeFile = { uniqueId: guid(), name: 'barcode.png', size: blob.size, data: blobText };
    //         console.log(barcodeFile);
    Visualforce.remoting.Manager.invokeAction(
        migrationDefaults.remoteActions.prepareCaseForTemplate,
        configuration.migrationProcessName,
        JSON.stringify(syncElemJSON),
        function(result, event) {
            console.log(result);
            console.log(event);
            if (result) {
                configuration.caseIdFromPage = result.theCaseId;
                window.open('/apex/renderAsPdf?caseId=' + result.theCaseId + '&template=' + teplateCode); // + '&displayBar=' + result.barcodeUrl);
            }
            dismissLoadingModal();
        }
    );
    //     }
    //     reader.readAsBinaryString(blob);
    // });
}

function buildSyncElemJSON(elemArray) {
    jsonObj = [];
    elemArray.each(function() {
        if (!($(this).parent().parent().hasClass('migration-hide') || $(this).parent().parent().parent().hasClass('migration-hide'))) {
            item = {};
            item["title"] = $(this)[0].getAttribute("data-syncelemname");
            item["value"] = getElementValue($(this));
            jsonObj.push(item);
        }
    });
    jsonObj.push(getRndDocNumber());
    return jsonObj;
}

function getRndDocNumber() {
    item = {};
    item["title"] = 'rndId';
    item["value"] = guid();
    return item;
}

function getElementValue(elem) {
    if (elem.prop('nodeName') == 'SELECT') {
        return elem.find(":selected").text();
    }
    if (elem.is(':checkbox')) {
        return elem.is(":checked");
    }
    return elem[0].value;
}

/*function generateIstsDocument(remoteMethodName, dmsDocumentId, templateCode, messageBeforePrint, url, element, openInNewWindow, bioSign) {
    if (!printingDuty || allPreContractDocumentPrinted) {
        if (messageBeforePrint) {
            alertify.alert('Upozornění', messageBeforePrint, function() {});
        }
        if (url) {
            openNonIstsDocument(url, $(element).children('p').text(), openInNewWindow);
        } else {
            showLoadingModal();
            var elDocDist = getElDocDistrib();

            Visualforce.remoting.Manager.invokeAction(
                remoteMethodName,
                configuration.accountId,
                configuration.assetId,
                dmsDocumentId,
                templateCode,
                JSON.stringify(configuration.productList),
                JSON.stringify(configuration.productRelations),
                configuration.selectedAssetMainElement,
                configuration.selectedAssetChildElement,
                configuration.migrationProcessId,
                elDocDist,
                configuration.caseIdFromPage,
                configuration.editMode,
                function(result, event) {
                    if (result) {
                        if (configuration.migrationProcessName === 'Account_Cancellation' && result == 'CANCEL_ACC_CANCEL_ERROR') {
                            alert('Chyba generování dokumentu. Pro storno žádosti je nejprve nutno žádost založit.');
                        } else {
                            configuration.generatedDocumentMap[dmsDocumentId] = result;
                            if (bioSign) {
                                var bioToggle = document.querySelector('#bio-signature-doc-'+dmsDocumentId+'-'+templateCode);
                                bioToggle.setAttribute('data-dmsdocid', result);
                                bioToggle.removeAttribute("disabled");
                            }
                            lastGeneratedDocId = result;
                            var reservation = configuration.migrationProcessName === 'Mobility_income' && $('[data-sign-method-callid]:selected').length < 1 && !$('[data-sign-method-callid]:selected').parent().parent().parent().hasClass('migration-hide') ? '&reservation=1' : '';
                            var prodNumber = configuration.migrationProcessName === 'Mobility_income' && !($('*[data-syncElemName="csobProductNumberKc"]').parent().parent().hasClass('migration-hide') && $('*[data-syncElemName="csobProductNumberKcExist"]').parent().parent().hasClass('migration-hide')) ? $('*[data-syncElemName="csobProductNumberKc"]').val() ? '&prodNumber=' + $('*[data-syncElemName="csobProductNumberKc"]').val() : '&prodNumber=' + $('*[data-syncElemName="csobProductNumberKcExist"]').children("option:selected").text().split(' - ')[0].trim() : '';
                            if (element) {
                                element.style.background = "#12a8cf";
//                                element.setAttribute("style", "background-color:#12a8cf");
                            }
                            if (sforce.console.isInConsole()) {
                                sforce.console.getEnclosingPrimaryTabId(function(primaryResult) {
                                    callBackopenTab(primaryResult, '/apex/IstsIframeGdprPage?id=' + result + '&migrationPremiumId=' + configuration.uniqueId + '&storeToJSK=1&migProc=' + configuration.migrationProcessName + reservation + prodNumber, 'ISTS');
                                });
                            } else {
                                //window.location = '/apex/IstsIframeGdprPage?id=' + result + '&migrationPremiumId=' + configuration.uniqueId + '&storeToJSK=1&migProc=' + configuration.migrationProcessName + reservation + prodNumber;
                                decodedUrl = '/apex/IstsIframeGdprPage?id=' + result + '&migrationPremiumId=' + configuration.uniqueId + '&storeToJSK=1&migProc=' + configuration.migrationProcessName + reservation + prodNumber;
                                if (parent) {
                                    openInLwc('openSubTabWithNewUrl', decodedUrl, 'ISTS');
                                }else{
                                    window.open(decodedUrl);
                                }
                            }
                       }
                    } else {
                        alert('Chyba generování dokumentu: ' + event.message);
                    }
                    dismissLoadingModal();
                });
        }
    }
    return false;
}*/

/*function bioSignature(){
    showLoadingModal();
    var dmsDocIdList = $.map($('input[id^="bio-signature-doc-"]:checked'), function (elem) {
        return elem.dataset.dmsdocid;
    });
    console.log('dmsDocIdList: ' + dmsDocIdList);
    if (dmsDocIdList.length < 1) {
        dismissLoadingModal();
        showNotifyMessage(migrationDefaults.labels.pcfBioSignNoSelectedDoc, 'warning');
    } else {
        */
/*var bioAssetId = configuration.assetId ? configuration.assetId : assetList.length > 0 ? assetList[0] : null;
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.callSignBiometricEnvelope,
            dmsDocIdList,
            bioAssetId,
            configuration.cuid,
            configuration.accName,
            configuration.accSurname,
            function(result, event) {
                dismissLoadingModal();
                if (result && result.status == 'OK') {
                    console.log('callSignBiometricEnvelope: 0K');
                    showNotifyMessage(migrationDefaults.labels.pcfBioSignSendToTablet, 'success');
                } else {
                    var errMessage = result ? result.message : 'Neznámá chyba.';
                    console.log('callSignBiometricEnvelope: K0');
                    console.log(errMessage);
                    console.log(result ? result.devMessage : '');
                    showNotifyMessage(errMessage, 'error');
                }
            }
        );*/
/*
    }
}*/

//var generatedIstsDocument = function(result) {
//    //alert(result.message);
//    //console.log('generateDocument result message: ' + result.message);
//    if (result.message == configuration.uniqueId) {
//        configuration.istsDocumentIsGenerated = true;
//    }
//};

function callBackopenTab(result, recordid, recordname) {
    sforce.console.openSubtab(result.id, recordid, true, recordname, null);
}

function checkIfEnableSubmitButton() {
    for (var printBtnId in configuration.printButtons) {
        var item = configuration.printButtons[printBtnId];
        if (!item) {
            return;
        }
    }
    $("#submit-btn").prop("disabled", false);
    $("#submit-btn").removeAttr('disabled');
}

function showNotifyMessage(message, messageType) {
    var oneHtml = "";
    oneHtml += '             <div class="slds-notify_container">';
    oneHtml += '                <div class="slds-notify slds-notify--toast slds-theme--' + messageType + '" role="alert">';
    oneHtml += '                  <span class="slds-assistive-text">Success</span>';
    oneHtml += '                  <button class="slds-button slds-button--icon-inverse slds-notify__close">';
    oneHtml += '                    <svg aria-hidden="true" class="slds-button__icon slds-button__icon--large">';
    oneHtml += '                      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons/utility-sprite/svg/symbols.svg#close"></use>';
    oneHtml += '                    </svg>';
    oneHtml += '                    <span class="slds-assistive-text">Zavřít</span>';
    oneHtml += '                  </button>';
    oneHtml += '                  <div class="notify__content slds-grid">';
    oneHtml += '                    <svg aria-hidden="true" class="slds-icon slds-icon--small slds-m-right--small slds-col slds-no-flex">';
    oneHtml += '                      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons/utility-sprite/svg/symbols.svg#notification"></use>';
    oneHtml += '                    </svg>';
    oneHtml += '                    <div class="slds-col slds-align-middle">';
    oneHtml += '                      <h2 class="slds-text-heading--small ">' + message + '</h2>';
    oneHtml += '                    </div>';
    oneHtml += '                  </div>';
    oneHtml += '                </div>';
    oneHtml += '              </div>';

    jQuery('#toast_notify').show().delay(0).fadeIn(600);
    jQuery('#toast_notify').hide().delay(3000).fadeOut(600);
    jQuery("#toast_notify").html(oneHtml);
}


function addFile(fileName, fileData, size) {
    if ((size) > 3145728) {
        alertify.alert('Chyba', "Maximální velikost každé přílohy je 3Mb.", function() {});
        return;
    }

    configuration.filesSize += size;
    if (configuration.files) {
        configuration.files.push({
            uniqueId: guid(),
            name: fileName,
            data: fileData,
            size: size
        });
    } else {
        configuration.files = [{
            uniqueId: guid(),
            name: fileName,
            data: fileData,
            size: size
        }];
    }
    rePaintFilesTable();
}

function removeFile(uniqueId) {
    if (uniqueId && configuration.files) {
        configuration.files.forEach(function(item) {
            if (item.uniqueId === uniqueId) {
                configuration.filesSize -= item.size;
                remove(configuration.files, item);
                rePaintFilesTable();
                return;
            }
        });
    }
    return false;
}

function rePaintFilesTable() {
    var container = $('#attachedFilesContent');
    var html = '';
    //var item;
    /*for(let index in configuration.files){
        item = configuration.files[index];
        if(item){
            html += '<div>{0}</div>'.format(item.name);
        }
    }*/
    configuration.files.forEach(function(item) {
        if (item) {
            html += '<div class="attachments-row">{0}&nbsp;(velikost souboru: {1}&nbsp;Mb)&nbsp;&nbsp;<a href="#" onclick="return removeFile(\'{2}\')"><img style="height: 20px;" src="{3}" alt="Odstranit"/></a></div>'
                .format(item.name, ((Math.round((item.size / 1048576) * 100) / 100)), item.uniqueId, migrationDefaults.images.cancel);
        }
    })
    if (html) {
        container.html(html);
    } else {
        container.html('Zatím nebyl přiložen žádný soubor.');
    }
}

function openScube2(cacheId, endpoint, endpointCacheId, json) {
    console.log(cacheId);
    console.log(endpoint);
    console.log(endpointCacheId);
    console.log(json);
    var data = {
        cacheId: cacheId,
        endpoint: endpoint,
        endpointCacheId: endpointCacheId,
        json: json
    }
    console.log(data);
    openScube(data);
}

function openScube(data) {
    var event = {
        status: true
    }
    console.log(data);
    openUrlAndSetCacheId(data, event);
    /*if (data) {
        var form = document.createElement("form");
        form.setAttribute("method", "POST");
        form.setAttribute("action", migrationDefaults.urls.scube);
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "datatransport");
        hiddenField.setAttribute("value", data);
        form.appendChild(hiddenField);
        document.body.appendChild(form);
        var uuid = guid();
        window.open('', uuid, 'location=no,toolbar=no,menubar=no,scrollbars=yes,resizable=yes, width=1320,height=767');
        form.target = uuid;
        form.submit();
    }*/
    return false;
}

function showTooltip(element) {
    //console.log(element);
    var jqElement = $(element);
    jqElement.append('<div class="tooltip"><p>{0}</p></div>'.format(jqElement.data().text));
    var tooltip = jqElement.find(".tooltip");
    var tooltipHeight = tooltip.height();
    tooltip.css({
        'top': (-tooltipHeight - 15) + 'px'
    });
}

function dismissTooltip(element) {
    $("div.tooltip").remove();
}

function getHelpTextSpan(helText) {
    return '&nbsp;<span class="question" data-text="{0}" onmouseover="showTooltip(this);" onmouseout="dismissTooltip(this);">?</span>'.format(helText);
}
// UTILITY Methods

var consoleNavigateToOpenSubtab = function consoleNavigateToOpenSubtab(success, tabId) {
    if (success) {
        sforce.console.focusSubtabById(tabId);
    }
};

var logErrorCallback = function(result) {
    if (result.error) {
        //console.log("Error message is " + result.error);
    }
};

function decodeString(data) {
    var parser = new DOMParser;
    var dom = parser.parseFromString(data, 'text/html');
    return dom.body.textContent;
}

function objectLength_Modern(object) {
    return Object.keys(object).length;
}

function objectLength_Legacy(object) {
    var length = 0;
    for (var key in object) {
        if (object.hasOwnProperty(key)) {
            ++length;
        }
    }
    return length;
}

function remove(array, element) {
    const index = array.indexOf(element);
    array.splice(index, 1);
}

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

var objectLength =
    Object.keys ? objectLength_Modern : objectLength_Legacy;

function investmentRelations(relations) {
    var div = document.createElement("div");
    div.setAttribute("style", "margin-top: 15px;");
    var divTabContent = document.createElement("div");
    divTabContent.setAttribute("class", "slds-table");
    var divFormHorizontal = document.createElement("div");
    divFormHorizontal.setAttribute("class", "slds-form--horizontal");
    divFormHorizontal.setAttribute("style", "text-align: left;");
    var divFormElement = document.createElement("div");
    divFormElement.setAttribute("class", "slds-form-element");
    var divElementControl = document.createElement("div");
    divElementControl.setAttribute("class", "slds-form-element__control");

    var label = document.createElement("label");
    label.setAttribute("class", "slds-form-element__label headline");
    label.setAttribute("for", "selectInvestment");
    label.setAttribute("style", "display: inline-block");
    label.innerHTML = 'Zvolte přístup';
    var select = document.createElement("select");
    select.id = 'selectInvestment';
    select.setAttribute("class", 'slds-select valid')
    select.onchange = function() {
        displayRelation(relations[this.value]);
    }
    var resultTab = document.getElementById("a-transitions-tab");
    if (resultTab) {
        resultTab.onclick = function() {
            calculateInvestments(relations[document.getElementById("selectInvestment").value]);
        }
    }
    var option = document.createElement("option");
    option.text = '--- Vyberte ---';
    select.appendChild(option);
    for (i = 0; i < relations.length; i++) {
        var option = document.createElement("option");
        option.value = [i];
        option.text = relations[i].Default_Name__c;
        select.appendChild(option);
    }
    divElementControl.appendChild(select);
    divFormElement.appendChild(label);
    divFormElement.appendChild(divElementControl);
    div.appendChild(divFormElement);
    divFormHorizontal.appendChild(div);
    divTabContent.appendChild(divFormHorizontal);

    document.getElementById("product-settings-tab-0").appendChild(divTabContent);

}

function displayRelation(relation) {
    if (document.getElementById("investmentTable")) {
        $("#investmentTable").remove();
    }

    if (relation) {
        var investmentTable = document.createElement("table");
        investmentTable.setAttribute("id", 'investmentTable');
        investmentTable.setAttribute("Class", 'slds-table slds-table_cell-buffer slds-table_bordered');
        investmentTable.setAttribute("style", "margin-top: 30px");
        investmentTable.innerHTML += '<tr class="slds-line-height_reset" style="background-color: #fafafa;">' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">Zvolená strategie</div>' +
            '</th>' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate"></div>' +
            '</th>' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">' + migrationDefaults.translations.base + '</div>' +
            '</th>' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">' + migrationDefaults.translations.supplement + '</div>' +
            '</th>' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">' + migrationDefaults.translations.theme + '</div>' +
            '</th>' +
            '</tr>';
        var BaseName = "Base__c" in relation ? relation.Base__c : '';
        var SuppName = "Supplement__c" in relation ? relation.Supplement__c : '';
        var ThemeName = "Theme__c" in relation ? relation.Theme__c : '';
        investmentTable.innerHTML += '<tr class="slds-hint-parent">' +
            '<td>' + relation.Default_Name__c + '</td>' +
            '<td></td>' +
            '<td>' + BaseName + '</td>' +
            '<td>' + SuppName + '</td>' +
            '<td>' + ThemeName + '</td>' +
            '</tr>'
        investmentTable.innerHTML += '<tr class="slds-line-height_reset" style="background-color: #fafafa;">' +
            '<th class="slds-text-title_caps" scope="col">Portfolio</th>' +
            '<th class="slds-text-title_caps" scope="col">Typ</th>' +
            '<th class="slds-text-title_caps" scope="col">Max. %</th>' +
            '<th class="slds-text-title_caps" scope="col">Min. Hodnota</th>' +
            '<th class="slds-text-title_caps" scope="col">Priorita</th>' +
            '</tr>'
        for (j = 0; j < relation.Product_Parameters__r.length; j++) {
            investmentTable.innerHTML += '<tr class="slds-hint-parent">' +
                '<td>' + relation.Product_Parameters__r[j].Parameter_Label__c + '</td>' +
                '<td>' + relation.Product_Parameters__r[j].Type__c + '</td>' +
                '<td>' + relation.Product_Parameters__r[j].Calc_Max_Percentage__c + '</td>' +
                '<td>' + relation.Product_Parameters__r[j].Calc_Min_Value__c + ' Kč</td>' +
                '<td>' + relation.Product_Parameters__r[j].Order_in_Section__c + '</td>' +
                '</tr>'
        }
        document.getElementById("product-settings-tab-0").appendChild(investmentTable);
    }
}

function calculateInvestments(relation) {
    pppConfig = [];
    if (document.getElementById("err-div")) {
        $("#err-div").remove();
    }
    if (document.getElementById("calculationTable")) {
        $("#calculationTable").remove();
    }
    if (document.getElementById("mainResultDiv")) {
        $("#mainResultDiv").remove();
    }
    if (document.getElementById("resultHeader")) {
        $("#resultHeader").remove();
    }

    var mainInput = $('[id^="GENERAL"]')[0];
    if (relation && mainInput.value > 0) {
        mainInput.onchange = function() {
            calculateInvestments(relation);
        }
        var header = document.createElement("div");
        header.setAttribute("id", "resultHeader");
        header.setAttribute("style", "background-color: #fafafa; padding: 8px;");
        header.innerHTML = relation.Default_Name__c;

        var table = document.createElement("table");
        table.setAttribute("id", 'calculationTable');
        table.setAttribute("Class", 'slds-table slds-table_cell-buffer slds-table_bordered');
        table.setAttribute("style", "margin-top: 15px;");
        table.innerHTML += '<tr class="slds-line-height_reset" style="background-color: #fafafa;">' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">Doporučená skladba</div>' +
            '</th>' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">Typ</div>' +
            '</th>' +
            '<th class="slds-text-title_caps" scope="col">' +
            '<div class="slds-truncate">Částka k investici</div>' +
            '</th>' +
            '</tr>';
        var base = [];
        var supplement = [];
        var theme = [];
        var ri = [];
        /*for (j = 0; j < relation.Product_Parameters__r.length; j++) {
            if (relation.Product_Parameters__r[j].Type__c === migrationDefaults.icalc.base || relation.Product_Parameters__r[j].Type__c === migrationDefaults.translations.base) {
                base.push(relation.Product_Parameters__r[j]);
            } else if (relation.Product_Parameters__r[j].Type__c === migrationDefaults.icalc.supplement || relation.Product_Parameters__r[j].Type__c === migrationDefaults.translations.supplement) {
                supplement.push(relation.Product_Parameters__r[j]);
            } else if (relation.Product_Parameters__r[j].Type__c === migrationDefaults.icalc.theme || relation.Product_Parameters__r[j].Type__c === migrationDefaults.translations.theme) {
                theme.push(relation.Product_Parameters__r[j]);
            } else if (relation.Product_Parameters__r[j].Type__c === migrationDefaults.icalc.regular_investment || relation.Product_Parameters__r[j].Type__c === migrationDefaults.translations.regular_investment) {
                ri.push(relation.Product_Parameters__r[j]);
            }
        }*/

        var baseValue = (Number(mainInput.value) / 100) * Number(relation.Base__c);
        var investedBase = [];
        if (base.length > 0) {
            investedBase = calculateParameters(Number(mainInput.value), baseValue, base);
            if (investedBase == false) {
                calculationError();
                return;
            }
            addResultToTable(table, investedBase);
        }

        var supplementValue = (Number(mainInput.value) / 100) * Number(relation.Supplement__c);
        var investedSupplement = [];
        if (supplement.length > 0) {
            investedSupplement = calculateParameters(Number(mainInput.value), supplementValue, supplement);
            if (investedSupplement == false) {
                calculationError();
                return;
            }
            addResultToTable(table, investedSupplement);
        }

        var themeValue = (Number(mainInput.value) / 100) * Number(relation.Theme__c);
        var investedTheme = [];
        if (theme.length > 0) {
            investedTheme = calculateParameters(Number(mainInput.value), themeValue, theme);
            if (investedTheme == false) {
                calculationError();
                return;
            }
            addResultToTable(table, investedTheme);
        }

        var regInvestment = [];
        if (ri.length > 0) {
            table.innerHTML += '<tr class="space"><td class="sp"></td><td class="sp"></td><td class="sp"></td></tr>';
            table.innerHTML += '<tr class="slds-hint-parent" style="background-color: #fafafa;"><th>Návrh pravidelných investic</th><th></th><th></th></tr>';
            regInvestment = calculateParameters(Number(mainInput.value), Number(mainInput.value), ri);
            addResultToTable(table, regInvestment);
        }

        setPPPConfig(investedBase.concat(investedSupplement).concat(investedTheme).concat(regInvestment));

        document.getElementById("product-settings-tab-1").appendChild(header);
        document.getElementById("product-settings-tab-1").appendChild(table);
    } else {
        var div = document.createElement("div");
        div.id = 'mainResultDiv';
        div.innerHTML = 'Vložte částku a parametry pro výpočet.';
        document.getElementById("product-settings-tab-1").appendChild(div);
    }
}

function setPPPConfig(pps) {
    for (i = 0; i < pps.length; i++) {
        addToPPP(pps[i].Parameter_Label__c, pps[i].Id, pps[i].investedMoney, pps[i].Type__c);
    }
}

function addToPPP(label, ppId, amount, type) {
    pppConfig.push({
        'label': label,
        'productParameterId': ppId,
        'amount': amount,
        'type': type
    });
}

function calculationError() {
    var div = document.createElement("div");
    div.id = 'mainResultDiv';
    div.innerHTML = 'Nedostatečná Částka';
    document.getElementById("product-settings-tab-1").appendChild(div);
}

function calculateParameters(originalValue, value, parameterList) {
    var originalValue = Number(originalValue.toFixed(0));
    value = Number(value.toFixed(0));
    var returnParameters = [];
    var regi = false;
    for (i = 0; i < parameterList.length; i++) {
        //console.log('VALUE: ' + value);
        //console.log('NAME: ' + parameterList[i].Parameter_Label__c);
        //console.log('Minimalni castka pro investovani: ' + parameterList[i].Calc_Min_Value__c);
        var maxPercent = ((originalValue / 100) * parameterList[i].Calc_Max_Percentage__c);
        //console.log('Maximalni castka pro investovani: ' + (originalValue / 100) * parameterList[i].Calc_Max_Percentage__c);
        if (maxPercent >= parameterList[i].Calc_Min_Value__c && value >= parameterList[i].Calc_Min_Value__c) {
            if (value >= maxPercent) {
                value = value - maxPercent;
                parameterList[i].investedMoney = maxPercent.toFixed(0);
            } else {
                parameterList[i].investedMoney = value.toFixed(0);
                value = 0;
            }

            returnParameters.push(parameterList[i]);
            //console.log('investovano: ' + parameterList[i].investedMoney);
        } else {
            //console.log('neinvestovano');
        }
        //console.log('----');
        if (parameterList[i].Type__c === "Regular Investment" || parameterList[i].Type__c === "Pravidelná investice") {
            regi = true;
        }
    }
    if (returnParameters.length == 0) {
        return false;
    }
    if (value > 0 && !regi) {
        returnParameters[0].investedMoney = (Number(returnParameters[0].investedMoney) + value).toFixed(0);
        //console.log('Zbyle investice: ' + value);
        //console.log('Prirazeno do: ' + returnParameters[0].Parameter_Label__c);
        //console.log('Celkem investice ve ' + returnParameters[0].Parameter_Label__c + ': ' + returnParameters[0].investedMoney);
        value = 0;
    }
    //console.log('--------------------------------KONEC-------------------------------------');
    return returnParameters;
}

function addResultToTable(table, result) {
    for (i = 0; i < result.length; i++) {
        table.innerHTML += '<tr class="slds-hint-parent">' +
            '<td>' + result[i].Parameter_Label__c + '</td>' +
            '<td>' + result[i].Type__c + '</td>' +
            '<td style="text-align: right;">' + result[i].investedMoney.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ' Kč</td>' +
            '</tr>'
    }
}

/*function printInvestment(template) {
    disablePrintButton(template);
    document.getElementById("a-transitions-tab").click();
    if (pppConfig.length > 0) {
        var mainInput = $('[id^="GENERAL"]')[0];
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.generateQuoteForPrinting,
            configuration.oppId,
            pppConfig,
            mainInput.value,
            configuration.accountId,
            template,
            function(result, event) {
                //console.log(result);
                //                alert('This function is currently under development...');
                if (result.indexOf('/quote/') !== -1) {
                    var parser = new DOMParser;
                    var dom = parser.parseFromString('<!doctype html><body>' + result, 'text/html');
                    var decodedUrl = dom.body.textContent;


                    if (sforce.console.isInConsole()) {
                        sforce.console.getEnclosingPrimaryTabId(function(res) {
                            sforce.console.openSubtab(res.id, decodedUrl, consoleNavigateToOpenSubtab);
                        });
                    } else {
                        if (parent) {
                            openInLwc('openSubTabWithNewUrl', decodedUrl, 'Investice');
                        }
                    }
                } else {
                    alert(result);
                }
            }
        );
    } else {
        if (!document.getElementById("err-div")) {
            var errDiv = document.createElement("div");
            errDiv.setAttribute('style', 'text-align: center; color: red; margin-top: 30px;');
            errDiv.setAttribute('id', 'err-div');
            errDiv.innerHTML = "Nejprve prosím vypočtěte výsledky.";
            $('#content-overview').append(errDiv)
        }
        enablePrintButton();
    }
}*/

function disablePrintButton(id) {
    $('#' + id).attr('disabled', 'disabled');
}

function enablePrintButton() {
    $('#print-inv-btn').removeAttr('disabled');
}

function checkValues() {
    /*if (configuration.migrationProcessName === 'Heritage' || configuration.migrationProcessName === 'Account_Cancellation') {
        var LabelNoValue = $Label.Migration_Premium_No_Value;
        var LabelNoValueEnd = $Label.Migration_Premium_No_Value_End;
        var LabelNotSelected = $Label.Migration_Premium_Not_Selected;
        var LabelNotSelectedAccCancel = $Label.Account_Cancel_Fill_Value;

        if (isEmpty(configuration.productList.itemMap)) {
             if (configuration.migrationProcessName === 'Heritage'){
                 alertify.alert('Upozornění', LabelNotSelected, function() {});
             } else if(configuration.migrationProcessName === 'Account_Cancellation'){
                 alertify.alert('Upozornění', LabelNotSelectedAccCancel, function() {});
             }
             return;
        } else {
            var selectedProducts = document.getElementById("selected-products");
            var selects = document.querySelectorAll('#prod_param_select_9_69');
            var prodList = [];

            for (var i = 0; i < selects.length; i++) {
                var currentSelect = selects[i];
                //console.log('### currentSelect - ', currentSelect);
                var currentValue = currentSelect.options[currentSelect.selectedIndex].value;
                var currentName = currentSelect.dataset.prodname;
                var pid = currentSelect.dataset.parid.split('-')[0];
                var currentErr = $('#transition-error-' + currentSelect.dataset.parid + '-' + currentSelect.dataset.prodid);
                if (currentValue == "0") {
                    prodList.push({
                        name: currentName,
                        id: pid
                    });
                    currentErr.show();
                } else {
                    currentErr.hide();
                }
            }
            var ddl = document.getElementById("prod_param_select_9_69");
            var selectedValue = ddl.options[ddl.selectedIndex].value;
            if (prodList.length > 0) {
                //label Migration_Premium_No_Value
                alertify.alert('Upozornění', LabelNoValue + ' ' + prodList[0].name + " " + LabelNoValueEnd, function() {});
                changePage(prodList[0].id);
                document.getElementById("a-transitions-tab").click();
                return;
            } else {
                selectScopedTab('nav-overview', 'content-overview', 'nav-product-settings', 'content-configuration');
            }
        }
    }*/
    if (requiredFields.length > 0) {
        var reqMessage = [];
        for (var i = 0; i < requiredFields.length; i++) {
            var element = document.getElementById(requiredFields[i].id);
            if (element && !element.parentElement.parentElement.classList.contains('migration-hide') && !element.parentElement.parentElement.parentElement.classList.contains('migration-hide')) {
                if (requiredFields[i].childIds.length > 0) {
                    var ok = false;
                    requiredFields[i].childIds.forEach(function(r) {
                        if (element.value == r.Id) {
                            ok = true;
                        }
                    });
                    if (!ok) {
                        reqMessage.push(requiredFields[i].label);
                    }
                } else {
                    if (element.value == '' || (element.tagName === 'SELECT' && element.querySelector('option[value=\'' + element.value + '\']').innerHTML == '--Vyberte--')) {
                        reqMessage.push(requiredFields[i].label);
                    }
                }
            }
        }
        if (reqMessage.length > 0) {
            document.getElementById("scopedTab0").click();
            var LabelReqFields = $Label.Migration_Premium_Required_Fields;
            var fields = '';
            reqMessage.forEach(function(field) {
                //console.log('### field - ', field);
                fields += field + ', ';
            });
            fields = fields.slice(0, -2);
            alertify.alert('Upozornění', LabelReqFields + ' ' + fields, function() {});
            return;
        }
    }
    if (configuration.migrationProcessName === 'Heritage') {
        showLoadingModal();
        Visualforce.remoting.Manager.invokeAction(
            migrationDefaults.remoteActions.checkHeirsData,
            JSON.stringify(configuration.productRelations),
            configuration.cuid,
            false,
            function(result, event) {
                if (event.status && result) {
                    if (result === 'nok') {
                        alertify.alert('Chyba', 'Zadané jméno, příjmení a datum narození dědice již existuje na jiném servisním případu.');
                        document.getElementById("scopedTab0").click();
                    } else if (result === 'error') {
                        alertify.alert('Chyba', 'Chyba při načítání konfigurace na servisním případu.');
                        document.getElementById("scopedTab0").click();
                    }
                    dismissLoadingModal();
                } else {
                    alertify.alert('Chyba! ' + event);
                    dismissLoadingModal();
                    document.getElementById("scopedTab0").click();
                }
            }
        );
    }

    if (configuration.pretermDocSwitch) {
        //        var isIE11 = !!window.MSInputMethodContext && !!document.documentMode;
        //        if (isIE11) {
        //            $('.printmsg').toggleClass('ie');
        //        }

        sendOutputSent = false;
        sendOutputDataListEl = [];
        sendOutputDataListPap = [];
        printingDuty = false;
        allPreContractDocumentPrinted = false;
        var htmlContent = '';
        var docProductList = getPretermDocProductList();
        pretermDocListLength = 0;
        var atLeastOneDocumentFromCST = false;
        for (var i = 0; i < docProductList.length; i++) {
            //console.log('*** Having pretermdoc: ' + docProductList[i].cstValueId);
            //console.log('with product name: ' + docProductList[i].name);
            if (docProductList[i].name) {
                htmlContent += '<h2>{0}</h2>'.format(docProductList[i].name);
                htmlContent += '<ul>';
            }
            /*if(configuration.cstProdMap[docProductList[i].cstValueId]) {
                configuration.cstProdMap[docProductList[i].cstValueId].forEach(function(docItem) {
                    htmlContent += '<li class="slds-dropdown__item"><a href="#void" role="menuitem" onclick="generatePretermDocument(\'{0}\', this)">' +
                                    '<p class="slds-truncate" style="width: 100%">{1}' +
                                    '<div class="float-right"><svg class="print-ico printer"><use xlink:href="{2}"></use></svg>';
                    var docDataId = docItem.cstValueId.split('-')[1] * 1;
                    var docAccNum = configuration.migrationProcessName == 'PPP' ? $('[data-syncElemName="PPP_ProdNumber"]').find(":selected").text() : docProductList[i].parentAccNumber ? docProductList[i].parentAccNumber : docProductList[i].accNumber; //parentAccNum should be present and used only for cards
                    if (migrationDefaults.fsval.errSize > 1 || (docProductList[i].insurance && $('#doc-el-distrib-opt-nok:selected').length > 0)) {
                        htmlContent += '<svg class="print-ico ok" style="display: none;"><use xlink:href="{3}"></use></svg>' +
                                        '<svg class="print-ico nok"><use xlink:href="{4}"></use></svg>';
                        printingDuty = true;
                        sendOutputDataListPap.push({uri: docItem.guid, docDesc: docItem.docDesc, docDataId: docDataId, accNum: docAccNum});
                        pretermDocListLength++;
                    } else {
                        sendOutputDataListEl.push({uri: docItem.guid, docDesc: docItem.docDesc, docDataId: docDataId, accNum: docAccNum});
                    }
                    htmlContent += '</div></p></a></li>';
                    htmlContent = htmlContent.format(docItem.guid, docItem.docDesc, 'https://' + migrationDefaults.urls.sf + migrationDefaults.images.printer, migrationDefaults.images.printok, migrationDefaults.images.printnok);
                    atLeastOneDocumentFromCST = true;
                });
            } else {*/
            htmlContent += '<li class="no-doc">Nebyly nalezeny žádné předsmluvní dokumenty...</li>';
            //}
            htmlContent += '</ul>';
        }
        htmlContent = atLeastOneDocumentFromCST ? htmlContent : '';

        var htmlLocalDocContent = '';
        for (var i = 0; i < configuration.documents.length; i++) {
            var doc = configuration.documents[i];
            if (doc.Pre_contract_document__c && doc.URL__c) {
                htmlLocalDocContent += '<li class="slds-dropdown__item"><a href="#void" role="menuitem" onclick="openNonIstsDocument(\'{0}\', \'{1}\', {3})">' +
                    '<p class="slds-truncate" style="width: 100%">{1}' +
                    '<div class="float-right"><svg class="print-ico printer"><use xlink:href="{2}"></use></svg></div></p></a></li>';
                htmlLocalDocContent = htmlLocalDocContent.format(doc.URL__c, doc.Label_CZ__c, 'https://' + migrationDefaults.urls.sf + migrationDefaults.images.printer, doc.Open_In_New_Window__c);
            }
        }
        htmlLocalDocContent = htmlLocalDocContent.length > 0 ? '<h2>&nbsp;</h2><ul>' + htmlLocalDocContent + '</ul>' : '';
        htmlContent += htmlLocalDocContent;

        if (printingDuty) {
            $('li.print-enabled').attr('class', 'slds-dropdown__item printmsg');
            $('svg.print-ico.printer').attr('class', 'print-ico nok-printer'); // on svg element does not work: .removeClass('nok-printer').addClass('printer');
            $('.printmsg-text').css('display', 'block');
        } else {
            $('.printmsg-text').css('display', 'none');
            $('li.printmsg').attr('class', 'slds-dropdown__item print-enabled');
            $('svg.print-ico.nok-printer').attr('class', 'print-ico printer'); // on svg element does not work: .removeClass('nok-printer').addClass('printer');
        }

        //console.log('***sendOutputDataListEl: ', sendOutputDataListEl);
        //console.log('***sendOutputDataListPap: ', sendOutputDataListPap);

        if (!configuration.sendOutputOnSubmit) {
            checkAndSendOutput();
        }

        //console.log(htmlContent);
        $('#preterm-doc-list-content').html(htmlContent);

        if ($('#doc-el-distrib-agreement').css("display") === 'block' && $('#doc-el-distrib-opt-nok:selected').length > 0) {
            $('#el-doc-dist-agr-error').show();
        } else {
            $('#el-doc-dist-agr-error').hide();
        }
    }

    selectScopedTab('nav-overview', 'content-overview', 'nav-product-settings', 'content-configuration');

    if (configuration.pretermDocSwitch) {
        $('#precontract-section').css('height', 'auto');
        $('#contract-section').css('height', 'auto');
        if ($('#precontract-section').height() > $('#contract-section').height()) {
            $('#contract-section').height($('#precontract-section').height());
        } else {
            $('#precontract-section').height($('#contract-section').height());
        }
        var printMargin = $('#contract-doc-list-content').width() - 300;
        $('.printmsg .printmsg-text').css('margin-left', printMargin);
    }

    /*    if(configuration.migrationProcessName === 'Heritage' ){
            showLoadingModal();
            var prodRelConf = JSON.stringify(configuration.productRelations);
            console.log(prodRelConf);
            Visualforce.remoting.Manager.invokeAction(
                migrationDefaults.remoteActions.checkElbValid,
                prodRelConf,
                configuration.savedConfiguration,
                function(result, event) {
                    if(event.status && result){
                        if(result === 'nok'){
                            $('#missing-elb-for-client-or-nonclient').show();
                        } else if( result === 'error'){
                            alertify.alert('Chyba', 'Chyba při načítání konfigurace.');
                        }
                        dismissLoadingModal();
                    }else{
                        alertify.alert('Chyba! ' + event);
                        dismissLoadingModal();
                    }
                }
            );
        }*/

}

function getPretermDocProductList() {
    //product relations:
    var docProductList = [];
    if (!configuration.doNotLoadPretermDocFromCST) {
        for (var prKey in configuration.productRelations) {
            if (prKey != 'GENERAL') {
                for (var prKey2 in configuration.productRelations[prKey]) {
                    var to = $('#' + prKey + '-' + prKey2).find('#prod_param_select_9_69').find('option:selected').length > 0 ? $('#' + prKey + '-' + prKey2).find('#prod_param_select_9_69').find('option:selected')[0].dataset.toCstValId : 'cancel';
                    if (to != 'cancel') {
                        var toName = $('#' + prKey + '-' + prKey2).find('#prod_param_select_9_69').find('option:selected')[0].dataset.toName;
                        var found = false;
                        for (var i = 0; i < docProductList.length; i++) {
                            if (docProductList[i].cstValueId == to) {
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            var accNum = configuration.productRelations[prKey][prKey2].assetAccountNumber;
                            var parentAccNum = configuration.productRelations[prKey][prKey2].isCard && configuration.productRelations[prKey][prKey2].parentAssetAccNumber ? configuration.productRelations[prKey][prKey2].parentAssetAccNumber : null;
                            docProductList.push({ name: toName, cstValueId: to, accNumber: accNum, parentAccNumber: parentAccNum, insurance: false });
                        }
                    }
                }
            }
        }

        //product parameters:
        for (var i = 0; i < $('[data-product-cst-value-id]:selected').length; i++) {
            var cvi = $('[data-product-cst-value-id]:selected')[i].getAttribute('data-product-cst-value-id');
            var cpn = $('[data-product-name]:selected')[i].getAttribute('data-product-name');
            var prParentId = $('[data-product-name]:selected').parent()[i].getAttribute('data-parentid');
            var prProductId = $('[data-product-name]:selected').parent()[i].getAttribute('data-productid');
            var insurance = $('[data-product-name]:selected').parent()[i].getAttribute('data-insurance');
            var parentAccNum = configuration.productRelations[prParentId][prProductId].isCard && configuration.productRelations[prParentId][prProductId].parentAssetAccNumber ? configuration.productRelations[prParentId][prProductId].parentAssetAccNumber : null;
            docProductList.push({ name: cpn, cstValueId: cvi, accNumber: configuration.productRelations[prParentId][prProductId].assetAccountNumber, parentAccNumber: parentAccNum, insurance: insurance ? true : false });
        }
    }
    return docProductList;
}

function propagateDocElDistribAgreement(element) {
    if (element.id === 'doc-el-distrib-select') {
        if ($('#doc-el-distrib-select').val() === 'ok') {
            if ($('[data-doc-dist-agreement] option:selected').text().toLowerCase().indexOf("ne") !== -1) {
                $('[data-doc-dist-agreement]').val($('[data-doc-dist-agreement] option:not(:selected)').val())
            }
        } else {
            if ($('[data-doc-dist-agreement] option:selected').text().toLowerCase().indexOf("ne") === -1) {
                $('[data-doc-dist-agreement]').val($('[data-doc-dist-agreement] option:not(:selected)').val())
            }
        }
        var selId = $('[data-doc-dist-agreement]').attr('id');
        var selIdParts = selId.split('-');
        if (selIdParts.length > 4) {
            changeProductParameterValue(selIdParts[0] + '-' + selIdParts[1], selIdParts[2] + '-' + selIdParts[3], selIdParts[4], $('[data-doc-dist-agreement]').val(), null, null, null, true);
        }
    } else {
        if ($('[data-doc-dist-agreement] option:selected').text().toLowerCase().indexOf("ne") === -1) {
            $('#doc-el-distrib-select').val('ok');
        } else {
            $('#doc-el-distrib-select').val('nok');
        }
    }
}

function setElDocDistAgrSelectVisibility(pageId) {
    if (configuration.pretermDocSwitch) {
        $('[data-doc-dist-agreement]').parent().parent().hide();
        if (!configuration.savedConfiguration) {
            var globalCheck = false;
            var pageCheck = false;
            $('.dda').each(function() {
                var idParts = $(this).attr('id').split('-');
                var currentPageId = idParts[0];
                if ($(this).find('option:selected').text() && $(this).find('option:selected').text().toLowerCase() !== 'žádné') {
                    globalCheck = true;
                    elDocDistVisible = true;
                    if (migrationDefaults.fsval.errSize > 1) {
                        $("#doc-el-distrib-select").attr("disabled", "disabled");
                        $('#doc-el-distrib-select').val('nok');
                    }
                    if (currentPageId == pageId) {
                        pageCheck = true;
                        $('#doc-el-distrib-agreement').show();
                        elDocDistVisibilityPerPage[pageId] = true;
                    }
                }
            });
            if (!globalCheck) {
                elDocDistVisible = false;
            }
            if (!pageCheck) {
                $('#doc-el-distrib-agreement').hide();
                elDocDistVisibilityPerPage[pageId] = false;
            }
        }
    }
}

function checkAndSetGlobalElDocDistVisibility() {
    var globalCheck = false;
    for (var i = 0; i < elDocDistVisibilityPerPage.length; i++) {
        if (elDocDistVisibilityPerPage[i]) {
            globalCheck = true;
        }
    }
    elDocDistVisible = globalCheck;
}

function getElDocDistrib() {
    var elDocDist = '0';

    if (elDocDistVisible === true) {
        if ($('#doc-el-distrib-opt-ok:selected').length > 0) {
            elDocDist = '1';
        } else {
            elDocDist = '2';
        }
    }
    return elDocDist;
}

function isEmpty(obj) {
    for (var key in obj) {
        if (obj.hasOwnProperty(key))
            return false;
    }
    return true;
}

/*function calculateBagettaDate(){
     let submDate = $('[data-syncElemName="bagetta_submissionDateBagettaInput"]')[0].value;
     let sipo = $('[data-syncElemName="bagetta_sipoBagettaInput"]')[0].checked;
     let pension = $('[data-syncElemName="bagetta_pensionBagettaInput"]')[0].checked;

     Visualforce.remoting.Manager.invokeAction(migrationDefaults.remoteActions.calculateBagettaDate, submDate, sipo, pension, function(result, event) {
         if (event.status && result) {
            let resParts = result.split('.');
            if(resParts.length > 0) {
                result = ('0'+resParts[0]).slice(-2) + '.' + ('0'+resParts[1]).slice(-2) + '.' + resParts[2];
            }
            let effectiveDateElement = $('[data-syncElemName="bagetta_effectiveDate"]');
            effectiveDateElement[0].value = result;
            let idParts = effectiveDateElement[0].id.split('-');
            changeProductParameterValue(idParts[0], idParts[1], idParts[2], effectiveDateElement[0].value, null, null, effectiveDateElement[0].dataset.syncelemname);
            calculateBagettaCancDate();
         }
     });

     return false;
}*/

function calculateBagettaCancDate() {
    let effectiveDateElement = $('[data-syncElemName="bagetta_effectiveDate"]')[0];
    let baggetaDate = effectiveDateElement.value;
    let bdParts = baggetaDate.split('.');
    let cancDate;
    if (bdParts.length > 0) {
        let month = ('0' + (parseInt(bdParts[1], 10) % 12 + 1)).slice(-2);
        let year = parseInt(bdParts[1], 10) + 1 > 12 ? parseInt(bdParts[2], 10) + 1 : bdParts[2];
        let nextMonthDaysCount = lastday(year, month);
        let day = bdParts[0] > nextMonthDaysCount ? nextMonthDaysCount : bdParts[0];
        cancDate = day + '.' + month + '.' + year;
    }
    let cancDateElement = $('[data-syncElemName="cancellationDate"]')[0];
    cancDateElement.value = cancDate;
    let idParts = cancDateElement.id.split('-');
    changeProductParameterValue(idParts[0], idParts[1], idParts[2], cancDateElement.value, null, null, cancDateElement.dataset.syncelemname);
}

function lastday(y, m) {
    return new Date(y, m, 0).getDate();
}

function openNonIstsDocument(url, label, newWindow) {
    if (newWindow) {
        window.open(url);
    } else if (sforce.console.isInConsole()) {
        sforce.console.getEnclosingPrimaryTabId(function(primaryResult) {
            callBackopenTab(primaryResult, url, label);
        });
    } else if (parent) {
        openInLwc('openSubTabWithNewUrl', url, label)
    } else {
        window.open(url);
    }
}

function openInLwc(action, url, subTabName) {
    var origin;
    if (location.ancestorOrigins[0] != null) {
        origin = location.ancestorOrigins[0];
    }
    var actualUrl = new URL(window.location.href);
    var openTime = actualUrl.searchParams.get("open_time");
    var pass_data = {
        'openTime': openTime,
        'action': action,
        'subTabName': subTabName,
        'url': url
    };
    console.log('standa111 migracePremium params ', pass_data);
    parent.postMessage(JSON.stringify(pass_data), origin);
}

function checkAndSendOutput() {
    if (typeOfOperation !== 'draft') {
        if (migrationDefaults.fsval.errSize < 2 && !configuration.savedConfiguration && sendOutputDataListEl.length > 0) {
            var typeId = migrationDefaults.fsval.errSize == 0 ? 37 : 15;
            var contact = null //migrationDefaults.fsval.errSize == 0 ? configuration.cuid : migrationDefaults.fsval.email;
            var offerType = configuration.migrationProcessName == 'PPP' ? '8' : '2';
            Visualforce.remoting.Manager.invokeAction(
                migrationDefaults.remoteActions.sendOutput,
                configuration.cuid,
                typeId,
                contact,
                offerType,
                configuration.sentOutputType,
                configuration.migrationProcessName,
                sendOutputDataListEl,
                function(result, event) {}
            );
        }
    }
}